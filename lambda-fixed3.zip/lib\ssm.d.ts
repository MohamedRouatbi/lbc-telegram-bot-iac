/**
 * Get a parameter from SSM Parameter Store with caching
 * @param parameterName - The name of the parameter to retrieve
 * @param useCache - Whether to use cached value (default: true)
 * @returns The parameter value
 */
export declare function getParameter(parameterName: string, useCache?: boolean): Promise<string>;
/**
 * Get multiple parameters from SSM Parameter Store
 * @param parameterNames - Array of parameter names to retrieve
 * @returns Object with parameter names as keys and values
 */
export declare function getParameters(parameterNames: string[]): Promise<Record<string, string>>;
/**
 * Clear the parameter cache (useful for testing or forced refresh)
 */
export declare function clearParameterCache(): void;
//# sourceMappingURL=ssm.d.ts.map
'use strict';

var middlewareHostHeader = require('@aws-sdk/middleware-host-header');
var middlewareLogger = require('@aws-sdk/middleware-logger');
var middlewareRecursionDetection = require('@aws-sdk/middleware-recursion-detection');
var middlewareSdkSqs = require('@aws-sdk/middleware-sdk-sqs');
var middlewareUserAgent = require('@aws-sdk/middleware-user-agent');
var configResolver = require('@smithy/config-resolver');
var core = require('@smithy/core');
var middlewareContentLength = require('@smithy/middleware-content-length');
var middlewareEndpoint = require('@smithy/middleware-endpoint');
var middlewareRetry = require('@smithy/middleware-retry');
var smithyClient = require('@smithy/smithy-client');
var httpAuthSchemeProvider = require('./auth/httpAuthSchemeProvider');
var runtimeConfig = require('./runtimeConfig');
var regionConfigResolver = require('@aws-sdk/region-config-resolver');
var protocolHttp = require('@smithy/protocol-http');
var middlewareSerde = require('@smithy/middleware-serde');
var core$1 = require('@aws-sdk/core');

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "sqs",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(regionConfigResolver.getAwsRegionExtensionConfiguration(runtimeConfig), smithyClient.getDefaultExtensionConfiguration(runtimeConfig), protocolHttp.getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, regionConfigResolver.resolveAwsRegionExtensionConfiguration(extensionConfiguration), smithyClient.resolveDefaultRuntimeConfig(extensionConfiguration), protocolHttp.resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class SQSClient extends smithyClient.Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = runtimeConfig.getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = middlewareUserAgent.resolveUserAgentConfig(_config_1);
        const _config_3 = middlewareRetry.resolveRetryConfig(_config_2);
        const _config_4 = configResolver.resolveRegionConfig(_config_3);
        const _config_5 = middlewareHostHeader.resolveHostHeaderConfig(_config_4);
        const _config_6 = middlewareEndpoint.resolveEndpointConfig(_config_5);
        const _config_7 = middlewareSdkSqs.resolveQueueUrlConfig(_config_6);
        const _config_8 = httpAuthSchemeProvider.resolveHttpAuthSchemeConfig(_config_7);
        const _config_9 = resolveRuntimeExtensions(_config_8, configuration?.extensions || []);
        this.config = _config_9;
        this.middlewareStack.use(middlewareUserAgent.getUserAgentPlugin(this.config));
        this.middlewareStack.use(middlewareRetry.getRetryPlugin(this.config));
        this.middlewareStack.use(middlewareContentLength.getContentLengthPlugin(this.config));
        this.middlewareStack.use(middlewareHostHeader.getHostHeaderPlugin(this.config));
        this.middlewareStack.use(middlewareLogger.getLoggerPlugin(this.config));
        this.middlewareStack.use(middlewareRecursionDetection.getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(middlewareSdkSqs.getQueueUrlPlugin(this.config));
        this.middlewareStack.use(core.getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: httpAuthSchemeProvider.defaultSQSHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new core.DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(core.getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

class SQSServiceException extends smithyClient.ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, SQSServiceException.prototype);
    }
}

class InvalidAddress extends SQSServiceException {
    name = "InvalidAddress";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidAddress",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAddress.prototype);
    }
}
class InvalidSecurity extends SQSServiceException {
    name = "InvalidSecurity";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidSecurity",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidSecurity.prototype);
    }
}
class OverLimit extends SQSServiceException {
    name = "OverLimit";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OverLimit",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OverLimit.prototype);
    }
}
class QueueDoesNotExist extends SQSServiceException {
    name = "QueueDoesNotExist";
    $fault = "client";
    constructor(opts) {
        super({
            name: "QueueDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, QueueDoesNotExist.prototype);
    }
}
class RequestThrottled extends SQSServiceException {
    name = "RequestThrottled";
    $fault = "client";
    constructor(opts) {
        super({
            name: "RequestThrottled",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, RequestThrottled.prototype);
    }
}
class UnsupportedOperation extends SQSServiceException {
    name = "UnsupportedOperation";
    $fault = "client";
    constructor(opts) {
        super({
            name: "UnsupportedOperation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedOperation.prototype);
    }
}
class ResourceNotFoundException extends SQSServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
class MessageNotInflight extends SQSServiceException {
    name = "MessageNotInflight";
    $fault = "client";
    constructor(opts) {
        super({
            name: "MessageNotInflight",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, MessageNotInflight.prototype);
    }
}
class ReceiptHandleIsInvalid extends SQSServiceException {
    name = "ReceiptHandleIsInvalid";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReceiptHandleIsInvalid",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReceiptHandleIsInvalid.prototype);
    }
}
class BatchEntryIdsNotDistinct extends SQSServiceException {
    name = "BatchEntryIdsNotDistinct";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BatchEntryIdsNotDistinct",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BatchEntryIdsNotDistinct.prototype);
    }
}
class EmptyBatchRequest extends SQSServiceException {
    name = "EmptyBatchRequest";
    $fault = "client";
    constructor(opts) {
        super({
            name: "EmptyBatchRequest",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, EmptyBatchRequest.prototype);
    }
}
class InvalidBatchEntryId extends SQSServiceException {
    name = "InvalidBatchEntryId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidBatchEntryId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidBatchEntryId.prototype);
    }
}
class TooManyEntriesInBatchRequest extends SQSServiceException {
    name = "TooManyEntriesInBatchRequest";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TooManyEntriesInBatchRequest",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TooManyEntriesInBatchRequest.prototype);
    }
}
const QueueAttributeName = {
    All: "All",
    ApproximateNumberOfMessages: "ApproximateNumberOfMessages",
    ApproximateNumberOfMessagesDelayed: "ApproximateNumberOfMessagesDelayed",
    ApproximateNumberOfMessagesNotVisible: "ApproximateNumberOfMessagesNotVisible",
    ContentBasedDeduplication: "ContentBasedDeduplication",
    CreatedTimestamp: "CreatedTimestamp",
    DeduplicationScope: "DeduplicationScope",
    DelaySeconds: "DelaySeconds",
    FifoQueue: "FifoQueue",
    FifoThroughputLimit: "FifoThroughputLimit",
    KmsDataKeyReusePeriodSeconds: "KmsDataKeyReusePeriodSeconds",
    KmsMasterKeyId: "KmsMasterKeyId",
    LastModifiedTimestamp: "LastModifiedTimestamp",
    MaximumMessageSize: "MaximumMessageSize",
    MessageRetentionPeriod: "MessageRetentionPeriod",
    Policy: "Policy",
    QueueArn: "QueueArn",
    ReceiveMessageWaitTimeSeconds: "ReceiveMessageWaitTimeSeconds",
    RedriveAllowPolicy: "RedriveAllowPolicy",
    RedrivePolicy: "RedrivePolicy",
    SqsManagedSseEnabled: "SqsManagedSseEnabled",
    VisibilityTimeout: "VisibilityTimeout",
};
class InvalidAttributeName extends SQSServiceException {
    name = "InvalidAttributeName";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidAttributeName",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAttributeName.prototype);
    }
}
class InvalidAttributeValue extends SQSServiceException {
    name = "InvalidAttributeValue";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidAttributeValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAttributeValue.prototype);
    }
}
class QueueDeletedRecently extends SQSServiceException {
    name = "QueueDeletedRecently";
    $fault = "client";
    constructor(opts) {
        super({
            name: "QueueDeletedRecently",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, QueueDeletedRecently.prototype);
    }
}
class QueueNameExists extends SQSServiceException {
    name = "QueueNameExists";
    $fault = "client";
    constructor(opts) {
        super({
            name: "QueueNameExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, QueueNameExists.prototype);
    }
}
class InvalidIdFormat extends SQSServiceException {
    name = "InvalidIdFormat";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidIdFormat",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidIdFormat.prototype);
    }
}
class PurgeQueueInProgress extends SQSServiceException {
    name = "PurgeQueueInProgress";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PurgeQueueInProgress",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PurgeQueueInProgress.prototype);
    }
}
class KmsAccessDenied extends SQSServiceException {
    name = "KmsAccessDenied";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsAccessDenied",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsAccessDenied.prototype);
    }
}
class KmsDisabled extends SQSServiceException {
    name = "KmsDisabled";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsDisabled",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsDisabled.prototype);
    }
}
class KmsInvalidKeyUsage extends SQSServiceException {
    name = "KmsInvalidKeyUsage";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsInvalidKeyUsage",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsInvalidKeyUsage.prototype);
    }
}
class KmsInvalidState extends SQSServiceException {
    name = "KmsInvalidState";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsInvalidState",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsInvalidState.prototype);
    }
}
class KmsNotFound extends SQSServiceException {
    name = "KmsNotFound";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsNotFound.prototype);
    }
}
class KmsOptInRequired extends SQSServiceException {
    name = "KmsOptInRequired";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsOptInRequired",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsOptInRequired.prototype);
    }
}
class KmsThrottled extends SQSServiceException {
    name = "KmsThrottled";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KmsThrottled",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KmsThrottled.prototype);
    }
}
const MessageSystemAttributeName = {
    AWSTraceHeader: "AWSTraceHeader",
    All: "All",
    ApproximateFirstReceiveTimestamp: "ApproximateFirstReceiveTimestamp",
    ApproximateReceiveCount: "ApproximateReceiveCount",
    DeadLetterQueueSourceArn: "DeadLetterQueueSourceArn",
    MessageDeduplicationId: "MessageDeduplicationId",
    MessageGroupId: "MessageGroupId",
    SenderId: "SenderId",
    SentTimestamp: "SentTimestamp",
    SequenceNumber: "SequenceNumber",
};
class InvalidMessageContents extends SQSServiceException {
    name = "InvalidMessageContents";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidMessageContents",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidMessageContents.prototype);
    }
}
const MessageSystemAttributeNameForSends = {
    AWSTraceHeader: "AWSTraceHeader",
};
class BatchRequestTooLong extends SQSServiceException {
    name = "BatchRequestTooLong";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BatchRequestTooLong",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BatchRequestTooLong.prototype);
    }
}

const se_AddPermissionCommand = async (input, context) => {
    const headers = sharedHeaders("AddPermission");
    let body;
    body = JSON.stringify(se_AddPermissionRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CancelMessageMoveTaskCommand = async (input, context) => {
    const headers = sharedHeaders("CancelMessageMoveTask");
    let body;
    body = JSON.stringify(se_CancelMessageMoveTaskRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ChangeMessageVisibilityCommand = async (input, context) => {
    const headers = sharedHeaders("ChangeMessageVisibility");
    let body;
    body = JSON.stringify(se_ChangeMessageVisibilityRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ChangeMessageVisibilityBatchCommand = async (input, context) => {
    const headers = sharedHeaders("ChangeMessageVisibilityBatch");
    let body;
    body = JSON.stringify(se_ChangeMessageVisibilityBatchRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateQueueCommand = async (input, context) => {
    const headers = sharedHeaders("CreateQueue");
    let body;
    body = JSON.stringify(se_CreateQueueRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteMessageCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteMessage");
    let body;
    body = JSON.stringify(se_DeleteMessageRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteMessageBatchCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteMessageBatch");
    let body;
    body = JSON.stringify(se_DeleteMessageBatchRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteQueueCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteQueue");
    let body;
    body = JSON.stringify(se_DeleteQueueRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetQueueAttributesCommand = async (input, context) => {
    const headers = sharedHeaders("GetQueueAttributes");
    let body;
    body = JSON.stringify(se_GetQueueAttributesRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetQueueUrlCommand = async (input, context) => {
    const headers = sharedHeaders("GetQueueUrl");
    let body;
    body = JSON.stringify(se_GetQueueUrlRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListDeadLetterSourceQueuesCommand = async (input, context) => {
    const headers = sharedHeaders("ListDeadLetterSourceQueues");
    let body;
    body = JSON.stringify(se_ListDeadLetterSourceQueuesRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListMessageMoveTasksCommand = async (input, context) => {
    const headers = sharedHeaders("ListMessageMoveTasks");
    let body;
    body = JSON.stringify(se_ListMessageMoveTasksRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListQueuesCommand = async (input, context) => {
    const headers = sharedHeaders("ListQueues");
    let body;
    body = JSON.stringify(se_ListQueuesRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListQueueTagsCommand = async (input, context) => {
    const headers = sharedHeaders("ListQueueTags");
    let body;
    body = JSON.stringify(se_ListQueueTagsRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_PurgeQueueCommand = async (input, context) => {
    const headers = sharedHeaders("PurgeQueue");
    let body;
    body = JSON.stringify(se_PurgeQueueRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ReceiveMessageCommand = async (input, context) => {
    const headers = sharedHeaders("ReceiveMessage");
    let body;
    body = JSON.stringify(se_ReceiveMessageRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_RemovePermissionCommand = async (input, context) => {
    const headers = sharedHeaders("RemovePermission");
    let body;
    body = JSON.stringify(se_RemovePermissionRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_SendMessageCommand = async (input, context) => {
    const headers = sharedHeaders("SendMessage");
    let body;
    body = JSON.stringify(se_SendMessageRequest(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_SendMessageBatchCommand = async (input, context) => {
    const headers = sharedHeaders("SendMessageBatch");
    let body;
    body = JSON.stringify(se_SendMessageBatchRequest(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_SetQueueAttributesCommand = async (input, context) => {
    const headers = sharedHeaders("SetQueueAttributes");
    let body;
    body = JSON.stringify(se_SetQueueAttributesRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartMessageMoveTaskCommand = async (input, context) => {
    const headers = sharedHeaders("StartMessageMoveTask");
    let body;
    body = JSON.stringify(se_StartMessageMoveTaskRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_TagQueueCommand = async (input, context) => {
    const headers = sharedHeaders("TagQueue");
    let body;
    body = JSON.stringify(se_TagQueueRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UntagQueueCommand = async (input, context) => {
    const headers = sharedHeaders("UntagQueue");
    let body;
    body = JSON.stringify(se_UntagQueueRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const de_AddPermissionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_CancelMessageMoveTaskCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ChangeMessageVisibilityCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_ChangeMessageVisibilityBatchCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateQueueCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteMessageCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_DeleteMessageBatchCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteQueueCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_GetQueueAttributesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetQueueUrlCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListDeadLetterSourceQueuesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListMessageMoveTasksCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListQueuesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListQueueTagsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_PurgeQueueCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_ReceiveMessageCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ReceiveMessageResult(data, context);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_RemovePermissionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_SendMessageCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_SendMessageBatchCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_SetQueueAttributesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_StartMessageMoveTaskCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_TagQueueCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_UntagQueueCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    await smithyClient.collectBody(output.body, context);
    const response = {
        $metadata: deserializeMetadata(output),
    };
    return response;
};
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await core$1.parseJsonErrorBody(output.body, context),
    };
    populateBodyWithQueryCompatibility(parsedOutput, output.headers);
    const errorCode = core$1.loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InvalidAddress":
        case "com.amazonaws.sqs#InvalidAddress":
            throw await de_InvalidAddressRes(parsedOutput);
        case "InvalidSecurity":
        case "com.amazonaws.sqs#InvalidSecurity":
            throw await de_InvalidSecurityRes(parsedOutput);
        case "OverLimit":
        case "com.amazonaws.sqs#OverLimit":
            throw await de_OverLimitRes(parsedOutput);
        case "QueueDoesNotExist":
        case "com.amazonaws.sqs#QueueDoesNotExist":
        case "AWS.SimpleQueueService.NonExistentQueue":
            throw await de_QueueDoesNotExistRes(parsedOutput);
        case "RequestThrottled":
        case "com.amazonaws.sqs#RequestThrottled":
            throw await de_RequestThrottledRes(parsedOutput);
        case "UnsupportedOperation":
        case "com.amazonaws.sqs#UnsupportedOperation":
        case "AWS.SimpleQueueService.UnsupportedOperation":
            throw await de_UnsupportedOperationRes(parsedOutput);
        case "ResourceNotFoundException":
        case "com.amazonaws.sqs#ResourceNotFoundException":
            throw await de_ResourceNotFoundExceptionRes(parsedOutput);
        case "MessageNotInflight":
        case "com.amazonaws.sqs#MessageNotInflight":
        case "AWS.SimpleQueueService.MessageNotInflight":
            throw await de_MessageNotInflightRes(parsedOutput);
        case "ReceiptHandleIsInvalid":
        case "com.amazonaws.sqs#ReceiptHandleIsInvalid":
            throw await de_ReceiptHandleIsInvalidRes(parsedOutput);
        case "BatchEntryIdsNotDistinct":
        case "com.amazonaws.sqs#BatchEntryIdsNotDistinct":
        case "AWS.SimpleQueueService.BatchEntryIdsNotDistinct":
            throw await de_BatchEntryIdsNotDistinctRes(parsedOutput);
        case "EmptyBatchRequest":
        case "com.amazonaws.sqs#EmptyBatchRequest":
        case "AWS.SimpleQueueService.EmptyBatchRequest":
            throw await de_EmptyBatchRequestRes(parsedOutput);
        case "InvalidBatchEntryId":
        case "com.amazonaws.sqs#InvalidBatchEntryId":
        case "AWS.SimpleQueueService.InvalidBatchEntryId":
            throw await de_InvalidBatchEntryIdRes(parsedOutput);
        case "TooManyEntriesInBatchRequest":
        case "com.amazonaws.sqs#TooManyEntriesInBatchRequest":
        case "AWS.SimpleQueueService.TooManyEntriesInBatchRequest":
            throw await de_TooManyEntriesInBatchRequestRes(parsedOutput);
        case "InvalidAttributeName":
        case "com.amazonaws.sqs#InvalidAttributeName":
            throw await de_InvalidAttributeNameRes(parsedOutput);
        case "InvalidAttributeValue":
        case "com.amazonaws.sqs#InvalidAttributeValue":
            throw await de_InvalidAttributeValueRes(parsedOutput);
        case "QueueDeletedRecently":
        case "com.amazonaws.sqs#QueueDeletedRecently":
        case "AWS.SimpleQueueService.QueueDeletedRecently":
            throw await de_QueueDeletedRecentlyRes(parsedOutput);
        case "QueueNameExists":
        case "com.amazonaws.sqs#QueueNameExists":
        case "QueueAlreadyExists":
            throw await de_QueueNameExistsRes(parsedOutput);
        case "InvalidIdFormat":
        case "com.amazonaws.sqs#InvalidIdFormat":
            throw await de_InvalidIdFormatRes(parsedOutput);
        case "PurgeQueueInProgress":
        case "com.amazonaws.sqs#PurgeQueueInProgress":
        case "AWS.SimpleQueueService.PurgeQueueInProgress":
            throw await de_PurgeQueueInProgressRes(parsedOutput);
        case "KmsAccessDenied":
        case "com.amazonaws.sqs#KmsAccessDenied":
        case "KMS.AccessDeniedException":
            throw await de_KmsAccessDeniedRes(parsedOutput);
        case "KmsDisabled":
        case "com.amazonaws.sqs#KmsDisabled":
        case "KMS.DisabledException":
            throw await de_KmsDisabledRes(parsedOutput);
        case "KmsInvalidKeyUsage":
        case "com.amazonaws.sqs#KmsInvalidKeyUsage":
        case "KMS.InvalidKeyUsageException":
            throw await de_KmsInvalidKeyUsageRes(parsedOutput);
        case "KmsInvalidState":
        case "com.amazonaws.sqs#KmsInvalidState":
        case "KMS.InvalidStateException":
            throw await de_KmsInvalidStateRes(parsedOutput);
        case "KmsNotFound":
        case "com.amazonaws.sqs#KmsNotFound":
        case "KMS.NotFoundException":
            throw await de_KmsNotFoundRes(parsedOutput);
        case "KmsOptInRequired":
        case "com.amazonaws.sqs#KmsOptInRequired":
        case "KMS.OptInRequired":
            throw await de_KmsOptInRequiredRes(parsedOutput);
        case "KmsThrottled":
        case "com.amazonaws.sqs#KmsThrottled":
        case "KMS.ThrottlingException":
            throw await de_KmsThrottledRes(parsedOutput);
        case "InvalidMessageContents":
        case "com.amazonaws.sqs#InvalidMessageContents":
            throw await de_InvalidMessageContentsRes(parsedOutput);
        case "BatchRequestTooLong":
        case "com.amazonaws.sqs#BatchRequestTooLong":
        case "AWS.SimpleQueueService.BatchRequestTooLong":
            throw await de_BatchRequestTooLongRes(parsedOutput);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode,
            });
    }
};
const de_BatchEntryIdsNotDistinctRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new BatchEntryIdsNotDistinct({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_BatchRequestTooLongRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new BatchRequestTooLong({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_EmptyBatchRequestRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new EmptyBatchRequest({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAddressRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAddress({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAttributeNameRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAttributeName({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAttributeValueRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAttributeValue({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidBatchEntryIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidBatchEntryId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidIdFormatRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidIdFormat({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidMessageContentsRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidMessageContents({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidSecurityRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidSecurity({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsAccessDeniedRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsAccessDenied({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsDisabledRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsDisabled({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsInvalidKeyUsageRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsInvalidKeyUsage({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsInvalidStateRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsInvalidState({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsNotFoundRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsNotFound({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsOptInRequiredRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsOptInRequired({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_KmsThrottledRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new KmsThrottled({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_MessageNotInflightRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new MessageNotInflight({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OverLimitRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OverLimit({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_PurgeQueueInProgressRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new PurgeQueueInProgress({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_QueueDeletedRecentlyRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new QueueDeletedRecently({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_QueueDoesNotExistRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new QueueDoesNotExist({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_QueueNameExistsRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new QueueNameExists({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ReceiptHandleIsInvalidRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ReceiptHandleIsInvalid({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_RequestThrottledRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new RequestThrottled({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_TooManyEntriesInBatchRequestRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new TooManyEntriesInBatchRequest({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedOperationRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedOperation({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const se_ActionNameList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_AddPermissionRequest = (input, context) => {
    return smithyClient.take(input, {
        AWSAccountIds: (_) => se_AWSAccountIdList(_),
        Actions: (_) => se_ActionNameList(_),
        Label: core$1._toStr,
        QueueUrl: core$1._toStr,
    });
};
const se_AttributeNameList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_AWSAccountIdList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_BinaryList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return context.base64Encoder(entry);
    });
};
const se_CancelMessageMoveTaskRequest = (input, context) => {
    return smithyClient.take(input, {
        TaskHandle: core$1._toStr,
    });
};
const se_ChangeMessageVisibilityBatchRequest = (input, context) => {
    return smithyClient.take(input, {
        Entries: (_) => se_ChangeMessageVisibilityBatchRequestEntryList(_),
        QueueUrl: core$1._toStr,
    });
};
const se_ChangeMessageVisibilityBatchRequestEntry = (input, context) => {
    return smithyClient.take(input, {
        Id: core$1._toStr,
        ReceiptHandle: core$1._toStr,
        VisibilityTimeout: core$1._toNum,
    });
};
const se_ChangeMessageVisibilityBatchRequestEntryList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return se_ChangeMessageVisibilityBatchRequestEntry(entry);
    });
};
const se_ChangeMessageVisibilityRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
        ReceiptHandle: core$1._toStr,
        VisibilityTimeout: core$1._toNum,
    });
};
const se_CreateQueueRequest = (input, context) => {
    return smithyClient.take(input, {
        Attributes: (_) => se_QueueAttributeMap(_),
        QueueName: core$1._toStr,
        tags: (_) => se_TagMap(_),
    });
};
const se_DeleteMessageBatchRequest = (input, context) => {
    return smithyClient.take(input, {
        Entries: (_) => se_DeleteMessageBatchRequestEntryList(_),
        QueueUrl: core$1._toStr,
    });
};
const se_DeleteMessageBatchRequestEntry = (input, context) => {
    return smithyClient.take(input, {
        Id: core$1._toStr,
        ReceiptHandle: core$1._toStr,
    });
};
const se_DeleteMessageBatchRequestEntryList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return se_DeleteMessageBatchRequestEntry(entry);
    });
};
const se_DeleteMessageRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
        ReceiptHandle: core$1._toStr,
    });
};
const se_DeleteQueueRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
    });
};
const se_GetQueueAttributesRequest = (input, context) => {
    return smithyClient.take(input, {
        AttributeNames: (_) => se_AttributeNameList(_),
        QueueUrl: core$1._toStr,
    });
};
const se_GetQueueUrlRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueName: core$1._toStr,
        QueueOwnerAWSAccountId: core$1._toStr,
    });
};
const se_ListDeadLetterSourceQueuesRequest = (input, context) => {
    return smithyClient.take(input, {
        MaxResults: core$1._toNum,
        NextToken: core$1._toStr,
        QueueUrl: core$1._toStr,
    });
};
const se_ListMessageMoveTasksRequest = (input, context) => {
    return smithyClient.take(input, {
        MaxResults: core$1._toNum,
        SourceArn: core$1._toStr,
    });
};
const se_ListQueuesRequest = (input, context) => {
    return smithyClient.take(input, {
        MaxResults: core$1._toNum,
        NextToken: core$1._toStr,
        QueueNamePrefix: core$1._toStr,
    });
};
const se_ListQueueTagsRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
    });
};
const se_MessageAttributeNameList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_MessageAttributeValue = (input, context) => {
    return smithyClient.take(input, {
        BinaryListValues: (_) => se_BinaryList(_, context),
        BinaryValue: context.base64Encoder,
        DataType: core$1._toStr,
        StringListValues: (_) => se_StringList(_),
        StringValue: core$1._toStr,
    });
};
const se_MessageBodyAttributeMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        acc[key] = se_MessageAttributeValue(value, context);
        return acc;
    }, {});
};
const se_MessageBodySystemAttributeMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        acc[key] = se_MessageSystemAttributeValue(value, context);
        return acc;
    }, {});
};
const se_MessageSystemAttributeList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_MessageSystemAttributeValue = (input, context) => {
    return smithyClient.take(input, {
        BinaryListValues: (_) => se_BinaryList(_, context),
        BinaryValue: context.base64Encoder,
        DataType: core$1._toStr,
        StringListValues: (_) => se_StringList(_),
        StringValue: core$1._toStr,
    });
};
const se_PurgeQueueRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
    });
};
const se_QueueAttributeMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        acc[key] = core$1._toStr(value);
        return acc;
    }, {});
};
const se_ReceiveMessageRequest = (input, context) => {
    return smithyClient.take(input, {
        AttributeNames: (_) => se_AttributeNameList(_),
        MaxNumberOfMessages: core$1._toNum,
        MessageAttributeNames: (_) => se_MessageAttributeNameList(_),
        MessageSystemAttributeNames: (_) => se_MessageSystemAttributeList(_),
        QueueUrl: core$1._toStr,
        ReceiveRequestAttemptId: core$1._toStr,
        VisibilityTimeout: core$1._toNum,
        WaitTimeSeconds: core$1._toNum,
    });
};
const se_RemovePermissionRequest = (input, context) => {
    return smithyClient.take(input, {
        Label: core$1._toStr,
        QueueUrl: core$1._toStr,
    });
};
const se_SendMessageBatchRequest = (input, context) => {
    return smithyClient.take(input, {
        Entries: (_) => se_SendMessageBatchRequestEntryList(_, context),
        QueueUrl: core$1._toStr,
    });
};
const se_SendMessageBatchRequestEntry = (input, context) => {
    return smithyClient.take(input, {
        DelaySeconds: core$1._toNum,
        Id: core$1._toStr,
        MessageAttributes: (_) => se_MessageBodyAttributeMap(_, context),
        MessageBody: core$1._toStr,
        MessageDeduplicationId: core$1._toStr,
        MessageGroupId: core$1._toStr,
        MessageSystemAttributes: (_) => se_MessageBodySystemAttributeMap(_, context),
    });
};
const se_SendMessageBatchRequestEntryList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return se_SendMessageBatchRequestEntry(entry, context);
    });
};
const se_SendMessageRequest = (input, context) => {
    return smithyClient.take(input, {
        DelaySeconds: core$1._toNum,
        MessageAttributes: (_) => se_MessageBodyAttributeMap(_, context),
        MessageBody: core$1._toStr,
        MessageDeduplicationId: core$1._toStr,
        MessageGroupId: core$1._toStr,
        MessageSystemAttributes: (_) => se_MessageBodySystemAttributeMap(_, context),
        QueueUrl: core$1._toStr,
    });
};
const se_SetQueueAttributesRequest = (input, context) => {
    return smithyClient.take(input, {
        Attributes: (_) => se_QueueAttributeMap(_),
        QueueUrl: core$1._toStr,
    });
};
const se_StartMessageMoveTaskRequest = (input, context) => {
    return smithyClient.take(input, {
        DestinationArn: core$1._toStr,
        MaxNumberOfMessagesPerSecond: core$1._toNum,
        SourceArn: core$1._toStr,
    });
};
const se_StringList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_TagKeyList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return core$1._toStr(entry);
    });
};
const se_TagMap = (input, context) => {
    return Object.entries(input).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        acc[key] = core$1._toStr(value);
        return acc;
    }, {});
};
const se_TagQueueRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
        Tags: (_) => se_TagMap(_),
    });
};
const se_UntagQueueRequest = (input, context) => {
    return smithyClient.take(input, {
        QueueUrl: core$1._toStr,
        TagKeys: (_) => se_TagKeyList(_),
    });
};
const de_BinaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return context.base64Decoder(entry);
    });
    return retVal;
};
const de_Message = (output, context) => {
    return smithyClient.take(output, {
        Attributes: smithyClient._json,
        Body: smithyClient.expectString,
        MD5OfBody: smithyClient.expectString,
        MD5OfMessageAttributes: smithyClient.expectString,
        MessageAttributes: (_) => de_MessageBodyAttributeMap(_, context),
        MessageId: smithyClient.expectString,
        ReceiptHandle: smithyClient.expectString,
    });
};
const de_MessageAttributeValue = (output, context) => {
    return smithyClient.take(output, {
        BinaryListValues: (_) => de_BinaryList(_, context),
        BinaryValue: context.base64Decoder,
        DataType: smithyClient.expectString,
        StringListValues: smithyClient._json,
        StringValue: smithyClient.expectString,
    });
};
const de_MessageBodyAttributeMap = (output, context) => {
    return Object.entries(output).reduce((acc, [key, value]) => {
        if (value === null) {
            return acc;
        }
        acc[key] = de_MessageAttributeValue(value, context);
        return acc;
    }, {});
};
const de_MessageList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Message(entry, context);
    });
    return retVal;
};
const de_ReceiveMessageResult = (output, context) => {
    return smithyClient.take(output, {
        Messages: (_) => de_MessageList(_, context),
    });
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const throwDefaultError = smithyClient.withBaseException(SQSServiceException);
const buildHttpRpcRequest = async (context, headers, path, resolvedHostname, body) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const contents = {
        protocol,
        hostname,
        port,
        method: "POST",
        path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
        headers,
    };
    if (body !== undefined) {
        contents.body = body;
    }
    return new protocolHttp.HttpRequest(contents);
};
function sharedHeaders(operation) {
    return {
        "content-type": "application/x-amz-json-1.0",
        "x-amz-target": `AmazonSQS.${operation}`,
        "x-amzn-query-mode": "true",
    };
}
const populateBodyWithQueryCompatibility = (parsedOutput, headers) => {
    const queryErrorHeader = headers["x-amzn-query-error"];
    if (parsedOutput.body !== undefined && queryErrorHeader != null) {
        const [Code, Type] = queryErrorHeader.split(";");
        const entries = Object.entries(parsedOutput.body);
        const Error = {
            Type,
            Code,
        };
        Object.assign(parsedOutput.body, Error);
        for (const [k, v] of entries) {
            Error[k] = v;
        }
        delete Error.__type;
        parsedOutput.body.Error = Error;
    }
};

class AddPermissionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "AddPermission", {})
    .n("SQSClient", "AddPermissionCommand")
    .f(void 0, void 0)
    .ser(se_AddPermissionCommand)
    .de(de_AddPermissionCommand)
    .build() {
}

class CancelMessageMoveTaskCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "CancelMessageMoveTask", {})
    .n("SQSClient", "CancelMessageMoveTaskCommand")
    .f(void 0, void 0)
    .ser(se_CancelMessageMoveTaskCommand)
    .de(de_CancelMessageMoveTaskCommand)
    .build() {
}

class ChangeMessageVisibilityBatchCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "ChangeMessageVisibilityBatch", {})
    .n("SQSClient", "ChangeMessageVisibilityBatchCommand")
    .f(void 0, void 0)
    .ser(se_ChangeMessageVisibilityBatchCommand)
    .de(de_ChangeMessageVisibilityBatchCommand)
    .build() {
}

class ChangeMessageVisibilityCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "ChangeMessageVisibility", {})
    .n("SQSClient", "ChangeMessageVisibilityCommand")
    .f(void 0, void 0)
    .ser(se_ChangeMessageVisibilityCommand)
    .de(de_ChangeMessageVisibilityCommand)
    .build() {
}

class CreateQueueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "CreateQueue", {})
    .n("SQSClient", "CreateQueueCommand")
    .f(void 0, void 0)
    .ser(se_CreateQueueCommand)
    .de(de_CreateQueueCommand)
    .build() {
}

class DeleteMessageBatchCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "DeleteMessageBatch", {})
    .n("SQSClient", "DeleteMessageBatchCommand")
    .f(void 0, void 0)
    .ser(se_DeleteMessageBatchCommand)
    .de(de_DeleteMessageBatchCommand)
    .build() {
}

class DeleteMessageCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "DeleteMessage", {})
    .n("SQSClient", "DeleteMessageCommand")
    .f(void 0, void 0)
    .ser(se_DeleteMessageCommand)
    .de(de_DeleteMessageCommand)
    .build() {
}

class DeleteQueueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "DeleteQueue", {})
    .n("SQSClient", "DeleteQueueCommand")
    .f(void 0, void 0)
    .ser(se_DeleteQueueCommand)
    .de(de_DeleteQueueCommand)
    .build() {
}

class GetQueueAttributesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "GetQueueAttributes", {})
    .n("SQSClient", "GetQueueAttributesCommand")
    .f(void 0, void 0)
    .ser(se_GetQueueAttributesCommand)
    .de(de_GetQueueAttributesCommand)
    .build() {
}

class GetQueueUrlCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "GetQueueUrl", {})
    .n("SQSClient", "GetQueueUrlCommand")
    .f(void 0, void 0)
    .ser(se_GetQueueUrlCommand)
    .de(de_GetQueueUrlCommand)
    .build() {
}

class ListDeadLetterSourceQueuesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "ListDeadLetterSourceQueues", {})
    .n("SQSClient", "ListDeadLetterSourceQueuesCommand")
    .f(void 0, void 0)
    .ser(se_ListDeadLetterSourceQueuesCommand)
    .de(de_ListDeadLetterSourceQueuesCommand)
    .build() {
}

class ListMessageMoveTasksCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "ListMessageMoveTasks", {})
    .n("SQSClient", "ListMessageMoveTasksCommand")
    .f(void 0, void 0)
    .ser(se_ListMessageMoveTasksCommand)
    .de(de_ListMessageMoveTasksCommand)
    .build() {
}

class ListQueuesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "ListQueues", {})
    .n("SQSClient", "ListQueuesCommand")
    .f(void 0, void 0)
    .ser(se_ListQueuesCommand)
    .de(de_ListQueuesCommand)
    .build() {
}

class ListQueueTagsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "ListQueueTags", {})
    .n("SQSClient", "ListQueueTagsCommand")
    .f(void 0, void 0)
    .ser(se_ListQueueTagsCommand)
    .de(de_ListQueueTagsCommand)
    .build() {
}

class PurgeQueueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "PurgeQueue", {})
    .n("SQSClient", "PurgeQueueCommand")
    .f(void 0, void 0)
    .ser(se_PurgeQueueCommand)
    .de(de_PurgeQueueCommand)
    .build() {
}

class ReceiveMessageCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
        middlewareSdkSqs.getReceiveMessagePlugin(config),
    ];
})
    .s("AmazonSQS", "ReceiveMessage", {})
    .n("SQSClient", "ReceiveMessageCommand")
    .f(void 0, void 0)
    .ser(se_ReceiveMessageCommand)
    .de(de_ReceiveMessageCommand)
    .build() {
}

class RemovePermissionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "RemovePermission", {})
    .n("SQSClient", "RemovePermissionCommand")
    .f(void 0, void 0)
    .ser(se_RemovePermissionCommand)
    .de(de_RemovePermissionCommand)
    .build() {
}

class SendMessageBatchCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
        middlewareSdkSqs.getSendMessageBatchPlugin(config),
    ];
})
    .s("AmazonSQS", "SendMessageBatch", {})
    .n("SQSClient", "SendMessageBatchCommand")
    .f(void 0, void 0)
    .ser(se_SendMessageBatchCommand)
    .de(de_SendMessageBatchCommand)
    .build() {
}

class SendMessageCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
        middlewareSdkSqs.getSendMessagePlugin(config),
    ];
})
    .s("AmazonSQS", "SendMessage", {})
    .n("SQSClient", "SendMessageCommand")
    .f(void 0, void 0)
    .ser(se_SendMessageCommand)
    .de(de_SendMessageCommand)
    .build() {
}

class SetQueueAttributesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "SetQueueAttributes", {})
    .n("SQSClient", "SetQueueAttributesCommand")
    .f(void 0, void 0)
    .ser(se_SetQueueAttributesCommand)
    .de(de_SetQueueAttributesCommand)
    .build() {
}

class StartMessageMoveTaskCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "StartMessageMoveTask", {})
    .n("SQSClient", "StartMessageMoveTaskCommand")
    .f(void 0, void 0)
    .ser(se_StartMessageMoveTaskCommand)
    .de(de_StartMessageMoveTaskCommand)
    .build() {
}

class TagQueueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "TagQueue", {})
    .n("SQSClient", "TagQueueCommand")
    .f(void 0, void 0)
    .ser(se_TagQueueCommand)
    .de(de_TagQueueCommand)
    .build() {
}

class UntagQueueCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "UntagQueue", {})
    .n("SQSClient", "UntagQueueCommand")
    .f(void 0, void 0)
    .ser(se_UntagQueueCommand)
    .de(de_UntagQueueCommand)
    .build() {
}

const commands = {
    AddPermissionCommand,
    CancelMessageMoveTaskCommand,
    ChangeMessageVisibilityCommand,
    ChangeMessageVisibilityBatchCommand,
    CreateQueueCommand,
    DeleteMessageCommand,
    DeleteMessageBatchCommand,
    DeleteQueueCommand,
    GetQueueAttributesCommand,
    GetQueueUrlCommand,
    ListDeadLetterSourceQueuesCommand,
    ListMessageMoveTasksCommand,
    ListQueuesCommand,
    ListQueueTagsCommand,
    PurgeQueueCommand,
    ReceiveMessageCommand,
    RemovePermissionCommand,
    SendMessageCommand,
    SendMessageBatchCommand,
    SetQueueAttributesCommand,
    StartMessageMoveTaskCommand,
    TagQueueCommand,
    UntagQueueCommand,
};
class SQS extends SQSClient {
}
smithyClient.createAggregatedClient(commands, SQS);

const paginateListDeadLetterSourceQueues = core.createPaginator(SQSClient, ListDeadLetterSourceQueuesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListQueues = core.createPaginator(SQSClient, ListQueuesCommand, "NextToken", "NextToken", "MaxResults");

Object.defineProperty(exports, "$Command", {
    enumerable: true,
    get: function () { return smithyClient.Command; }
});
Object.defineProperty(exports, "__Client", {
    enumerable: true,
    get: function () { return smithyClient.Client; }
});
exports.AddPermissionCommand = AddPermissionCommand;
exports.BatchEntryIdsNotDistinct = BatchEntryIdsNotDistinct;
exports.BatchRequestTooLong = BatchRequestTooLong;
exports.CancelMessageMoveTaskCommand = CancelMessageMoveTaskCommand;
exports.ChangeMessageVisibilityBatchCommand = ChangeMessageVisibilityBatchCommand;
exports.ChangeMessageVisibilityCommand = ChangeMessageVisibilityCommand;
exports.CreateQueueCommand = CreateQueueCommand;
exports.DeleteMessageBatchCommand = DeleteMessageBatchCommand;
exports.DeleteMessageCommand = DeleteMessageCommand;
exports.DeleteQueueCommand = DeleteQueueCommand;
exports.EmptyBatchRequest = EmptyBatchRequest;
exports.GetQueueAttributesCommand = GetQueueAttributesCommand;
exports.GetQueueUrlCommand = GetQueueUrlCommand;
exports.InvalidAddress = InvalidAddress;
exports.InvalidAttributeName = InvalidAttributeName;
exports.InvalidAttributeValue = InvalidAttributeValue;
exports.InvalidBatchEntryId = InvalidBatchEntryId;
exports.InvalidIdFormat = InvalidIdFormat;
exports.InvalidMessageContents = InvalidMessageContents;
exports.InvalidSecurity = InvalidSecurity;
exports.KmsAccessDenied = KmsAccessDenied;
exports.KmsDisabled = KmsDisabled;
exports.KmsInvalidKeyUsage = KmsInvalidKeyUsage;
exports.KmsInvalidState = KmsInvalidState;
exports.KmsNotFound = KmsNotFound;
exports.KmsOptInRequired = KmsOptInRequired;
exports.KmsThrottled = KmsThrottled;
exports.ListDeadLetterSourceQueuesCommand = ListDeadLetterSourceQueuesCommand;
exports.ListMessageMoveTasksCommand = ListMessageMoveTasksCommand;
exports.ListQueueTagsCommand = ListQueueTagsCommand;
exports.ListQueuesCommand = ListQueuesCommand;
exports.MessageNotInflight = MessageNotInflight;
exports.MessageSystemAttributeName = MessageSystemAttributeName;
exports.MessageSystemAttributeNameForSends = MessageSystemAttributeNameForSends;
exports.OverLimit = OverLimit;
exports.PurgeQueueCommand = PurgeQueueCommand;
exports.PurgeQueueInProgress = PurgeQueueInProgress;
exports.QueueAttributeName = QueueAttributeName;
exports.QueueDeletedRecently = QueueDeletedRecently;
exports.QueueDoesNotExist = QueueDoesNotExist;
exports.QueueNameExists = QueueNameExists;
exports.ReceiptHandleIsInvalid = ReceiptHandleIsInvalid;
exports.ReceiveMessageCommand = ReceiveMessageCommand;
exports.RemovePermissionCommand = RemovePermissionCommand;
exports.RequestThrottled = RequestThrottled;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.SQS = SQS;
exports.SQSClient = SQSClient;
exports.SQSServiceException = SQSServiceException;
exports.SendMessageBatchCommand = SendMessageBatchCommand;
exports.SendMessageCommand = SendMessageCommand;
exports.SetQueueAttributesCommand = SetQueueAttributesCommand;
exports.StartMessageMoveTaskCommand = StartMessageMoveTaskCommand;
exports.TagQueueCommand = TagQueueCommand;
exports.TooManyEntriesInBatchRequest = TooManyEntriesInBatchRequest;
exports.UnsupportedOperation = UnsupportedOperation;
exports.UntagQueueCommand = UntagQueueCommand;
exports.paginateListDeadLetterSourceQueues = paginateListDeadLetterSourceQueues;
exports.paginateListQueues = paginateListQueues;

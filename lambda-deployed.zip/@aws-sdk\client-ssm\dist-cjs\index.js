'use strict';

var middlewareHostHeader = require('@aws-sdk/middleware-host-header');
var middlewareLogger = require('@aws-sdk/middleware-logger');
var middlewareRecursionDetection = require('@aws-sdk/middleware-recursion-detection');
var middlewareUserAgent = require('@aws-sdk/middleware-user-agent');
var configResolver = require('@smithy/config-resolver');
var core = require('@smithy/core');
var middlewareContentLength = require('@smithy/middleware-content-length');
var middlewareEndpoint = require('@smithy/middleware-endpoint');
var middlewareRetry = require('@smithy/middleware-retry');
var smithyClient = require('@smithy/smithy-client');
var httpAuthSchemeProvider = require('./auth/httpAuthSchemeProvider');
var runtimeConfig = require('./runtimeConfig');
var regionConfigResolver = require('@aws-sdk/region-config-resolver');
var protocolHttp = require('@smithy/protocol-http');
var middlewareSerde = require('@smithy/middleware-serde');
var core$1 = require('@aws-sdk/core');
var uuid = require('@smithy/uuid');
var utilWaiter = require('@smithy/util-waiter');

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "ssm",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(regionConfigResolver.getAwsRegionExtensionConfiguration(runtimeConfig), smithyClient.getDefaultExtensionConfiguration(runtimeConfig), protocolHttp.getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, regionConfigResolver.resolveAwsRegionExtensionConfiguration(extensionConfiguration), smithyClient.resolveDefaultRuntimeConfig(extensionConfiguration), protocolHttp.resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class SSMClient extends smithyClient.Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = runtimeConfig.getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = middlewareUserAgent.resolveUserAgentConfig(_config_1);
        const _config_3 = middlewareRetry.resolveRetryConfig(_config_2);
        const _config_4 = configResolver.resolveRegionConfig(_config_3);
        const _config_5 = middlewareHostHeader.resolveHostHeaderConfig(_config_4);
        const _config_6 = middlewareEndpoint.resolveEndpointConfig(_config_5);
        const _config_7 = httpAuthSchemeProvider.resolveHttpAuthSchemeConfig(_config_6);
        const _config_8 = resolveRuntimeExtensions(_config_7, configuration?.extensions || []);
        this.config = _config_8;
        this.middlewareStack.use(middlewareUserAgent.getUserAgentPlugin(this.config));
        this.middlewareStack.use(middlewareRetry.getRetryPlugin(this.config));
        this.middlewareStack.use(middlewareContentLength.getContentLengthPlugin(this.config));
        this.middlewareStack.use(middlewareHostHeader.getHostHeaderPlugin(this.config));
        this.middlewareStack.use(middlewareLogger.getLoggerPlugin(this.config));
        this.middlewareStack.use(middlewareRecursionDetection.getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(core.getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: httpAuthSchemeProvider.defaultSSMHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new core.DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(core.getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

class SSMServiceException extends smithyClient.ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, SSMServiceException.prototype);
    }
}

class AccessDeniedException extends SSMServiceException {
    name = "AccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
const AccessRequestStatus = {
    APPROVED: "Approved",
    EXPIRED: "Expired",
    PENDING: "Pending",
    REJECTED: "Rejected",
    REVOKED: "Revoked",
};
const AccessType = {
    JUSTINTIME: "JustInTime",
    STANDARD: "Standard",
};
const ResourceTypeForTagging = {
    ASSOCIATION: "Association",
    AUTOMATION: "Automation",
    DOCUMENT: "Document",
    MAINTENANCE_WINDOW: "MaintenanceWindow",
    MANAGED_INSTANCE: "ManagedInstance",
    OPSMETADATA: "OpsMetadata",
    OPS_ITEM: "OpsItem",
    PARAMETER: "Parameter",
    PATCH_BASELINE: "PatchBaseline",
};
class InternalServerError extends SSMServiceException {
    name = "InternalServerError";
    $fault = "server";
    Message;
    constructor(opts) {
        super({
            name: "InternalServerError",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerError.prototype);
        this.Message = opts.Message;
    }
}
class InvalidResourceId extends SSMServiceException {
    name = "InvalidResourceId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidResourceId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidResourceId.prototype);
    }
}
class InvalidResourceType extends SSMServiceException {
    name = "InvalidResourceType";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidResourceType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidResourceType.prototype);
    }
}
class TooManyTagsError extends SSMServiceException {
    name = "TooManyTagsError";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TooManyTagsError",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TooManyTagsError.prototype);
    }
}
class TooManyUpdates extends SSMServiceException {
    name = "TooManyUpdates";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TooManyUpdates",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TooManyUpdates.prototype);
        this.Message = opts.Message;
    }
}
const ExternalAlarmState = {
    ALARM: "ALARM",
    UNKNOWN: "UNKNOWN",
};
class AlreadyExistsException extends SSMServiceException {
    name = "AlreadyExistsException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AlreadyExistsException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemConflictException extends SSMServiceException {
    name = "OpsItemConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemConflictException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemInvalidParameterException extends SSMServiceException {
    name = "OpsItemInvalidParameterException";
    $fault = "client";
    ParameterNames;
    Message;
    constructor(opts) {
        super({
            name: "OpsItemInvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemInvalidParameterException.prototype);
        this.ParameterNames = opts.ParameterNames;
        this.Message = opts.Message;
    }
}
class OpsItemLimitExceededException extends SSMServiceException {
    name = "OpsItemLimitExceededException";
    $fault = "client";
    ResourceTypes;
    Limit;
    LimitType;
    Message;
    constructor(opts) {
        super({
            name: "OpsItemLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemLimitExceededException.prototype);
        this.ResourceTypes = opts.ResourceTypes;
        this.Limit = opts.Limit;
        this.LimitType = opts.LimitType;
        this.Message = opts.Message;
    }
}
class OpsItemNotFoundException extends SSMServiceException {
    name = "OpsItemNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemRelatedItemAlreadyExistsException extends SSMServiceException {
    name = "OpsItemRelatedItemAlreadyExistsException";
    $fault = "client";
    Message;
    ResourceUri;
    OpsItemId;
    constructor(opts) {
        super({
            name: "OpsItemRelatedItemAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemRelatedItemAlreadyExistsException.prototype);
        this.Message = opts.Message;
        this.ResourceUri = opts.ResourceUri;
        this.OpsItemId = opts.OpsItemId;
    }
}
class DuplicateInstanceId extends SSMServiceException {
    name = "DuplicateInstanceId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "DuplicateInstanceId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateInstanceId.prototype);
    }
}
class InvalidCommandId extends SSMServiceException {
    name = "InvalidCommandId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidCommandId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidCommandId.prototype);
    }
}
class InvalidInstanceId extends SSMServiceException {
    name = "InvalidInstanceId";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInstanceId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInstanceId.prototype);
        this.Message = opts.Message;
    }
}
class DoesNotExistException extends SSMServiceException {
    name = "DoesNotExistException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DoesNotExistException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DoesNotExistException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidParameters extends SSMServiceException {
    name = "InvalidParameters";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidParameters",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidParameters.prototype);
        this.Message = opts.Message;
    }
}
class AssociationAlreadyExists extends SSMServiceException {
    name = "AssociationAlreadyExists";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AssociationAlreadyExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationAlreadyExists.prototype);
    }
}
class AssociationLimitExceeded extends SSMServiceException {
    name = "AssociationLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AssociationLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationLimitExceeded.prototype);
    }
}
const AssociationComplianceSeverity = {
    Critical: "CRITICAL",
    High: "HIGH",
    Low: "LOW",
    Medium: "MEDIUM",
    Unspecified: "UNSPECIFIED",
};
const AssociationSyncCompliance = {
    Auto: "AUTO",
    Manual: "MANUAL",
};
const AssociationStatusName = {
    Failed: "Failed",
    Pending: "Pending",
    Success: "Success",
};
class InvalidDocument extends SSMServiceException {
    name = "InvalidDocument";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocument",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocument.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDocumentVersion extends SSMServiceException {
    name = "InvalidDocumentVersion";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentVersion",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentVersion.prototype);
        this.Message = opts.Message;
    }
}
class InvalidOutputLocation extends SSMServiceException {
    name = "InvalidOutputLocation";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidOutputLocation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidOutputLocation.prototype);
    }
}
class InvalidSchedule extends SSMServiceException {
    name = "InvalidSchedule";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidSchedule",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidSchedule.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTag extends SSMServiceException {
    name = "InvalidTag";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTag",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTag.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTarget extends SSMServiceException {
    name = "InvalidTarget";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTarget",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTarget.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTargetMaps extends SSMServiceException {
    name = "InvalidTargetMaps";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTargetMaps",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTargetMaps.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedPlatformType extends SSMServiceException {
    name = "UnsupportedPlatformType";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedPlatformType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedPlatformType.prototype);
        this.Message = opts.Message;
    }
}
const Fault = {
    Client: "Client",
    Server: "Server",
    Unknown: "Unknown",
};
const AttachmentsSourceKey = {
    AttachmentReference: "AttachmentReference",
    S3FileUrl: "S3FileUrl",
    SourceUrl: "SourceUrl",
};
const DocumentFormat = {
    JSON: "JSON",
    TEXT: "TEXT",
    YAML: "YAML",
};
const DocumentType = {
    ApplicationConfiguration: "ApplicationConfiguration",
    ApplicationConfigurationSchema: "ApplicationConfigurationSchema",
    AutoApprovalPolicy: "AutoApprovalPolicy",
    Automation: "Automation",
    ChangeCalendar: "ChangeCalendar",
    ChangeTemplate: "Automation.ChangeTemplate",
    CloudFormation: "CloudFormation",
    Command: "Command",
    ConformancePackTemplate: "ConformancePackTemplate",
    DeploymentStrategy: "DeploymentStrategy",
    ManualApprovalPolicy: "ManualApprovalPolicy",
    Package: "Package",
    Policy: "Policy",
    ProblemAnalysis: "ProblemAnalysis",
    ProblemAnalysisTemplate: "ProblemAnalysisTemplate",
    QuickSetup: "QuickSetup",
    Session: "Session",
};
const DocumentHashType = {
    SHA1: "Sha1",
    SHA256: "Sha256",
};
const DocumentParameterType = {
    String: "String",
    StringList: "StringList",
};
const PlatformType = {
    LINUX: "Linux",
    MACOS: "MacOS",
    WINDOWS: "Windows",
};
const ReviewStatus = {
    APPROVED: "APPROVED",
    NOT_REVIEWED: "NOT_REVIEWED",
    PENDING: "PENDING",
    REJECTED: "REJECTED",
};
const DocumentStatus = {
    Active: "Active",
    Creating: "Creating",
    Deleting: "Deleting",
    Failed: "Failed",
    Updating: "Updating",
};
class DocumentAlreadyExists extends SSMServiceException {
    name = "DocumentAlreadyExists";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentAlreadyExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentAlreadyExists.prototype);
        this.Message = opts.Message;
    }
}
class DocumentLimitExceeded extends SSMServiceException {
    name = "DocumentLimitExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentLimitExceeded.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDocumentContent extends SSMServiceException {
    name = "InvalidDocumentContent";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentContent",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentContent.prototype);
        this.Message = opts.Message;
    }
}
class InvalidDocumentSchemaVersion extends SSMServiceException {
    name = "InvalidDocumentSchemaVersion";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentSchemaVersion",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentSchemaVersion.prototype);
        this.Message = opts.Message;
    }
}
class MaxDocumentSizeExceeded extends SSMServiceException {
    name = "MaxDocumentSizeExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "MaxDocumentSizeExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, MaxDocumentSizeExceeded.prototype);
        this.Message = opts.Message;
    }
}
class IdempotentParameterMismatch extends SSMServiceException {
    name = "IdempotentParameterMismatch";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "IdempotentParameterMismatch",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IdempotentParameterMismatch.prototype);
        this.Message = opts.Message;
    }
}
class ResourceLimitExceededException extends SSMServiceException {
    name = "ResourceLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
const OpsItemDataType = {
    SEARCHABLE_STRING: "SearchableString",
    STRING: "String",
};
class OpsItemAccessDeniedException extends SSMServiceException {
    name = "OpsItemAccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemAccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemAccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
class OpsItemAlreadyExistsException extends SSMServiceException {
    name = "OpsItemAlreadyExistsException";
    $fault = "client";
    Message;
    OpsItemId;
    constructor(opts) {
        super({
            name: "OpsItemAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemAlreadyExistsException.prototype);
        this.Message = opts.Message;
        this.OpsItemId = opts.OpsItemId;
    }
}
class OpsMetadataAlreadyExistsException extends SSMServiceException {
    name = "OpsMetadataAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataAlreadyExistsException.prototype);
    }
}
class OpsMetadataInvalidArgumentException extends SSMServiceException {
    name = "OpsMetadataInvalidArgumentException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataInvalidArgumentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataInvalidArgumentException.prototype);
    }
}
class OpsMetadataLimitExceededException extends SSMServiceException {
    name = "OpsMetadataLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataLimitExceededException.prototype);
    }
}
class OpsMetadataTooManyUpdatesException extends SSMServiceException {
    name = "OpsMetadataTooManyUpdatesException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataTooManyUpdatesException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataTooManyUpdatesException.prototype);
    }
}
const PatchComplianceLevel = {
    Critical: "CRITICAL",
    High: "HIGH",
    Informational: "INFORMATIONAL",
    Low: "LOW",
    Medium: "MEDIUM",
    Unspecified: "UNSPECIFIED",
};
const PatchFilterKey = {
    AdvisoryId: "ADVISORY_ID",
    Arch: "ARCH",
    BugzillaId: "BUGZILLA_ID",
    CVEId: "CVE_ID",
    Classification: "CLASSIFICATION",
    Epoch: "EPOCH",
    MsrcSeverity: "MSRC_SEVERITY",
    Name: "NAME",
    PatchId: "PATCH_ID",
    PatchSet: "PATCH_SET",
    Priority: "PRIORITY",
    Product: "PRODUCT",
    ProductFamily: "PRODUCT_FAMILY",
    Release: "RELEASE",
    Repository: "REPOSITORY",
    Section: "SECTION",
    Security: "SECURITY",
    Severity: "SEVERITY",
    Version: "VERSION",
};
const PatchComplianceStatus = {
    Compliant: "COMPLIANT",
    NonCompliant: "NON_COMPLIANT",
};
const OperatingSystem = {
    AlmaLinux: "ALMA_LINUX",
    AmazonLinux: "AMAZON_LINUX",
    AmazonLinux2: "AMAZON_LINUX_2",
    AmazonLinux2022: "AMAZON_LINUX_2022",
    AmazonLinux2023: "AMAZON_LINUX_2023",
    CentOS: "CENTOS",
    Debian: "DEBIAN",
    MacOS: "MACOS",
    OracleLinux: "ORACLE_LINUX",
    Raspbian: "RASPBIAN",
    RedhatEnterpriseLinux: "REDHAT_ENTERPRISE_LINUX",
    Rocky_Linux: "ROCKY_LINUX",
    Suse: "SUSE",
    Ubuntu: "UBUNTU",
    Windows: "WINDOWS",
};
const PatchAction = {
    AllowAsDependency: "ALLOW_AS_DEPENDENCY",
    Block: "BLOCK",
};
const ResourceDataSyncS3Format = {
    JSON_SERDE: "JsonSerDe",
};
class ResourceDataSyncAlreadyExistsException extends SSMServiceException {
    name = "ResourceDataSyncAlreadyExistsException";
    $fault = "client";
    SyncName;
    constructor(opts) {
        super({
            name: "ResourceDataSyncAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncAlreadyExistsException.prototype);
        this.SyncName = opts.SyncName;
    }
}
class ResourceDataSyncCountExceededException extends SSMServiceException {
    name = "ResourceDataSyncCountExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncCountExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncCountExceededException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceDataSyncInvalidConfigurationException extends SSMServiceException {
    name = "ResourceDataSyncInvalidConfigurationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncInvalidConfigurationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncInvalidConfigurationException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidActivation extends SSMServiceException {
    name = "InvalidActivation";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidActivation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidActivation.prototype);
        this.Message = opts.Message;
    }
}
class InvalidActivationId extends SSMServiceException {
    name = "InvalidActivationId";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidActivationId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidActivationId.prototype);
        this.Message = opts.Message;
    }
}
class AssociationDoesNotExist extends SSMServiceException {
    name = "AssociationDoesNotExist";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AssociationDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationDoesNotExist.prototype);
        this.Message = opts.Message;
    }
}
class AssociatedInstances extends SSMServiceException {
    name = "AssociatedInstances";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AssociatedInstances",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociatedInstances.prototype);
    }
}
class InvalidDocumentOperation extends SSMServiceException {
    name = "InvalidDocumentOperation";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentOperation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentOperation.prototype);
        this.Message = opts.Message;
    }
}
const InventorySchemaDeleteOption = {
    DELETE_SCHEMA: "DeleteSchema",
    DISABLE_SCHEMA: "DisableSchema",
};
class InvalidDeleteInventoryParametersException extends SSMServiceException {
    name = "InvalidDeleteInventoryParametersException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDeleteInventoryParametersException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDeleteInventoryParametersException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInventoryRequestException extends SSMServiceException {
    name = "InvalidInventoryRequestException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInventoryRequestException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInventoryRequestException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidOptionException extends SSMServiceException {
    name = "InvalidOptionException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidOptionException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidOptionException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidTypeNameException extends SSMServiceException {
    name = "InvalidTypeNameException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidTypeNameException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidTypeNameException.prototype);
        this.Message = opts.Message;
    }
}
class OpsMetadataNotFoundException extends SSMServiceException {
    name = "OpsMetadataNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataNotFoundException.prototype);
    }
}
class ParameterNotFound extends SSMServiceException {
    name = "ParameterNotFound";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterNotFound.prototype);
    }
}
class ResourceInUseException extends SSMServiceException {
    name = "ResourceInUseException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceInUseException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceDataSyncNotFoundException extends SSMServiceException {
    name = "ResourceDataSyncNotFoundException";
    $fault = "client";
    SyncName;
    SyncType;
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncNotFoundException.prototype);
        this.SyncName = opts.SyncName;
        this.SyncType = opts.SyncType;
        this.Message = opts.Message;
    }
}
class MalformedResourcePolicyDocumentException extends SSMServiceException {
    name = "MalformedResourcePolicyDocumentException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "MalformedResourcePolicyDocumentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, MalformedResourcePolicyDocumentException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceNotFoundException extends SSMServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class ResourcePolicyConflictException extends SSMServiceException {
    name = "ResourcePolicyConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyConflictException.prototype);
        this.Message = opts.Message;
    }
}
class ResourcePolicyInvalidParameterException extends SSMServiceException {
    name = "ResourcePolicyInvalidParameterException";
    $fault = "client";
    ParameterNames;
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyInvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyInvalidParameterException.prototype);
        this.ParameterNames = opts.ParameterNames;
        this.Message = opts.Message;
    }
}
class ResourcePolicyNotFoundException extends SSMServiceException {
    name = "ResourcePolicyNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class TargetInUseException extends SSMServiceException {
    name = "TargetInUseException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TargetInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TargetInUseException.prototype);
        this.Message = opts.Message;
    }
}
const DescribeActivationsFilterKeys = {
    ACTIVATION_IDS: "ActivationIds",
    DEFAULT_INSTANCE_NAME: "DefaultInstanceName",
    IAM_ROLE: "IamRole",
};
class InvalidFilter extends SSMServiceException {
    name = "InvalidFilter";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidFilter",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilter.prototype);
        this.Message = opts.Message;
    }
}
class InvalidNextToken extends SSMServiceException {
    name = "InvalidNextToken";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidNextToken",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidNextToken.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAssociationVersion extends SSMServiceException {
    name = "InvalidAssociationVersion";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAssociationVersion",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAssociationVersion.prototype);
        this.Message = opts.Message;
    }
}
const AssociationExecutionFilterKey = {
    CreatedTime: "CreatedTime",
    ExecutionId: "ExecutionId",
    Status: "Status",
};
const AssociationFilterOperatorType = {
    Equal: "EQUAL",
    GreaterThan: "GREATER_THAN",
    LessThan: "LESS_THAN",
};
class AssociationExecutionDoesNotExist extends SSMServiceException {
    name = "AssociationExecutionDoesNotExist";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AssociationExecutionDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationExecutionDoesNotExist.prototype);
        this.Message = opts.Message;
    }
}
const AssociationExecutionTargetsFilterKey = {
    ResourceId: "ResourceId",
    ResourceType: "ResourceType",
    Status: "Status",
};
const AutomationExecutionFilterKey = {
    AUTOMATION_SUBTYPE: "AutomationSubtype",
    AUTOMATION_TYPE: "AutomationType",
    CURRENT_ACTION: "CurrentAction",
    DOCUMENT_NAME_PREFIX: "DocumentNamePrefix",
    EXECUTION_ID: "ExecutionId",
    EXECUTION_STATUS: "ExecutionStatus",
    OPS_ITEM_ID: "OpsItemId",
    PARENT_EXECUTION_ID: "ParentExecutionId",
    START_TIME_AFTER: "StartTimeAfter",
    START_TIME_BEFORE: "StartTimeBefore",
    TAG_KEY: "TagKey",
    TARGET_RESOURCE_GROUP: "TargetResourceGroup",
};
const AutomationExecutionStatus = {
    APPROVED: "Approved",
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    CHANGE_CALENDAR_OVERRIDE_APPROVED: "ChangeCalendarOverrideApproved",
    CHANGE_CALENDAR_OVERRIDE_REJECTED: "ChangeCalendarOverrideRejected",
    COMPLETED_WITH_FAILURE: "CompletedWithFailure",
    COMPLETED_WITH_SUCCESS: "CompletedWithSuccess",
    EXITED: "Exited",
    FAILED: "Failed",
    INPROGRESS: "InProgress",
    PENDING: "Pending",
    PENDING_APPROVAL: "PendingApproval",
    PENDING_CHANGE_CALENDAR_OVERRIDE: "PendingChangeCalendarOverride",
    REJECTED: "Rejected",
    RUNBOOK_INPROGRESS: "RunbookInProgress",
    SCHEDULED: "Scheduled",
    SUCCESS: "Success",
    TIMEDOUT: "TimedOut",
    WAITING: "Waiting",
};
const AutomationSubtype = {
    AccessRequest: "AccessRequest",
    ChangeRequest: "ChangeRequest",
};
const AutomationType = {
    CrossAccount: "CrossAccount",
    Local: "Local",
};
const ExecutionMode = {
    Auto: "Auto",
    Interactive: "Interactive",
};
class InvalidFilterKey extends SSMServiceException {
    name = "InvalidFilterKey";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidFilterKey",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilterKey.prototype);
    }
}
class InvalidFilterValue extends SSMServiceException {
    name = "InvalidFilterValue";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidFilterValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilterValue.prototype);
        this.Message = opts.Message;
    }
}
class AutomationExecutionNotFoundException extends SSMServiceException {
    name = "AutomationExecutionNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationExecutionNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationExecutionNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
const StepExecutionFilterKey = {
    ACTION: "Action",
    PARENT_STEP_EXECUTION_ID: "ParentStepExecutionId",
    PARENT_STEP_ITERATION: "ParentStepIteration",
    PARENT_STEP_ITERATOR_VALUE: "ParentStepIteratorValue",
    START_TIME_AFTER: "StartTimeAfter",
    START_TIME_BEFORE: "StartTimeBefore",
    STEP_EXECUTION_ID: "StepExecutionId",
    STEP_EXECUTION_STATUS: "StepExecutionStatus",
    STEP_NAME: "StepName",
};
const DocumentPermissionType = {
    SHARE: "Share",
};
class InvalidPermissionType extends SSMServiceException {
    name = "InvalidPermissionType";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidPermissionType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPermissionType.prototype);
        this.Message = opts.Message;
    }
}
const PatchDeploymentStatus = {
    Approved: "APPROVED",
    ExplicitApproved: "EXPLICIT_APPROVED",
    ExplicitRejected: "EXPLICIT_REJECTED",
    PendingApproval: "PENDING_APPROVAL",
};
class UnsupportedOperatingSystem extends SSMServiceException {
    name = "UnsupportedOperatingSystem";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedOperatingSystem",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedOperatingSystem.prototype);
        this.Message = opts.Message;
    }
}
const InstanceInformationFilterKey = {
    ACTIVATION_IDS: "ActivationIds",
    AGENT_VERSION: "AgentVersion",
    ASSOCIATION_STATUS: "AssociationStatus",
    IAM_ROLE: "IamRole",
    INSTANCE_IDS: "InstanceIds",
    PING_STATUS: "PingStatus",
    PLATFORM_TYPES: "PlatformTypes",
    RESOURCE_TYPE: "ResourceType",
};
const PingStatus = {
    CONNECTION_LOST: "ConnectionLost",
    INACTIVE: "Inactive",
    ONLINE: "Online",
};
const ResourceType = {
    EC2_INSTANCE: "EC2Instance",
    MANAGED_INSTANCE: "ManagedInstance",
};
const SourceType = {
    AWS_EC2_INSTANCE: "AWS::EC2::Instance",
    AWS_IOT_THING: "AWS::IoT::Thing",
    AWS_SSM_MANAGEDINSTANCE: "AWS::SSM::ManagedInstance",
};
class InvalidInstanceInformationFilterValue extends SSMServiceException {
    name = "InvalidInstanceInformationFilterValue";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidInstanceInformationFilterValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInstanceInformationFilterValue.prototype);
    }
}
const PatchComplianceDataState = {
    AvailableSecurityUpdate: "AVAILABLE_SECURITY_UPDATE",
    Failed: "FAILED",
    Installed: "INSTALLED",
    InstalledOther: "INSTALLED_OTHER",
    InstalledPendingReboot: "INSTALLED_PENDING_REBOOT",
    InstalledRejected: "INSTALLED_REJECTED",
    Missing: "MISSING",
    NotApplicable: "NOT_APPLICABLE",
};
const PatchOperationType = {
    INSTALL: "Install",
    SCAN: "Scan",
};
const RebootOption = {
    NO_REBOOT: "NoReboot",
    REBOOT_IF_NEEDED: "RebootIfNeeded",
};
const InstancePatchStateOperatorType = {
    EQUAL: "Equal",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
const InstancePropertyFilterOperator = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
const InstancePropertyFilterKey = {
    ACTIVATION_IDS: "ActivationIds",
    AGENT_VERSION: "AgentVersion",
    ASSOCIATION_STATUS: "AssociationStatus",
    DOCUMENT_NAME: "DocumentName",
    IAM_ROLE: "IamRole",
    INSTANCE_IDS: "InstanceIds",
    PING_STATUS: "PingStatus",
    PLATFORM_TYPES: "PlatformTypes",
    RESOURCE_TYPE: "ResourceType",
};
class InvalidInstancePropertyFilterValue extends SSMServiceException {
    name = "InvalidInstancePropertyFilterValue";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidInstancePropertyFilterValue",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInstancePropertyFilterValue.prototype);
    }
}
const InventoryDeletionStatus = {
    COMPLETE: "Complete",
    IN_PROGRESS: "InProgress",
};
class InvalidDeletionIdException extends SSMServiceException {
    name = "InvalidDeletionIdException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDeletionIdException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDeletionIdException.prototype);
        this.Message = opts.Message;
    }
}
const MaintenanceWindowExecutionStatus = {
    Cancelled: "CANCELLED",
    Cancelling: "CANCELLING",
    Failed: "FAILED",
    InProgress: "IN_PROGRESS",
    Pending: "PENDING",
    SkippedOverlapping: "SKIPPED_OVERLAPPING",
    Success: "SUCCESS",
    TimedOut: "TIMED_OUT",
};
const MaintenanceWindowTaskType = {
    Automation: "AUTOMATION",
    Lambda: "LAMBDA",
    RunCommand: "RUN_COMMAND",
    StepFunctions: "STEP_FUNCTIONS",
};
const CreateAssociationRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const AssociationDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const CreateAssociationResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.AssociationDescription && {
        AssociationDescription: AssociationDescriptionFilterSensitiveLog(obj.AssociationDescription),
    }),
});
const CreateAssociationBatchRequestEntryFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const CreateAssociationBatchRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Entries && {
        Entries: obj.Entries.map((item) => CreateAssociationBatchRequestEntryFilterSensitiveLog(item)),
    }),
});
const FailedCreateAssociationFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Entry && { Entry: CreateAssociationBatchRequestEntryFilterSensitiveLog(obj.Entry) }),
});
const CreateAssociationBatchResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Successful && { Successful: obj.Successful.map((item) => AssociationDescriptionFilterSensitiveLog(item)) }),
    ...(obj.Failed && { Failed: obj.Failed.map((item) => FailedCreateAssociationFilterSensitiveLog(item)) }),
});
const CreateMaintenanceWindowRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const PatchSourceFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Configuration && { Configuration: smithyClient.SENSITIVE_STRING }),
});
const CreatePatchBaselineRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Sources && { Sources: obj.Sources.map((item) => PatchSourceFilterSensitiveLog(item)) }),
});
const DescribeAssociationResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.AssociationDescription && {
        AssociationDescription: AssociationDescriptionFilterSensitiveLog(obj.AssociationDescription),
    }),
});
const InstanceInformationFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.IPAddress && { IPAddress: smithyClient.SENSITIVE_STRING }),
});
const DescribeInstanceInformationResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.InstanceInformationList && {
        InstanceInformationList: obj.InstanceInformationList.map((item) => InstanceInformationFilterSensitiveLog(item)),
    }),
});
const InstancePatchStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
});
const DescribeInstancePatchStatesResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.InstancePatchStates && {
        InstancePatchStates: obj.InstancePatchStates.map((item) => InstancePatchStateFilterSensitiveLog(item)),
    }),
});
const DescribeInstancePatchStatesForPatchGroupResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.InstancePatchStates && {
        InstancePatchStates: obj.InstancePatchStates.map((item) => InstancePatchStateFilterSensitiveLog(item)),
    }),
});
const InstancePropertyFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.IPAddress && { IPAddress: smithyClient.SENSITIVE_STRING }),
});
const DescribeInstancePropertiesResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.InstanceProperties && {
        InstanceProperties: obj.InstanceProperties.map((item) => InstancePropertyFilterSensitiveLog(item)),
    }),
});
const MaintenanceWindowExecutionTaskInvocationIdentityFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
});
const DescribeMaintenanceWindowExecutionTaskInvocationsResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.WindowExecutionTaskInvocationIdentities && {
        WindowExecutionTaskInvocationIdentities: obj.WindowExecutionTaskInvocationIdentities.map((item) => MaintenanceWindowExecutionTaskInvocationIdentityFilterSensitiveLog(item)),
    }),
});
const MaintenanceWindowIdentityFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});

const MaintenanceWindowResourceType = {
    Instance: "INSTANCE",
    ResourceGroup: "RESOURCE_GROUP",
};
const MaintenanceWindowTaskCutoffBehavior = {
    CancelTask: "CANCEL_TASK",
    ContinueTask: "CONTINUE_TASK",
};
const OpsItemFilterKey = {
    ACCESS_REQUEST_APPROVER_ARN: "AccessRequestByApproverArn",
    ACCESS_REQUEST_APPROVER_ID: "AccessRequestByApproverId",
    ACCESS_REQUEST_IS_REPLICA: "AccessRequestByIsReplica",
    ACCESS_REQUEST_REQUESTER_ARN: "AccessRequestByRequesterArn",
    ACCESS_REQUEST_REQUESTER_ID: "AccessRequestByRequesterId",
    ACCESS_REQUEST_SOURCE_ACCOUNT_ID: "AccessRequestBySourceAccountId",
    ACCESS_REQUEST_SOURCE_OPS_ITEM_ID: "AccessRequestBySourceOpsItemId",
    ACCESS_REQUEST_SOURCE_REGION: "AccessRequestBySourceRegion",
    ACCESS_REQUEST_TARGET_RESOURCE_ID: "AccessRequestByTargetResourceId",
    ACCOUNT_ID: "AccountId",
    ACTUAL_END_TIME: "ActualEndTime",
    ACTUAL_START_TIME: "ActualStartTime",
    AUTOMATION_ID: "AutomationId",
    CATEGORY: "Category",
    CHANGE_REQUEST_APPROVER_ARN: "ChangeRequestByApproverArn",
    CHANGE_REQUEST_APPROVER_NAME: "ChangeRequestByApproverName",
    CHANGE_REQUEST_REQUESTER_ARN: "ChangeRequestByRequesterArn",
    CHANGE_REQUEST_REQUESTER_NAME: "ChangeRequestByRequesterName",
    CHANGE_REQUEST_TARGETS_RESOURCE_GROUP: "ChangeRequestByTargetsResourceGroup",
    CHANGE_REQUEST_TEMPLATE: "ChangeRequestByTemplate",
    CREATED_BY: "CreatedBy",
    CREATED_TIME: "CreatedTime",
    INSIGHT_TYPE: "InsightByType",
    LAST_MODIFIED_TIME: "LastModifiedTime",
    OPERATIONAL_DATA: "OperationalData",
    OPERATIONAL_DATA_KEY: "OperationalDataKey",
    OPERATIONAL_DATA_VALUE: "OperationalDataValue",
    OPSITEM_ID: "OpsItemId",
    OPSITEM_TYPE: "OpsItemType",
    PLANNED_END_TIME: "PlannedEndTime",
    PLANNED_START_TIME: "PlannedStartTime",
    PRIORITY: "Priority",
    RESOURCE_ID: "ResourceId",
    SEVERITY: "Severity",
    SOURCE: "Source",
    STATUS: "Status",
    TITLE: "Title",
};
const OpsItemFilterOperator = {
    CONTAINS: "Contains",
    EQUAL: "Equal",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
};
const OpsItemStatus = {
    APPROVED: "Approved",
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    CHANGE_CALENDAR_OVERRIDE_APPROVED: "ChangeCalendarOverrideApproved",
    CHANGE_CALENDAR_OVERRIDE_REJECTED: "ChangeCalendarOverrideRejected",
    CLOSED: "Closed",
    COMPLETED_WITH_FAILURE: "CompletedWithFailure",
    COMPLETED_WITH_SUCCESS: "CompletedWithSuccess",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    OPEN: "Open",
    PENDING: "Pending",
    PENDING_APPROVAL: "PendingApproval",
    PENDING_CHANGE_CALENDAR_OVERRIDE: "PendingChangeCalendarOverride",
    REJECTED: "Rejected",
    RESOLVED: "Resolved",
    REVOKED: "Revoked",
    RUNBOOK_IN_PROGRESS: "RunbookInProgress",
    SCHEDULED: "Scheduled",
    TIMED_OUT: "TimedOut",
};
const ParametersFilterKey = {
    KEY_ID: "KeyId",
    NAME: "Name",
    TYPE: "Type",
};
const ParameterTier = {
    ADVANCED: "Advanced",
    INTELLIGENT_TIERING: "Intelligent-Tiering",
    STANDARD: "Standard",
};
const ParameterType = {
    SECURE_STRING: "SecureString",
    STRING: "String",
    STRING_LIST: "StringList",
};
class InvalidFilterOption extends SSMServiceException {
    name = "InvalidFilterOption";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidFilterOption",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidFilterOption.prototype);
    }
}
const PatchSet = {
    Application: "APPLICATION",
    Os: "OS",
};
const PatchProperty = {
    PatchClassification: "CLASSIFICATION",
    PatchMsrcSeverity: "MSRC_SEVERITY",
    PatchPriority: "PRIORITY",
    PatchProductFamily: "PRODUCT_FAMILY",
    PatchSeverity: "SEVERITY",
    Product: "PRODUCT",
};
const SessionFilterKey = {
    ACCESS_TYPE: "AccessType",
    INVOKED_AFTER: "InvokedAfter",
    INVOKED_BEFORE: "InvokedBefore",
    OWNER: "Owner",
    SESSION_ID: "SessionId",
    STATUS: "Status",
    TARGET_ID: "Target",
};
const SessionState = {
    ACTIVE: "Active",
    HISTORY: "History",
};
const SessionStatus = {
    CONNECTED: "Connected",
    CONNECTING: "Connecting",
    DISCONNECTED: "Disconnected",
    FAILED: "Failed",
    TERMINATED: "Terminated",
    TERMINATING: "Terminating",
};
class OpsItemRelatedItemAssociationNotFoundException extends SSMServiceException {
    name = "OpsItemRelatedItemAssociationNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "OpsItemRelatedItemAssociationNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsItemRelatedItemAssociationNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class ThrottlingException extends SSMServiceException {
    name = "ThrottlingException";
    $fault = "client";
    Message;
    QuotaCode;
    ServiceCode;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
        this.QuotaCode = opts.QuotaCode;
        this.ServiceCode = opts.ServiceCode;
    }
}
class ValidationException extends SSMServiceException {
    name = "ValidationException";
    $fault = "client";
    Message;
    ReasonCode;
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
        this.ReasonCode = opts.ReasonCode;
    }
}
const CalendarState = {
    CLOSED: "CLOSED",
    OPEN: "OPEN",
};
class InvalidDocumentType extends SSMServiceException {
    name = "InvalidDocumentType";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidDocumentType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidDocumentType.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedCalendarException extends SSMServiceException {
    name = "UnsupportedCalendarException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedCalendarException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedCalendarException.prototype);
        this.Message = opts.Message;
    }
}
const CommandInvocationStatus = {
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    DELAYED: "Delayed",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
class InvalidPluginName extends SSMServiceException {
    name = "InvalidPluginName";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidPluginName",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPluginName.prototype);
    }
}
class InvocationDoesNotExist extends SSMServiceException {
    name = "InvocationDoesNotExist";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvocationDoesNotExist",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvocationDoesNotExist.prototype);
    }
}
const ConnectionStatus = {
    CONNECTED: "connected",
    NOT_CONNECTED: "notconnected",
};
class UnsupportedFeatureRequiredException extends SSMServiceException {
    name = "UnsupportedFeatureRequiredException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedFeatureRequiredException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedFeatureRequiredException.prototype);
        this.Message = opts.Message;
    }
}
const AttachmentHashType = {
    SHA256: "Sha256",
};
const ImpactType = {
    MUTATING: "Mutating",
    NON_MUTATING: "NonMutating",
    UNDETERMINED: "Undetermined",
};
exports.ExecutionPreview = void 0;
(function (ExecutionPreview) {
    ExecutionPreview.visit = (value, visitor) => {
        if (value.Automation !== undefined)
            return visitor.Automation(value.Automation);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(exports.ExecutionPreview || (exports.ExecutionPreview = {}));
const ExecutionPreviewStatus = {
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
};
const InventoryQueryOperatorType = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    EXISTS: "Exists",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
class InvalidAggregatorException extends SSMServiceException {
    name = "InvalidAggregatorException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAggregatorException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAggregatorException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInventoryGroupException extends SSMServiceException {
    name = "InvalidInventoryGroupException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInventoryGroupException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInventoryGroupException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidResultAttributeException extends SSMServiceException {
    name = "InvalidResultAttributeException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidResultAttributeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidResultAttributeException.prototype);
        this.Message = opts.Message;
    }
}
const InventoryAttributeDataType = {
    NUMBER: "number",
    STRING: "string",
};
const NotificationEvent = {
    ALL: "All",
    CANCELLED: "Cancelled",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const NotificationType = {
    Command: "Command",
    Invocation: "Invocation",
};
const OpsFilterOperatorType = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    EXISTS: "Exists",
    GREATER_THAN: "GreaterThan",
    LESS_THAN: "LessThan",
    NOT_EQUAL: "NotEqual",
};
class InvalidKeyId extends SSMServiceException {
    name = "InvalidKeyId";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidKeyId",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidKeyId.prototype);
    }
}
class ParameterVersionNotFound extends SSMServiceException {
    name = "ParameterVersionNotFound";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterVersionNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterVersionNotFound.prototype);
    }
}
class ServiceSettingNotFound extends SSMServiceException {
    name = "ServiceSettingNotFound";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ServiceSettingNotFound",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceSettingNotFound.prototype);
        this.Message = opts.Message;
    }
}
class ParameterVersionLabelLimitExceeded extends SSMServiceException {
    name = "ParameterVersionLabelLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterVersionLabelLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterVersionLabelLimitExceeded.prototype);
    }
}
const AssociationFilterKey = {
    AssociationId: "AssociationId",
    AssociationName: "AssociationName",
    InstanceId: "InstanceId",
    LastExecutedAfter: "LastExecutedAfter",
    LastExecutedBefore: "LastExecutedBefore",
    Name: "Name",
    ResourceGroupName: "ResourceGroupName",
    Status: "AssociationStatusName",
};
const CommandFilterKey = {
    DOCUMENT_NAME: "DocumentName",
    EXECUTION_STAGE: "ExecutionStage",
    INVOKED_AFTER: "InvokedAfter",
    INVOKED_BEFORE: "InvokedBefore",
    STATUS: "Status",
};
const CommandPluginStatus = {
    CANCELLED: "Cancelled",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const CommandStatus = {
    CANCELLED: "Cancelled",
    CANCELLING: "Cancelling",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
    PENDING: "Pending",
    SUCCESS: "Success",
    TIMED_OUT: "TimedOut",
};
const ComplianceQueryOperatorType = {
    BeginWith: "BEGIN_WITH",
    Equal: "EQUAL",
    GreaterThan: "GREATER_THAN",
    LessThan: "LESS_THAN",
    NotEqual: "NOT_EQUAL",
};
const ComplianceSeverity = {
    Critical: "CRITICAL",
    High: "HIGH",
    Informational: "INFORMATIONAL",
    Low: "LOW",
    Medium: "MEDIUM",
    Unspecified: "UNSPECIFIED",
};
const ComplianceStatus = {
    Compliant: "COMPLIANT",
    NonCompliant: "NON_COMPLIANT",
};
const DocumentMetadataEnum = {
    DocumentReviews: "DocumentReviews",
};
const DocumentReviewCommentType = {
    Comment: "Comment",
};
const DocumentFilterKey = {
    DocumentType: "DocumentType",
    Name: "Name",
    Owner: "Owner",
    PlatformTypes: "PlatformTypes",
};
const NodeFilterKey = {
    ACCOUNT_ID: "AccountId",
    AGENT_TYPE: "AgentType",
    AGENT_VERSION: "AgentVersion",
    COMPUTER_NAME: "ComputerName",
    INSTANCE_ID: "InstanceId",
    INSTANCE_STATUS: "InstanceStatus",
    IP_ADDRESS: "IpAddress",
    MANAGED_STATUS: "ManagedStatus",
    ORGANIZATIONAL_UNIT_ID: "OrganizationalUnitId",
    ORGANIZATIONAL_UNIT_PATH: "OrganizationalUnitPath",
    PLATFORM_NAME: "PlatformName",
    PLATFORM_TYPE: "PlatformType",
    PLATFORM_VERSION: "PlatformVersion",
    REGION: "Region",
    RESOURCE_TYPE: "ResourceType",
};
const NodeFilterOperatorType = {
    BEGIN_WITH: "BeginWith",
    EQUAL: "Equal",
    NOT_EQUAL: "NotEqual",
};
const ManagedStatus = {
    ALL: "All",
    MANAGED: "Managed",
    UNMANAGED: "Unmanaged",
};
exports.NodeType = void 0;
(function (NodeType) {
    NodeType.visit = (value, visitor) => {
        if (value.Instance !== undefined)
            return visitor.Instance(value.Instance);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(exports.NodeType || (exports.NodeType = {}));
class UnsupportedOperationException extends SSMServiceException {
    name = "UnsupportedOperationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedOperationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedOperationException.prototype);
        this.Message = opts.Message;
    }
}
const NodeAggregatorType = {
    COUNT: "Count",
};
const NodeAttributeName = {
    AGENT_VERSION: "AgentVersion",
    PLATFORM_NAME: "PlatformName",
    PLATFORM_TYPE: "PlatformType",
    PLATFORM_VERSION: "PlatformVersion",
    REGION: "Region",
    RESOURCE_TYPE: "ResourceType",
};
const NodeTypeName = {
    INSTANCE: "Instance",
};
const OpsItemEventFilterKey = {
    OPSITEM_ID: "OpsItemId",
};
const OpsItemEventFilterOperator = {
    EQUAL: "Equal",
};
const OpsItemRelatedItemsFilterKey = {
    ASSOCIATION_ID: "AssociationId",
    RESOURCE_TYPE: "ResourceType",
    RESOURCE_URI: "ResourceUri",
};
const OpsItemRelatedItemsFilterOperator = {
    EQUAL: "Equal",
};
const LastResourceDataSyncStatus = {
    FAILED: "Failed",
    INPROGRESS: "InProgress",
    SUCCESSFUL: "Successful",
};
class DocumentPermissionLimit extends SSMServiceException {
    name = "DocumentPermissionLimit";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentPermissionLimit",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentPermissionLimit.prototype);
        this.Message = opts.Message;
    }
}
class ComplianceTypeCountLimitExceededException extends SSMServiceException {
    name = "ComplianceTypeCountLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ComplianceTypeCountLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ComplianceTypeCountLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidItemContentException extends SSMServiceException {
    name = "InvalidItemContentException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "InvalidItemContentException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidItemContentException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class ItemSizeLimitExceededException extends SSMServiceException {
    name = "ItemSizeLimitExceededException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "ItemSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemSizeLimitExceededException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
const ComplianceUploadType = {
    Complete: "COMPLETE",
    Partial: "PARTIAL",
};
class TotalSizeLimitExceededException extends SSMServiceException {
    name = "TotalSizeLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TotalSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TotalSizeLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class CustomSchemaCountLimitExceededException extends SSMServiceException {
    name = "CustomSchemaCountLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "CustomSchemaCountLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, CustomSchemaCountLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidInventoryItemContextException extends SSMServiceException {
    name = "InvalidInventoryItemContextException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidInventoryItemContextException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidInventoryItemContextException.prototype);
        this.Message = opts.Message;
    }
}
class ItemContentMismatchException extends SSMServiceException {
    name = "ItemContentMismatchException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "ItemContentMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemContentMismatchException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class SubTypeCountLimitExceededException extends SSMServiceException {
    name = "SubTypeCountLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "SubTypeCountLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, SubTypeCountLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class UnsupportedInventoryItemContextException extends SSMServiceException {
    name = "UnsupportedInventoryItemContextException";
    $fault = "client";
    TypeName;
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedInventoryItemContextException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedInventoryItemContextException.prototype);
        this.TypeName = opts.TypeName;
        this.Message = opts.Message;
    }
}
class UnsupportedInventorySchemaVersionException extends SSMServiceException {
    name = "UnsupportedInventorySchemaVersionException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "UnsupportedInventorySchemaVersionException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedInventorySchemaVersionException.prototype);
        this.Message = opts.Message;
    }
}
class HierarchyLevelLimitExceededException extends SSMServiceException {
    name = "HierarchyLevelLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "HierarchyLevelLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, HierarchyLevelLimitExceededException.prototype);
    }
}
class HierarchyTypeMismatchException extends SSMServiceException {
    name = "HierarchyTypeMismatchException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "HierarchyTypeMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, HierarchyTypeMismatchException.prototype);
    }
}
class IncompatiblePolicyException extends SSMServiceException {
    name = "IncompatiblePolicyException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "IncompatiblePolicyException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IncompatiblePolicyException.prototype);
    }
}
class InvalidAllowedPatternException extends SSMServiceException {
    name = "InvalidAllowedPatternException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidAllowedPatternException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAllowedPatternException.prototype);
    }
}
class InvalidPolicyAttributeException extends SSMServiceException {
    name = "InvalidPolicyAttributeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidPolicyAttributeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPolicyAttributeException.prototype);
    }
}
class InvalidPolicyTypeException extends SSMServiceException {
    name = "InvalidPolicyTypeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidPolicyTypeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidPolicyTypeException.prototype);
    }
}
class ParameterAlreadyExists extends SSMServiceException {
    name = "ParameterAlreadyExists";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterAlreadyExists",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterAlreadyExists.prototype);
    }
}
class ParameterLimitExceeded extends SSMServiceException {
    name = "ParameterLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterLimitExceeded.prototype);
    }
}
class ParameterMaxVersionLimitExceeded extends SSMServiceException {
    name = "ParameterMaxVersionLimitExceeded";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterMaxVersionLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterMaxVersionLimitExceeded.prototype);
    }
}
class ParameterPatternMismatchException extends SSMServiceException {
    name = "ParameterPatternMismatchException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ParameterPatternMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ParameterPatternMismatchException.prototype);
    }
}
class PoliciesLimitExceededException extends SSMServiceException {
    name = "PoliciesLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PoliciesLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PoliciesLimitExceededException.prototype);
    }
}
class UnsupportedParameterType extends SSMServiceException {
    name = "UnsupportedParameterType";
    $fault = "client";
    constructor(opts) {
        super({
            name: "UnsupportedParameterType",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UnsupportedParameterType.prototype);
    }
}
class ResourcePolicyLimitExceededException extends SSMServiceException {
    name = "ResourcePolicyLimitExceededException";
    $fault = "client";
    Limit;
    LimitType;
    Message;
    constructor(opts) {
        super({
            name: "ResourcePolicyLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourcePolicyLimitExceededException.prototype);
        this.Limit = opts.Limit;
        this.LimitType = opts.LimitType;
        this.Message = opts.Message;
    }
}
const DescribeMaintenanceWindowsResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.WindowIdentities && {
        WindowIdentities: obj.WindowIdentities.map((item) => MaintenanceWindowIdentityFilterSensitiveLog(item)),
    }),
});
const MaintenanceWindowTargetFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const DescribeMaintenanceWindowTargetsResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Targets && { Targets: obj.Targets.map((item) => MaintenanceWindowTargetFilterSensitiveLog(item)) }),
});
const MaintenanceWindowTaskParameterValueExpressionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Values && { Values: smithyClient.SENSITIVE_STRING }),
});
const MaintenanceWindowTaskFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TaskParameters && { TaskParameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const DescribeMaintenanceWindowTasksResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Tasks && { Tasks: obj.Tasks.map((item) => MaintenanceWindowTaskFilterSensitiveLog(item)) }),
});
const CredentialsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SecretAccessKey && { SecretAccessKey: smithyClient.SENSITIVE_STRING }),
    ...(obj.SessionToken && { SessionToken: smithyClient.SENSITIVE_STRING }),
});
const GetAccessTokenResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Credentials && { Credentials: CredentialsFilterSensitiveLog(obj.Credentials) }),
});
const BaselineOverrideFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Sources && { Sources: obj.Sources.map((item) => PatchSourceFilterSensitiveLog(item)) }),
});
const GetDeployablePatchSnapshotForInstanceRequestFilterSensitiveLog = (obj) => ({
    ...obj,
});
const GetMaintenanceWindowResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const GetMaintenanceWindowExecutionTaskResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TaskParameters && { TaskParameters: smithyClient.SENSITIVE_STRING }),
});
const GetMaintenanceWindowExecutionTaskInvocationResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
});
const MaintenanceWindowLambdaParametersFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Payload && { Payload: smithyClient.SENSITIVE_STRING }),
});
const MaintenanceWindowRunCommandParametersFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const MaintenanceWindowStepFunctionsParametersFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Input && { Input: smithyClient.SENSITIVE_STRING }),
});
const MaintenanceWindowTaskInvocationParametersFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.RunCommand && { RunCommand: MaintenanceWindowRunCommandParametersFilterSensitiveLog(obj.RunCommand) }),
    ...(obj.StepFunctions && {
        StepFunctions: MaintenanceWindowStepFunctionsParametersFilterSensitiveLog(obj.StepFunctions),
    }),
    ...(obj.Lambda && { Lambda: MaintenanceWindowLambdaParametersFilterSensitiveLog(obj.Lambda) }),
});
const GetMaintenanceWindowTaskResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TaskParameters && { TaskParameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.TaskInvocationParameters && {
        TaskInvocationParameters: MaintenanceWindowTaskInvocationParametersFilterSensitiveLog(obj.TaskInvocationParameters),
    }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const ParameterFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Value && { Value: smithyClient.SENSITIVE_STRING }),
});
const GetParameterResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameter && { Parameter: ParameterFilterSensitiveLog(obj.Parameter) }),
});
const ParameterHistoryFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Value && { Value: smithyClient.SENSITIVE_STRING }),
});
const GetParameterHistoryResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: obj.Parameters.map((item) => ParameterHistoryFilterSensitiveLog(item)) }),
});
const GetParametersResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: obj.Parameters.map((item) => ParameterFilterSensitiveLog(item)) }),
});
const GetParametersByPathResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: obj.Parameters.map((item) => ParameterFilterSensitiveLog(item)) }),
});
const GetPatchBaselineResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Sources && { Sources: obj.Sources.map((item) => PatchSourceFilterSensitiveLog(item)) }),
});
const AssociationVersionInfoFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const ListAssociationVersionsResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.AssociationVersions && {
        AssociationVersions: obj.AssociationVersions.map((item) => AssociationVersionInfoFilterSensitiveLog(item)),
    }),
});
const CommandFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const ListCommandsResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Commands && { Commands: obj.Commands.map((item) => CommandFilterSensitiveLog(item)) }),
});
const InstanceInfoFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.IpAddress && { IpAddress: smithyClient.SENSITIVE_STRING }),
});
const NodeTypeFilterSensitiveLog = (obj) => {
    if (obj.Instance !== undefined)
        return { Instance: InstanceInfoFilterSensitiveLog(obj.Instance) };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: "UNKNOWN" };
};
const NodeFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.NodeType && { NodeType: NodeTypeFilterSensitiveLog(obj.NodeType) }),
});
const ListNodesResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Nodes && { Nodes: obj.Nodes.map((item) => NodeFilterSensitiveLog(item)) }),
});
const PutParameterRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Value && { Value: smithyClient.SENSITIVE_STRING }),
});

class FeatureNotAvailableException extends SSMServiceException {
    name = "FeatureNotAvailableException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "FeatureNotAvailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, FeatureNotAvailableException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationStepNotFoundException extends SSMServiceException {
    name = "AutomationStepNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationStepNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationStepNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAutomationSignalException extends SSMServiceException {
    name = "InvalidAutomationSignalException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAutomationSignalException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAutomationSignalException.prototype);
        this.Message = opts.Message;
    }
}
const SignalType = {
    APPROVE: "Approve",
    REJECT: "Reject",
    RESUME: "Resume",
    REVOKE: "Revoke",
    START_STEP: "StartStep",
    STOP_STEP: "StopStep",
};
class InvalidNotificationConfig extends SSMServiceException {
    name = "InvalidNotificationConfig";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidNotificationConfig",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidNotificationConfig.prototype);
        this.Message = opts.Message;
    }
}
class InvalidOutputFolder extends SSMServiceException {
    name = "InvalidOutputFolder";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidOutputFolder",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidOutputFolder.prototype);
    }
}
class InvalidRole extends SSMServiceException {
    name = "InvalidRole";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidRole",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidRole.prototype);
        this.Message = opts.Message;
    }
}
class ServiceQuotaExceededException extends SSMServiceException {
    name = "ServiceQuotaExceededException";
    $fault = "client";
    Message;
    ResourceId;
    ResourceType;
    QuotaCode;
    ServiceCode;
    constructor(opts) {
        super({
            name: "ServiceQuotaExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
        this.Message = opts.Message;
        this.ResourceId = opts.ResourceId;
        this.ResourceType = opts.ResourceType;
        this.QuotaCode = opts.QuotaCode;
        this.ServiceCode = opts.ServiceCode;
    }
}
class InvalidAssociation extends SSMServiceException {
    name = "InvalidAssociation";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAssociation",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAssociation.prototype);
        this.Message = opts.Message;
    }
}
class AutomationDefinitionNotFoundException extends SSMServiceException {
    name = "AutomationDefinitionNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationDefinitionNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationDefinitionNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationDefinitionVersionNotFoundException extends SSMServiceException {
    name = "AutomationDefinitionVersionNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationDefinitionVersionNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationDefinitionVersionNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationExecutionLimitExceededException extends SSMServiceException {
    name = "AutomationExecutionLimitExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationExecutionLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationExecutionLimitExceededException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAutomationExecutionParametersException extends SSMServiceException {
    name = "InvalidAutomationExecutionParametersException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAutomationExecutionParametersException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAutomationExecutionParametersException.prototype);
        this.Message = opts.Message;
    }
}
class AutomationDefinitionNotApprovedException extends SSMServiceException {
    name = "AutomationDefinitionNotApprovedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AutomationDefinitionNotApprovedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AutomationDefinitionNotApprovedException.prototype);
        this.Message = opts.Message;
    }
}
exports.ExecutionInputs = void 0;
(function (ExecutionInputs) {
    ExecutionInputs.visit = (value, visitor) => {
        if (value.Automation !== undefined)
            return visitor.Automation(value.Automation);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(exports.ExecutionInputs || (exports.ExecutionInputs = {}));
class TargetNotConnected extends SSMServiceException {
    name = "TargetNotConnected";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TargetNotConnected",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TargetNotConnected.prototype);
        this.Message = opts.Message;
    }
}
class InvalidAutomationStatusUpdateException extends SSMServiceException {
    name = "InvalidAutomationStatusUpdateException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidAutomationStatusUpdateException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidAutomationStatusUpdateException.prototype);
        this.Message = opts.Message;
    }
}
const StopType = {
    CANCEL: "Cancel",
    COMPLETE: "Complete",
};
class AssociationVersionLimitExceeded extends SSMServiceException {
    name = "AssociationVersionLimitExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AssociationVersionLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AssociationVersionLimitExceeded.prototype);
        this.Message = opts.Message;
    }
}
class InvalidUpdate extends SSMServiceException {
    name = "InvalidUpdate";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidUpdate",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidUpdate.prototype);
        this.Message = opts.Message;
    }
}
class StatusUnchanged extends SSMServiceException {
    name = "StatusUnchanged";
    $fault = "client";
    constructor(opts) {
        super({
            name: "StatusUnchanged",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, StatusUnchanged.prototype);
    }
}
class DocumentVersionLimitExceeded extends SSMServiceException {
    name = "DocumentVersionLimitExceeded";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DocumentVersionLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DocumentVersionLimitExceeded.prototype);
        this.Message = opts.Message;
    }
}
class DuplicateDocumentContent extends SSMServiceException {
    name = "DuplicateDocumentContent";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DuplicateDocumentContent",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateDocumentContent.prototype);
        this.Message = opts.Message;
    }
}
class DuplicateDocumentVersionName extends SSMServiceException {
    name = "DuplicateDocumentVersionName";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "DuplicateDocumentVersionName",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateDocumentVersionName.prototype);
        this.Message = opts.Message;
    }
}
const DocumentReviewAction = {
    Approve: "Approve",
    Reject: "Reject",
    SendForReview: "SendForReview",
    UpdateReview: "UpdateReview",
};
class OpsMetadataKeyLimitExceededException extends SSMServiceException {
    name = "OpsMetadataKeyLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OpsMetadataKeyLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OpsMetadataKeyLimitExceededException.prototype);
    }
}
class ResourceDataSyncConflictException extends SSMServiceException {
    name = "ResourceDataSyncConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceDataSyncConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceDataSyncConflictException.prototype);
        this.Message = opts.Message;
    }
}
const RegisterTargetWithMaintenanceWindowRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const RegisterTaskWithMaintenanceWindowRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TaskParameters && { TaskParameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.TaskInvocationParameters && {
        TaskInvocationParameters: MaintenanceWindowTaskInvocationParametersFilterSensitiveLog(obj.TaskInvocationParameters),
    }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const SendCommandRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const SendCommandResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Command && { Command: CommandFilterSensitiveLog(obj.Command) }),
});
const UpdateAssociationRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Parameters && { Parameters: smithyClient.SENSITIVE_STRING }),
});
const UpdateAssociationResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.AssociationDescription && {
        AssociationDescription: AssociationDescriptionFilterSensitiveLog(obj.AssociationDescription),
    }),
});
const UpdateAssociationStatusResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.AssociationDescription && {
        AssociationDescription: AssociationDescriptionFilterSensitiveLog(obj.AssociationDescription),
    }),
});
const UpdateMaintenanceWindowRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const UpdateMaintenanceWindowResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const UpdateMaintenanceWindowTargetRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const UpdateMaintenanceWindowTargetResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.OwnerInformation && { OwnerInformation: smithyClient.SENSITIVE_STRING }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const UpdateMaintenanceWindowTaskRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TaskParameters && { TaskParameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.TaskInvocationParameters && {
        TaskInvocationParameters: MaintenanceWindowTaskInvocationParametersFilterSensitiveLog(obj.TaskInvocationParameters),
    }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const UpdateMaintenanceWindowTaskResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.TaskParameters && { TaskParameters: smithyClient.SENSITIVE_STRING }),
    ...(obj.TaskInvocationParameters && {
        TaskInvocationParameters: MaintenanceWindowTaskInvocationParametersFilterSensitiveLog(obj.TaskInvocationParameters),
    }),
    ...(obj.Description && { Description: smithyClient.SENSITIVE_STRING }),
});
const UpdatePatchBaselineRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Sources && { Sources: obj.Sources.map((item) => PatchSourceFilterSensitiveLog(item)) }),
});
const UpdatePatchBaselineResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Sources && { Sources: obj.Sources.map((item) => PatchSourceFilterSensitiveLog(item)) }),
});

const se_AddTagsToResourceCommand = async (input, context) => {
    const headers = sharedHeaders("AddTagsToResource");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_AssociateOpsItemRelatedItemCommand = async (input, context) => {
    const headers = sharedHeaders("AssociateOpsItemRelatedItem");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CancelCommandCommand = async (input, context) => {
    const headers = sharedHeaders("CancelCommand");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CancelMaintenanceWindowExecutionCommand = async (input, context) => {
    const headers = sharedHeaders("CancelMaintenanceWindowExecution");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateActivationCommand = async (input, context) => {
    const headers = sharedHeaders("CreateActivation");
    let body;
    body = JSON.stringify(se_CreateActivationRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateAssociationCommand = async (input, context) => {
    const headers = sharedHeaders("CreateAssociation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateAssociationBatchCommand = async (input, context) => {
    const headers = sharedHeaders("CreateAssociationBatch");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateDocumentCommand = async (input, context) => {
    const headers = sharedHeaders("CreateDocument");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("CreateMaintenanceWindow");
    let body;
    body = JSON.stringify(se_CreateMaintenanceWindowRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateOpsItemCommand = async (input, context) => {
    const headers = sharedHeaders("CreateOpsItem");
    let body;
    body = JSON.stringify(se_CreateOpsItemRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateOpsMetadataCommand = async (input, context) => {
    const headers = sharedHeaders("CreateOpsMetadata");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreatePatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("CreatePatchBaseline");
    let body;
    body = JSON.stringify(se_CreatePatchBaselineRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_CreateResourceDataSyncCommand = async (input, context) => {
    const headers = sharedHeaders("CreateResourceDataSync");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteActivationCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteActivation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteAssociationCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteAssociation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteDocumentCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteDocument");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteInventoryCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteInventory");
    let body;
    body = JSON.stringify(se_DeleteInventoryRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteMaintenanceWindow");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteOpsItemCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteOpsItem");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteOpsMetadataCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteOpsMetadata");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteParameterCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteParameter");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteParametersCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteParameters");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeletePatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("DeletePatchBaseline");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteResourceDataSyncCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteResourceDataSync");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeleteResourcePolicyCommand = async (input, context) => {
    const headers = sharedHeaders("DeleteResourcePolicy");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeregisterManagedInstanceCommand = async (input, context) => {
    const headers = sharedHeaders("DeregisterManagedInstance");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeregisterPatchBaselineForPatchGroupCommand = async (input, context) => {
    const headers = sharedHeaders("DeregisterPatchBaselineForPatchGroup");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeregisterTargetFromMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("DeregisterTargetFromMaintenanceWindow");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DeregisterTaskFromMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("DeregisterTaskFromMaintenanceWindow");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeActivationsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeActivations");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeAssociationCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeAssociation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeAssociationExecutionsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeAssociationExecutions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeAssociationExecutionTargetsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeAssociationExecutionTargets");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeAutomationExecutionsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeAutomationExecutions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeAutomationStepExecutionsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeAutomationStepExecutions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeAvailablePatchesCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeAvailablePatches");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeDocumentCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeDocument");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeDocumentPermissionCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeDocumentPermission");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeEffectiveInstanceAssociationsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeEffectiveInstanceAssociations");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeEffectivePatchesForPatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeEffectivePatchesForPatchBaseline");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInstanceAssociationsStatusCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInstanceAssociationsStatus");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInstanceInformationCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInstanceInformation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInstancePatchesCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInstancePatches");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInstancePatchStatesCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInstancePatchStates");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInstancePatchStatesForPatchGroupCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInstancePatchStatesForPatchGroup");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInstancePropertiesCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInstanceProperties");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeInventoryDeletionsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeInventoryDeletions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowExecutionsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowExecutions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowExecutionTaskInvocationsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowExecutionTaskInvocations");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowExecutionTasksCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowExecutionTasks");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindows");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowScheduleCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowSchedule");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowsForTargetCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowsForTarget");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowTargetsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowTargets");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeMaintenanceWindowTasksCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeMaintenanceWindowTasks");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeOpsItemsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeOpsItems");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeParametersCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeParameters");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribePatchBaselinesCommand = async (input, context) => {
    const headers = sharedHeaders("DescribePatchBaselines");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribePatchGroupsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribePatchGroups");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribePatchGroupStateCommand = async (input, context) => {
    const headers = sharedHeaders("DescribePatchGroupState");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribePatchPropertiesCommand = async (input, context) => {
    const headers = sharedHeaders("DescribePatchProperties");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DescribeSessionsCommand = async (input, context) => {
    const headers = sharedHeaders("DescribeSessions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_DisassociateOpsItemRelatedItemCommand = async (input, context) => {
    const headers = sharedHeaders("DisassociateOpsItemRelatedItem");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetAccessTokenCommand = async (input, context) => {
    const headers = sharedHeaders("GetAccessToken");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetAutomationExecutionCommand = async (input, context) => {
    const headers = sharedHeaders("GetAutomationExecution");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetCalendarStateCommand = async (input, context) => {
    const headers = sharedHeaders("GetCalendarState");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetCommandInvocationCommand = async (input, context) => {
    const headers = sharedHeaders("GetCommandInvocation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetConnectionStatusCommand = async (input, context) => {
    const headers = sharedHeaders("GetConnectionStatus");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetDefaultPatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("GetDefaultPatchBaseline");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetDeployablePatchSnapshotForInstanceCommand = async (input, context) => {
    const headers = sharedHeaders("GetDeployablePatchSnapshotForInstance");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetDocumentCommand = async (input, context) => {
    const headers = sharedHeaders("GetDocument");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetExecutionPreviewCommand = async (input, context) => {
    const headers = sharedHeaders("GetExecutionPreview");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetInventoryCommand = async (input, context) => {
    const headers = sharedHeaders("GetInventory");
    let body;
    body = JSON.stringify(se_GetInventoryRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetInventorySchemaCommand = async (input, context) => {
    const headers = sharedHeaders("GetInventorySchema");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("GetMaintenanceWindow");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetMaintenanceWindowExecutionCommand = async (input, context) => {
    const headers = sharedHeaders("GetMaintenanceWindowExecution");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetMaintenanceWindowExecutionTaskCommand = async (input, context) => {
    const headers = sharedHeaders("GetMaintenanceWindowExecutionTask");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetMaintenanceWindowExecutionTaskInvocationCommand = async (input, context) => {
    const headers = sharedHeaders("GetMaintenanceWindowExecutionTaskInvocation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetMaintenanceWindowTaskCommand = async (input, context) => {
    const headers = sharedHeaders("GetMaintenanceWindowTask");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetOpsItemCommand = async (input, context) => {
    const headers = sharedHeaders("GetOpsItem");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetOpsMetadataCommand = async (input, context) => {
    const headers = sharedHeaders("GetOpsMetadata");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetOpsSummaryCommand = async (input, context) => {
    const headers = sharedHeaders("GetOpsSummary");
    let body;
    body = JSON.stringify(se_GetOpsSummaryRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetParameterCommand = async (input, context) => {
    const headers = sharedHeaders("GetParameter");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetParameterHistoryCommand = async (input, context) => {
    const headers = sharedHeaders("GetParameterHistory");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetParametersCommand = async (input, context) => {
    const headers = sharedHeaders("GetParameters");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetParametersByPathCommand = async (input, context) => {
    const headers = sharedHeaders("GetParametersByPath");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetPatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("GetPatchBaseline");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetPatchBaselineForPatchGroupCommand = async (input, context) => {
    const headers = sharedHeaders("GetPatchBaselineForPatchGroup");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetResourcePoliciesCommand = async (input, context) => {
    const headers = sharedHeaders("GetResourcePolicies");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_GetServiceSettingCommand = async (input, context) => {
    const headers = sharedHeaders("GetServiceSetting");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_LabelParameterVersionCommand = async (input, context) => {
    const headers = sharedHeaders("LabelParameterVersion");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListAssociationsCommand = async (input, context) => {
    const headers = sharedHeaders("ListAssociations");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListAssociationVersionsCommand = async (input, context) => {
    const headers = sharedHeaders("ListAssociationVersions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListCommandInvocationsCommand = async (input, context) => {
    const headers = sharedHeaders("ListCommandInvocations");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListCommandsCommand = async (input, context) => {
    const headers = sharedHeaders("ListCommands");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListComplianceItemsCommand = async (input, context) => {
    const headers = sharedHeaders("ListComplianceItems");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListComplianceSummariesCommand = async (input, context) => {
    const headers = sharedHeaders("ListComplianceSummaries");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListDocumentMetadataHistoryCommand = async (input, context) => {
    const headers = sharedHeaders("ListDocumentMetadataHistory");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListDocumentsCommand = async (input, context) => {
    const headers = sharedHeaders("ListDocuments");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListDocumentVersionsCommand = async (input, context) => {
    const headers = sharedHeaders("ListDocumentVersions");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListInventoryEntriesCommand = async (input, context) => {
    const headers = sharedHeaders("ListInventoryEntries");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListNodesCommand = async (input, context) => {
    const headers = sharedHeaders("ListNodes");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListNodesSummaryCommand = async (input, context) => {
    const headers = sharedHeaders("ListNodesSummary");
    let body;
    body = JSON.stringify(se_ListNodesSummaryRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListOpsItemEventsCommand = async (input, context) => {
    const headers = sharedHeaders("ListOpsItemEvents");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListOpsItemRelatedItemsCommand = async (input, context) => {
    const headers = sharedHeaders("ListOpsItemRelatedItems");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListOpsMetadataCommand = async (input, context) => {
    const headers = sharedHeaders("ListOpsMetadata");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListResourceComplianceSummariesCommand = async (input, context) => {
    const headers = sharedHeaders("ListResourceComplianceSummaries");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListResourceDataSyncCommand = async (input, context) => {
    const headers = sharedHeaders("ListResourceDataSync");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ListTagsForResourceCommand = async (input, context) => {
    const headers = sharedHeaders("ListTagsForResource");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ModifyDocumentPermissionCommand = async (input, context) => {
    const headers = sharedHeaders("ModifyDocumentPermission");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_PutComplianceItemsCommand = async (input, context) => {
    const headers = sharedHeaders("PutComplianceItems");
    let body;
    body = JSON.stringify(se_PutComplianceItemsRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_PutInventoryCommand = async (input, context) => {
    const headers = sharedHeaders("PutInventory");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_PutParameterCommand = async (input, context) => {
    const headers = sharedHeaders("PutParameter");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_PutResourcePolicyCommand = async (input, context) => {
    const headers = sharedHeaders("PutResourcePolicy");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_RegisterDefaultPatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("RegisterDefaultPatchBaseline");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_RegisterPatchBaselineForPatchGroupCommand = async (input, context) => {
    const headers = sharedHeaders("RegisterPatchBaselineForPatchGroup");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_RegisterTargetWithMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("RegisterTargetWithMaintenanceWindow");
    let body;
    body = JSON.stringify(se_RegisterTargetWithMaintenanceWindowRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_RegisterTaskWithMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("RegisterTaskWithMaintenanceWindow");
    let body;
    body = JSON.stringify(se_RegisterTaskWithMaintenanceWindowRequest(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_RemoveTagsFromResourceCommand = async (input, context) => {
    const headers = sharedHeaders("RemoveTagsFromResource");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ResetServiceSettingCommand = async (input, context) => {
    const headers = sharedHeaders("ResetServiceSetting");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_ResumeSessionCommand = async (input, context) => {
    const headers = sharedHeaders("ResumeSession");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_SendAutomationSignalCommand = async (input, context) => {
    const headers = sharedHeaders("SendAutomationSignal");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_SendCommandCommand = async (input, context) => {
    const headers = sharedHeaders("SendCommand");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartAccessRequestCommand = async (input, context) => {
    const headers = sharedHeaders("StartAccessRequest");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartAssociationsOnceCommand = async (input, context) => {
    const headers = sharedHeaders("StartAssociationsOnce");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartAutomationExecutionCommand = async (input, context) => {
    const headers = sharedHeaders("StartAutomationExecution");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartChangeRequestExecutionCommand = async (input, context) => {
    const headers = sharedHeaders("StartChangeRequestExecution");
    let body;
    body = JSON.stringify(se_StartChangeRequestExecutionRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartExecutionPreviewCommand = async (input, context) => {
    const headers = sharedHeaders("StartExecutionPreview");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StartSessionCommand = async (input, context) => {
    const headers = sharedHeaders("StartSession");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_StopAutomationExecutionCommand = async (input, context) => {
    const headers = sharedHeaders("StopAutomationExecution");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_TerminateSessionCommand = async (input, context) => {
    const headers = sharedHeaders("TerminateSession");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UnlabelParameterVersionCommand = async (input, context) => {
    const headers = sharedHeaders("UnlabelParameterVersion");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateAssociationCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateAssociation");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateAssociationStatusCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateAssociationStatus");
    let body;
    body = JSON.stringify(se_UpdateAssociationStatusRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateDocumentCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateDocument");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateDocumentDefaultVersionCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateDocumentDefaultVersion");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateDocumentMetadataCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateDocumentMetadata");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateMaintenanceWindowCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateMaintenanceWindow");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateMaintenanceWindowTargetCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateMaintenanceWindowTarget");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateMaintenanceWindowTaskCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateMaintenanceWindowTask");
    let body;
    body = JSON.stringify(se_UpdateMaintenanceWindowTaskRequest(input, context));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateManagedInstanceRoleCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateManagedInstanceRole");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateOpsItemCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateOpsItem");
    let body;
    body = JSON.stringify(se_UpdateOpsItemRequest(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateOpsMetadataCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateOpsMetadata");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdatePatchBaselineCommand = async (input, context) => {
    const headers = sharedHeaders("UpdatePatchBaseline");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateResourceDataSyncCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateResourceDataSync");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const se_UpdateServiceSettingCommand = async (input, context) => {
    const headers = sharedHeaders("UpdateServiceSetting");
    let body;
    body = JSON.stringify(smithyClient._json(input));
    return buildHttpRpcRequest(context, headers, "/", undefined, body);
};
const de_AddTagsToResourceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_AssociateOpsItemRelatedItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CancelCommandCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CancelMaintenanceWindowExecutionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateActivationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateAssociationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_CreateAssociationResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateAssociationBatchCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_CreateAssociationBatchResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateDocumentCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_CreateDocumentResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateOpsItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateOpsMetadataCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreatePatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CreateResourceDataSyncCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteActivationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteAssociationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteDocumentCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteInventoryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteOpsItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteOpsMetadataCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteParameterCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteParametersCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeletePatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteResourceDataSyncCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeleteResourcePolicyCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeregisterManagedInstanceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeregisterPatchBaselineForPatchGroupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeregisterTargetFromMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DeregisterTaskFromMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeActivationsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeActivationsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeAssociationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeAssociationResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeAssociationExecutionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeAssociationExecutionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeAssociationExecutionTargetsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeAssociationExecutionTargetsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeAutomationExecutionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeAutomationExecutionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeAutomationStepExecutionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeAutomationStepExecutionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeAvailablePatchesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeAvailablePatchesResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeDocumentCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeDocumentResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeDocumentPermissionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeEffectiveInstanceAssociationsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeEffectivePatchesForPatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeEffectivePatchesForPatchBaselineResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInstanceAssociationsStatusCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInstanceAssociationsStatusResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInstanceInformationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInstanceInformationResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInstancePatchesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInstancePatchesResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInstancePatchStatesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInstancePatchStatesResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInstancePatchStatesForPatchGroupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInstancePatchStatesForPatchGroupResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInstancePropertiesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInstancePropertiesResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeInventoryDeletionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeInventoryDeletionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowExecutionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeMaintenanceWindowExecutionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowExecutionTaskInvocationsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeMaintenanceWindowExecutionTaskInvocationsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowExecutionTasksCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeMaintenanceWindowExecutionTasksResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowScheduleCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowsForTargetCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowTargetsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeMaintenanceWindowTasksCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeOpsItemsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeOpsItemsResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeParametersCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeParametersResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribePatchBaselinesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribePatchGroupsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribePatchGroupStateCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribePatchPropertiesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DescribeSessionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_DescribeSessionsResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_DisassociateOpsItemRelatedItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetAccessTokenCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetAccessTokenResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetAutomationExecutionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetAutomationExecutionResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetCalendarStateCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetCommandInvocationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetConnectionStatusCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetDefaultPatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetDeployablePatchSnapshotForInstanceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetDocumentCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetDocumentResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetExecutionPreviewCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetExecutionPreviewResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetInventoryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetInventorySchemaCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetMaintenanceWindowResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetMaintenanceWindowExecutionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetMaintenanceWindowExecutionResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetMaintenanceWindowExecutionTaskCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetMaintenanceWindowExecutionTaskResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetMaintenanceWindowExecutionTaskInvocationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetMaintenanceWindowExecutionTaskInvocationResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetMaintenanceWindowTaskCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetMaintenanceWindowTaskResult(data, context);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetOpsItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetOpsItemResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetOpsMetadataCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetOpsSummaryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetParameterCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetParameterResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetParameterHistoryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetParameterHistoryResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetParametersCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetParametersResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetParametersByPathCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetParametersByPathResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetPatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetPatchBaselineResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetPatchBaselineForPatchGroupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetResourcePoliciesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_GetServiceSettingCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_GetServiceSettingResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_LabelParameterVersionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListAssociationsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListAssociationsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListAssociationVersionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListAssociationVersionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListCommandInvocationsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListCommandInvocationsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListCommandsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListCommandsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListComplianceItemsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListComplianceItemsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListComplianceSummariesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListDocumentMetadataHistoryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListDocumentMetadataHistoryResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListDocumentsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListDocumentsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListDocumentVersionsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListDocumentVersionsResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListInventoryEntriesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListNodesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListNodesResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListNodesSummaryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListOpsItemEventsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListOpsItemEventsResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListOpsItemRelatedItemsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListOpsItemRelatedItemsResponse(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListOpsMetadataCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListOpsMetadataResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListResourceComplianceSummariesCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListResourceComplianceSummariesResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListResourceDataSyncCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ListResourceDataSyncResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ListTagsForResourceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ModifyDocumentPermissionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_PutComplianceItemsCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_PutInventoryCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_PutParameterCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_PutResourcePolicyCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_RegisterDefaultPatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_RegisterPatchBaselineForPatchGroupCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_RegisterTargetWithMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_RegisterTaskWithMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_RemoveTagsFromResourceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ResetServiceSettingCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_ResetServiceSettingResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_ResumeSessionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_SendAutomationSignalCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_SendCommandCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_SendCommandResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StartAccessRequestCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StartAssociationsOnceCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StartAutomationExecutionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StartChangeRequestExecutionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StartExecutionPreviewCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StartSessionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_StopAutomationExecutionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_TerminateSessionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UnlabelParameterVersionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateAssociationCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_UpdateAssociationResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateAssociationStatusCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_UpdateAssociationStatusResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateDocumentCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_UpdateDocumentResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateDocumentDefaultVersionCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateDocumentMetadataCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateMaintenanceWindowCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateMaintenanceWindowTargetCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateMaintenanceWindowTaskCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_UpdateMaintenanceWindowTaskResult(data, context);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateManagedInstanceRoleCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateOpsItemCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateOpsMetadataCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdatePatchBaselineCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = de_UpdatePatchBaselineResult(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateResourceDataSyncCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_UpdateServiceSettingCommand = async (output, context) => {
    if (output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const data = await core$1.parseJsonBody(output.body, context);
    let contents = {};
    contents = smithyClient._json(data);
    const response = {
        $metadata: deserializeMetadata(output),
        ...contents,
    };
    return response;
};
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await core$1.parseJsonErrorBody(output.body, context),
    };
    const errorCode = core$1.loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "InternalServerError":
        case "com.amazonaws.ssm#InternalServerError":
            throw await de_InternalServerErrorRes(parsedOutput);
        case "InvalidResourceId":
        case "com.amazonaws.ssm#InvalidResourceId":
            throw await de_InvalidResourceIdRes(parsedOutput);
        case "InvalidResourceType":
        case "com.amazonaws.ssm#InvalidResourceType":
            throw await de_InvalidResourceTypeRes(parsedOutput);
        case "TooManyTagsError":
        case "com.amazonaws.ssm#TooManyTagsError":
            throw await de_TooManyTagsErrorRes(parsedOutput);
        case "TooManyUpdates":
        case "com.amazonaws.ssm#TooManyUpdates":
            throw await de_TooManyUpdatesRes(parsedOutput);
        case "OpsItemConflictException":
        case "com.amazonaws.ssm#OpsItemConflictException":
            throw await de_OpsItemConflictExceptionRes(parsedOutput);
        case "OpsItemInvalidParameterException":
        case "com.amazonaws.ssm#OpsItemInvalidParameterException":
            throw await de_OpsItemInvalidParameterExceptionRes(parsedOutput);
        case "OpsItemLimitExceededException":
        case "com.amazonaws.ssm#OpsItemLimitExceededException":
            throw await de_OpsItemLimitExceededExceptionRes(parsedOutput);
        case "OpsItemNotFoundException":
        case "com.amazonaws.ssm#OpsItemNotFoundException":
            throw await de_OpsItemNotFoundExceptionRes(parsedOutput);
        case "OpsItemRelatedItemAlreadyExistsException":
        case "com.amazonaws.ssm#OpsItemRelatedItemAlreadyExistsException":
            throw await de_OpsItemRelatedItemAlreadyExistsExceptionRes(parsedOutput);
        case "DuplicateInstanceId":
        case "com.amazonaws.ssm#DuplicateInstanceId":
            throw await de_DuplicateInstanceIdRes(parsedOutput);
        case "InvalidCommandId":
        case "com.amazonaws.ssm#InvalidCommandId":
            throw await de_InvalidCommandIdRes(parsedOutput);
        case "InvalidInstanceId":
        case "com.amazonaws.ssm#InvalidInstanceId":
            throw await de_InvalidInstanceIdRes(parsedOutput);
        case "DoesNotExistException":
        case "com.amazonaws.ssm#DoesNotExistException":
            throw await de_DoesNotExistExceptionRes(parsedOutput);
        case "InvalidParameters":
        case "com.amazonaws.ssm#InvalidParameters":
            throw await de_InvalidParametersRes(parsedOutput);
        case "AssociationAlreadyExists":
        case "com.amazonaws.ssm#AssociationAlreadyExists":
            throw await de_AssociationAlreadyExistsRes(parsedOutput);
        case "AssociationLimitExceeded":
        case "com.amazonaws.ssm#AssociationLimitExceeded":
            throw await de_AssociationLimitExceededRes(parsedOutput);
        case "InvalidDocument":
        case "com.amazonaws.ssm#InvalidDocument":
            throw await de_InvalidDocumentRes(parsedOutput);
        case "InvalidDocumentVersion":
        case "com.amazonaws.ssm#InvalidDocumentVersion":
            throw await de_InvalidDocumentVersionRes(parsedOutput);
        case "InvalidOutputLocation":
        case "com.amazonaws.ssm#InvalidOutputLocation":
            throw await de_InvalidOutputLocationRes(parsedOutput);
        case "InvalidSchedule":
        case "com.amazonaws.ssm#InvalidSchedule":
            throw await de_InvalidScheduleRes(parsedOutput);
        case "InvalidTag":
        case "com.amazonaws.ssm#InvalidTag":
            throw await de_InvalidTagRes(parsedOutput);
        case "InvalidTarget":
        case "com.amazonaws.ssm#InvalidTarget":
            throw await de_InvalidTargetRes(parsedOutput);
        case "InvalidTargetMaps":
        case "com.amazonaws.ssm#InvalidTargetMaps":
            throw await de_InvalidTargetMapsRes(parsedOutput);
        case "UnsupportedPlatformType":
        case "com.amazonaws.ssm#UnsupportedPlatformType":
            throw await de_UnsupportedPlatformTypeRes(parsedOutput);
        case "DocumentAlreadyExists":
        case "com.amazonaws.ssm#DocumentAlreadyExists":
            throw await de_DocumentAlreadyExistsRes(parsedOutput);
        case "DocumentLimitExceeded":
        case "com.amazonaws.ssm#DocumentLimitExceeded":
            throw await de_DocumentLimitExceededRes(parsedOutput);
        case "InvalidDocumentContent":
        case "com.amazonaws.ssm#InvalidDocumentContent":
            throw await de_InvalidDocumentContentRes(parsedOutput);
        case "InvalidDocumentSchemaVersion":
        case "com.amazonaws.ssm#InvalidDocumentSchemaVersion":
            throw await de_InvalidDocumentSchemaVersionRes(parsedOutput);
        case "MaxDocumentSizeExceeded":
        case "com.amazonaws.ssm#MaxDocumentSizeExceeded":
            throw await de_MaxDocumentSizeExceededRes(parsedOutput);
        case "IdempotentParameterMismatch":
        case "com.amazonaws.ssm#IdempotentParameterMismatch":
            throw await de_IdempotentParameterMismatchRes(parsedOutput);
        case "ResourceLimitExceededException":
        case "com.amazonaws.ssm#ResourceLimitExceededException":
            throw await de_ResourceLimitExceededExceptionRes(parsedOutput);
        case "OpsItemAccessDeniedException":
        case "com.amazonaws.ssm#OpsItemAccessDeniedException":
            throw await de_OpsItemAccessDeniedExceptionRes(parsedOutput);
        case "OpsItemAlreadyExistsException":
        case "com.amazonaws.ssm#OpsItemAlreadyExistsException":
            throw await de_OpsItemAlreadyExistsExceptionRes(parsedOutput);
        case "OpsMetadataAlreadyExistsException":
        case "com.amazonaws.ssm#OpsMetadataAlreadyExistsException":
            throw await de_OpsMetadataAlreadyExistsExceptionRes(parsedOutput);
        case "OpsMetadataInvalidArgumentException":
        case "com.amazonaws.ssm#OpsMetadataInvalidArgumentException":
            throw await de_OpsMetadataInvalidArgumentExceptionRes(parsedOutput);
        case "OpsMetadataLimitExceededException":
        case "com.amazonaws.ssm#OpsMetadataLimitExceededException":
            throw await de_OpsMetadataLimitExceededExceptionRes(parsedOutput);
        case "OpsMetadataTooManyUpdatesException":
        case "com.amazonaws.ssm#OpsMetadataTooManyUpdatesException":
            throw await de_OpsMetadataTooManyUpdatesExceptionRes(parsedOutput);
        case "ResourceDataSyncAlreadyExistsException":
        case "com.amazonaws.ssm#ResourceDataSyncAlreadyExistsException":
            throw await de_ResourceDataSyncAlreadyExistsExceptionRes(parsedOutput);
        case "ResourceDataSyncCountExceededException":
        case "com.amazonaws.ssm#ResourceDataSyncCountExceededException":
            throw await de_ResourceDataSyncCountExceededExceptionRes(parsedOutput);
        case "ResourceDataSyncInvalidConfigurationException":
        case "com.amazonaws.ssm#ResourceDataSyncInvalidConfigurationException":
            throw await de_ResourceDataSyncInvalidConfigurationExceptionRes(parsedOutput);
        case "InvalidActivation":
        case "com.amazonaws.ssm#InvalidActivation":
            throw await de_InvalidActivationRes(parsedOutput);
        case "InvalidActivationId":
        case "com.amazonaws.ssm#InvalidActivationId":
            throw await de_InvalidActivationIdRes(parsedOutput);
        case "AssociationDoesNotExist":
        case "com.amazonaws.ssm#AssociationDoesNotExist":
            throw await de_AssociationDoesNotExistRes(parsedOutput);
        case "AssociatedInstances":
        case "com.amazonaws.ssm#AssociatedInstances":
            throw await de_AssociatedInstancesRes(parsedOutput);
        case "InvalidDocumentOperation":
        case "com.amazonaws.ssm#InvalidDocumentOperation":
            throw await de_InvalidDocumentOperationRes(parsedOutput);
        case "InvalidDeleteInventoryParametersException":
        case "com.amazonaws.ssm#InvalidDeleteInventoryParametersException":
            throw await de_InvalidDeleteInventoryParametersExceptionRes(parsedOutput);
        case "InvalidInventoryRequestException":
        case "com.amazonaws.ssm#InvalidInventoryRequestException":
            throw await de_InvalidInventoryRequestExceptionRes(parsedOutput);
        case "InvalidOptionException":
        case "com.amazonaws.ssm#InvalidOptionException":
            throw await de_InvalidOptionExceptionRes(parsedOutput);
        case "InvalidTypeNameException":
        case "com.amazonaws.ssm#InvalidTypeNameException":
            throw await de_InvalidTypeNameExceptionRes(parsedOutput);
        case "OpsMetadataNotFoundException":
        case "com.amazonaws.ssm#OpsMetadataNotFoundException":
            throw await de_OpsMetadataNotFoundExceptionRes(parsedOutput);
        case "ParameterNotFound":
        case "com.amazonaws.ssm#ParameterNotFound":
            throw await de_ParameterNotFoundRes(parsedOutput);
        case "ResourceInUseException":
        case "com.amazonaws.ssm#ResourceInUseException":
            throw await de_ResourceInUseExceptionRes(parsedOutput);
        case "ResourceDataSyncNotFoundException":
        case "com.amazonaws.ssm#ResourceDataSyncNotFoundException":
            throw await de_ResourceDataSyncNotFoundExceptionRes(parsedOutput);
        case "MalformedResourcePolicyDocumentException":
        case "com.amazonaws.ssm#MalformedResourcePolicyDocumentException":
            throw await de_MalformedResourcePolicyDocumentExceptionRes(parsedOutput);
        case "ResourceNotFoundException":
        case "com.amazonaws.ssm#ResourceNotFoundException":
            throw await de_ResourceNotFoundExceptionRes(parsedOutput);
        case "ResourcePolicyConflictException":
        case "com.amazonaws.ssm#ResourcePolicyConflictException":
            throw await de_ResourcePolicyConflictExceptionRes(parsedOutput);
        case "ResourcePolicyInvalidParameterException":
        case "com.amazonaws.ssm#ResourcePolicyInvalidParameterException":
            throw await de_ResourcePolicyInvalidParameterExceptionRes(parsedOutput);
        case "ResourcePolicyNotFoundException":
        case "com.amazonaws.ssm#ResourcePolicyNotFoundException":
            throw await de_ResourcePolicyNotFoundExceptionRes(parsedOutput);
        case "TargetInUseException":
        case "com.amazonaws.ssm#TargetInUseException":
            throw await de_TargetInUseExceptionRes(parsedOutput);
        case "InvalidFilter":
        case "com.amazonaws.ssm#InvalidFilter":
            throw await de_InvalidFilterRes(parsedOutput);
        case "InvalidNextToken":
        case "com.amazonaws.ssm#InvalidNextToken":
            throw await de_InvalidNextTokenRes(parsedOutput);
        case "InvalidAssociationVersion":
        case "com.amazonaws.ssm#InvalidAssociationVersion":
            throw await de_InvalidAssociationVersionRes(parsedOutput);
        case "AssociationExecutionDoesNotExist":
        case "com.amazonaws.ssm#AssociationExecutionDoesNotExist":
            throw await de_AssociationExecutionDoesNotExistRes(parsedOutput);
        case "InvalidFilterKey":
        case "com.amazonaws.ssm#InvalidFilterKey":
            throw await de_InvalidFilterKeyRes(parsedOutput);
        case "InvalidFilterValue":
        case "com.amazonaws.ssm#InvalidFilterValue":
            throw await de_InvalidFilterValueRes(parsedOutput);
        case "AutomationExecutionNotFoundException":
        case "com.amazonaws.ssm#AutomationExecutionNotFoundException":
            throw await de_AutomationExecutionNotFoundExceptionRes(parsedOutput);
        case "InvalidPermissionType":
        case "com.amazonaws.ssm#InvalidPermissionType":
            throw await de_InvalidPermissionTypeRes(parsedOutput);
        case "UnsupportedOperatingSystem":
        case "com.amazonaws.ssm#UnsupportedOperatingSystem":
            throw await de_UnsupportedOperatingSystemRes(parsedOutput);
        case "InvalidInstanceInformationFilterValue":
        case "com.amazonaws.ssm#InvalidInstanceInformationFilterValue":
            throw await de_InvalidInstanceInformationFilterValueRes(parsedOutput);
        case "InvalidInstancePropertyFilterValue":
        case "com.amazonaws.ssm#InvalidInstancePropertyFilterValue":
            throw await de_InvalidInstancePropertyFilterValueRes(parsedOutput);
        case "InvalidDeletionIdException":
        case "com.amazonaws.ssm#InvalidDeletionIdException":
            throw await de_InvalidDeletionIdExceptionRes(parsedOutput);
        case "InvalidFilterOption":
        case "com.amazonaws.ssm#InvalidFilterOption":
            throw await de_InvalidFilterOptionRes(parsedOutput);
        case "OpsItemRelatedItemAssociationNotFoundException":
        case "com.amazonaws.ssm#OpsItemRelatedItemAssociationNotFoundException":
            throw await de_OpsItemRelatedItemAssociationNotFoundExceptionRes(parsedOutput);
        case "AccessDeniedException":
        case "com.amazonaws.ssm#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput);
        case "ThrottlingException":
        case "com.amazonaws.ssm#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput);
        case "ValidationException":
        case "com.amazonaws.ssm#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput);
        case "InvalidDocumentType":
        case "com.amazonaws.ssm#InvalidDocumentType":
            throw await de_InvalidDocumentTypeRes(parsedOutput);
        case "UnsupportedCalendarException":
        case "com.amazonaws.ssm#UnsupportedCalendarException":
            throw await de_UnsupportedCalendarExceptionRes(parsedOutput);
        case "InvalidPluginName":
        case "com.amazonaws.ssm#InvalidPluginName":
            throw await de_InvalidPluginNameRes(parsedOutput);
        case "InvocationDoesNotExist":
        case "com.amazonaws.ssm#InvocationDoesNotExist":
            throw await de_InvocationDoesNotExistRes(parsedOutput);
        case "UnsupportedFeatureRequiredException":
        case "com.amazonaws.ssm#UnsupportedFeatureRequiredException":
            throw await de_UnsupportedFeatureRequiredExceptionRes(parsedOutput);
        case "InvalidAggregatorException":
        case "com.amazonaws.ssm#InvalidAggregatorException":
            throw await de_InvalidAggregatorExceptionRes(parsedOutput);
        case "InvalidInventoryGroupException":
        case "com.amazonaws.ssm#InvalidInventoryGroupException":
            throw await de_InvalidInventoryGroupExceptionRes(parsedOutput);
        case "InvalidResultAttributeException":
        case "com.amazonaws.ssm#InvalidResultAttributeException":
            throw await de_InvalidResultAttributeExceptionRes(parsedOutput);
        case "InvalidKeyId":
        case "com.amazonaws.ssm#InvalidKeyId":
            throw await de_InvalidKeyIdRes(parsedOutput);
        case "ParameterVersionNotFound":
        case "com.amazonaws.ssm#ParameterVersionNotFound":
            throw await de_ParameterVersionNotFoundRes(parsedOutput);
        case "ServiceSettingNotFound":
        case "com.amazonaws.ssm#ServiceSettingNotFound":
            throw await de_ServiceSettingNotFoundRes(parsedOutput);
        case "ParameterVersionLabelLimitExceeded":
        case "com.amazonaws.ssm#ParameterVersionLabelLimitExceeded":
            throw await de_ParameterVersionLabelLimitExceededRes(parsedOutput);
        case "UnsupportedOperationException":
        case "com.amazonaws.ssm#UnsupportedOperationException":
            throw await de_UnsupportedOperationExceptionRes(parsedOutput);
        case "DocumentPermissionLimit":
        case "com.amazonaws.ssm#DocumentPermissionLimit":
            throw await de_DocumentPermissionLimitRes(parsedOutput);
        case "ComplianceTypeCountLimitExceededException":
        case "com.amazonaws.ssm#ComplianceTypeCountLimitExceededException":
            throw await de_ComplianceTypeCountLimitExceededExceptionRes(parsedOutput);
        case "InvalidItemContentException":
        case "com.amazonaws.ssm#InvalidItemContentException":
            throw await de_InvalidItemContentExceptionRes(parsedOutput);
        case "ItemSizeLimitExceededException":
        case "com.amazonaws.ssm#ItemSizeLimitExceededException":
            throw await de_ItemSizeLimitExceededExceptionRes(parsedOutput);
        case "TotalSizeLimitExceededException":
        case "com.amazonaws.ssm#TotalSizeLimitExceededException":
            throw await de_TotalSizeLimitExceededExceptionRes(parsedOutput);
        case "CustomSchemaCountLimitExceededException":
        case "com.amazonaws.ssm#CustomSchemaCountLimitExceededException":
            throw await de_CustomSchemaCountLimitExceededExceptionRes(parsedOutput);
        case "InvalidInventoryItemContextException":
        case "com.amazonaws.ssm#InvalidInventoryItemContextException":
            throw await de_InvalidInventoryItemContextExceptionRes(parsedOutput);
        case "ItemContentMismatchException":
        case "com.amazonaws.ssm#ItemContentMismatchException":
            throw await de_ItemContentMismatchExceptionRes(parsedOutput);
        case "SubTypeCountLimitExceededException":
        case "com.amazonaws.ssm#SubTypeCountLimitExceededException":
            throw await de_SubTypeCountLimitExceededExceptionRes(parsedOutput);
        case "UnsupportedInventoryItemContextException":
        case "com.amazonaws.ssm#UnsupportedInventoryItemContextException":
            throw await de_UnsupportedInventoryItemContextExceptionRes(parsedOutput);
        case "UnsupportedInventorySchemaVersionException":
        case "com.amazonaws.ssm#UnsupportedInventorySchemaVersionException":
            throw await de_UnsupportedInventorySchemaVersionExceptionRes(parsedOutput);
        case "HierarchyLevelLimitExceededException":
        case "com.amazonaws.ssm#HierarchyLevelLimitExceededException":
            throw await de_HierarchyLevelLimitExceededExceptionRes(parsedOutput);
        case "HierarchyTypeMismatchException":
        case "com.amazonaws.ssm#HierarchyTypeMismatchException":
            throw await de_HierarchyTypeMismatchExceptionRes(parsedOutput);
        case "IncompatiblePolicyException":
        case "com.amazonaws.ssm#IncompatiblePolicyException":
            throw await de_IncompatiblePolicyExceptionRes(parsedOutput);
        case "InvalidAllowedPatternException":
        case "com.amazonaws.ssm#InvalidAllowedPatternException":
            throw await de_InvalidAllowedPatternExceptionRes(parsedOutput);
        case "InvalidPolicyAttributeException":
        case "com.amazonaws.ssm#InvalidPolicyAttributeException":
            throw await de_InvalidPolicyAttributeExceptionRes(parsedOutput);
        case "InvalidPolicyTypeException":
        case "com.amazonaws.ssm#InvalidPolicyTypeException":
            throw await de_InvalidPolicyTypeExceptionRes(parsedOutput);
        case "ParameterAlreadyExists":
        case "com.amazonaws.ssm#ParameterAlreadyExists":
            throw await de_ParameterAlreadyExistsRes(parsedOutput);
        case "ParameterLimitExceeded":
        case "com.amazonaws.ssm#ParameterLimitExceeded":
            throw await de_ParameterLimitExceededRes(parsedOutput);
        case "ParameterMaxVersionLimitExceeded":
        case "com.amazonaws.ssm#ParameterMaxVersionLimitExceeded":
            throw await de_ParameterMaxVersionLimitExceededRes(parsedOutput);
        case "ParameterPatternMismatchException":
        case "com.amazonaws.ssm#ParameterPatternMismatchException":
            throw await de_ParameterPatternMismatchExceptionRes(parsedOutput);
        case "PoliciesLimitExceededException":
        case "com.amazonaws.ssm#PoliciesLimitExceededException":
            throw await de_PoliciesLimitExceededExceptionRes(parsedOutput);
        case "UnsupportedParameterType":
        case "com.amazonaws.ssm#UnsupportedParameterType":
            throw await de_UnsupportedParameterTypeRes(parsedOutput);
        case "ResourcePolicyLimitExceededException":
        case "com.amazonaws.ssm#ResourcePolicyLimitExceededException":
            throw await de_ResourcePolicyLimitExceededExceptionRes(parsedOutput);
        case "AlreadyExistsException":
        case "com.amazonaws.ssm#AlreadyExistsException":
            throw await de_AlreadyExistsExceptionRes(parsedOutput);
        case "FeatureNotAvailableException":
        case "com.amazonaws.ssm#FeatureNotAvailableException":
            throw await de_FeatureNotAvailableExceptionRes(parsedOutput);
        case "AutomationStepNotFoundException":
        case "com.amazonaws.ssm#AutomationStepNotFoundException":
            throw await de_AutomationStepNotFoundExceptionRes(parsedOutput);
        case "InvalidAutomationSignalException":
        case "com.amazonaws.ssm#InvalidAutomationSignalException":
            throw await de_InvalidAutomationSignalExceptionRes(parsedOutput);
        case "InvalidNotificationConfig":
        case "com.amazonaws.ssm#InvalidNotificationConfig":
            throw await de_InvalidNotificationConfigRes(parsedOutput);
        case "InvalidOutputFolder":
        case "com.amazonaws.ssm#InvalidOutputFolder":
            throw await de_InvalidOutputFolderRes(parsedOutput);
        case "InvalidRole":
        case "com.amazonaws.ssm#InvalidRole":
            throw await de_InvalidRoleRes(parsedOutput);
        case "ServiceQuotaExceededException":
        case "com.amazonaws.ssm#ServiceQuotaExceededException":
            throw await de_ServiceQuotaExceededExceptionRes(parsedOutput);
        case "InvalidAssociation":
        case "com.amazonaws.ssm#InvalidAssociation":
            throw await de_InvalidAssociationRes(parsedOutput);
        case "AutomationDefinitionNotFoundException":
        case "com.amazonaws.ssm#AutomationDefinitionNotFoundException":
            throw await de_AutomationDefinitionNotFoundExceptionRes(parsedOutput);
        case "AutomationDefinitionVersionNotFoundException":
        case "com.amazonaws.ssm#AutomationDefinitionVersionNotFoundException":
            throw await de_AutomationDefinitionVersionNotFoundExceptionRes(parsedOutput);
        case "AutomationExecutionLimitExceededException":
        case "com.amazonaws.ssm#AutomationExecutionLimitExceededException":
            throw await de_AutomationExecutionLimitExceededExceptionRes(parsedOutput);
        case "InvalidAutomationExecutionParametersException":
        case "com.amazonaws.ssm#InvalidAutomationExecutionParametersException":
            throw await de_InvalidAutomationExecutionParametersExceptionRes(parsedOutput);
        case "AutomationDefinitionNotApprovedException":
        case "com.amazonaws.ssm#AutomationDefinitionNotApprovedException":
            throw await de_AutomationDefinitionNotApprovedExceptionRes(parsedOutput);
        case "TargetNotConnected":
        case "com.amazonaws.ssm#TargetNotConnected":
            throw await de_TargetNotConnectedRes(parsedOutput);
        case "InvalidAutomationStatusUpdateException":
        case "com.amazonaws.ssm#InvalidAutomationStatusUpdateException":
            throw await de_InvalidAutomationStatusUpdateExceptionRes(parsedOutput);
        case "AssociationVersionLimitExceeded":
        case "com.amazonaws.ssm#AssociationVersionLimitExceeded":
            throw await de_AssociationVersionLimitExceededRes(parsedOutput);
        case "InvalidUpdate":
        case "com.amazonaws.ssm#InvalidUpdate":
            throw await de_InvalidUpdateRes(parsedOutput);
        case "StatusUnchanged":
        case "com.amazonaws.ssm#StatusUnchanged":
            throw await de_StatusUnchangedRes(parsedOutput);
        case "DocumentVersionLimitExceeded":
        case "com.amazonaws.ssm#DocumentVersionLimitExceeded":
            throw await de_DocumentVersionLimitExceededRes(parsedOutput);
        case "DuplicateDocumentContent":
        case "com.amazonaws.ssm#DuplicateDocumentContent":
            throw await de_DuplicateDocumentContentRes(parsedOutput);
        case "DuplicateDocumentVersionName":
        case "com.amazonaws.ssm#DuplicateDocumentVersionName":
            throw await de_DuplicateDocumentVersionNameRes(parsedOutput);
        case "OpsMetadataKeyLimitExceededException":
        case "com.amazonaws.ssm#OpsMetadataKeyLimitExceededException":
            throw await de_OpsMetadataKeyLimitExceededExceptionRes(parsedOutput);
        case "ResourceDataSyncConflictException":
        case "com.amazonaws.ssm#ResourceDataSyncConflictException":
            throw await de_ResourceDataSyncConflictExceptionRes(parsedOutput);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode,
            });
    }
};
const de_AccessDeniedExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AccessDeniedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AlreadyExistsExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AlreadyExistsException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AssociatedInstancesRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AssociatedInstances({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AssociationAlreadyExistsRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AssociationAlreadyExists({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AssociationDoesNotExistRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AssociationDoesNotExist({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AssociationExecutionDoesNotExistRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AssociationExecutionDoesNotExist({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AssociationLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AssociationLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AssociationVersionLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AssociationVersionLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AutomationDefinitionNotApprovedExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AutomationDefinitionNotApprovedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AutomationDefinitionNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AutomationDefinitionNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AutomationDefinitionVersionNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AutomationDefinitionVersionNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AutomationExecutionLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AutomationExecutionLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AutomationExecutionNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AutomationExecutionNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_AutomationStepNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new AutomationStepNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ComplianceTypeCountLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ComplianceTypeCountLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_CustomSchemaCountLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new CustomSchemaCountLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DocumentAlreadyExistsRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DocumentAlreadyExists({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DocumentLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DocumentLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DocumentPermissionLimitRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DocumentPermissionLimit({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DocumentVersionLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DocumentVersionLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DoesNotExistExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DoesNotExistException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DuplicateDocumentContentRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DuplicateDocumentContent({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DuplicateDocumentVersionNameRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DuplicateDocumentVersionName({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_DuplicateInstanceIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new DuplicateInstanceId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_FeatureNotAvailableExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new FeatureNotAvailableException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_HierarchyLevelLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new HierarchyLevelLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_HierarchyTypeMismatchExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new HierarchyTypeMismatchException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_IdempotentParameterMismatchRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new IdempotentParameterMismatch({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_IncompatiblePolicyExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new IncompatiblePolicyException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InternalServerErrorRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InternalServerError({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidActivationRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidActivation({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidActivationIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidActivationId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAggregatorExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAggregatorException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAllowedPatternExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAllowedPatternException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAssociationRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAssociation({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAssociationVersionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAssociationVersion({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAutomationExecutionParametersExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAutomationExecutionParametersException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAutomationSignalExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAutomationSignalException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidAutomationStatusUpdateExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidAutomationStatusUpdateException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidCommandIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidCommandId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDeleteInventoryParametersExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDeleteInventoryParametersException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDeletionIdExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDeletionIdException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDocumentRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDocument({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDocumentContentRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDocumentContent({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDocumentOperationRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDocumentOperation({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDocumentSchemaVersionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDocumentSchemaVersion({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDocumentTypeRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDocumentType({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidDocumentVersionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidDocumentVersion({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidFilterRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidFilter({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidFilterKeyRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidFilterKey({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidFilterOptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidFilterOption({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidFilterValueRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidFilterValue({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidInstanceIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidInstanceId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidInstanceInformationFilterValueRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidInstanceInformationFilterValue({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidInstancePropertyFilterValueRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidInstancePropertyFilterValue({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidInventoryGroupExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidInventoryGroupException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidInventoryItemContextExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidInventoryItemContextException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidInventoryRequestExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidInventoryRequestException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidItemContentExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidItemContentException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidKeyIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidKeyId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidNextTokenRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidNextToken({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidNotificationConfigRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidNotificationConfig({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidOptionExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidOptionException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidOutputFolderRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidOutputFolder({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidOutputLocationRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidOutputLocation({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidParametersRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidParameters({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidPermissionTypeRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidPermissionType({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidPluginNameRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidPluginName({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidPolicyAttributeExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidPolicyAttributeException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidPolicyTypeExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidPolicyTypeException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidResourceIdRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidResourceId({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidResourceTypeRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidResourceType({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidResultAttributeExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidResultAttributeException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidRoleRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidRole({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidScheduleRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidSchedule({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidTagRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidTag({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidTargetRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidTarget({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidTargetMapsRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidTargetMaps({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidTypeNameExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidTypeNameException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvalidUpdateRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvalidUpdate({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_InvocationDoesNotExistRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new InvocationDoesNotExist({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ItemContentMismatchExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ItemContentMismatchException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ItemSizeLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ItemSizeLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_MalformedResourcePolicyDocumentExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new MalformedResourcePolicyDocumentException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_MaxDocumentSizeExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new MaxDocumentSizeExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemAccessDeniedExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemAccessDeniedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemAlreadyExistsExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemAlreadyExistsException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemConflictExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemConflictException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemInvalidParameterExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemInvalidParameterException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemRelatedItemAlreadyExistsExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemRelatedItemAlreadyExistsException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsItemRelatedItemAssociationNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsItemRelatedItemAssociationNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsMetadataAlreadyExistsExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsMetadataAlreadyExistsException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsMetadataInvalidArgumentExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsMetadataInvalidArgumentException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsMetadataKeyLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsMetadataKeyLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsMetadataLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsMetadataLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsMetadataNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsMetadataNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_OpsMetadataTooManyUpdatesExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new OpsMetadataTooManyUpdatesException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterAlreadyExistsRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterAlreadyExists({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterMaxVersionLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterMaxVersionLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterNotFoundRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterNotFound({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterPatternMismatchExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterPatternMismatchException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterVersionLabelLimitExceededRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterVersionLabelLimitExceeded({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ParameterVersionNotFoundRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ParameterVersionNotFound({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_PoliciesLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new PoliciesLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceDataSyncAlreadyExistsExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceDataSyncAlreadyExistsException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceDataSyncConflictExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceDataSyncConflictException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceDataSyncCountExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceDataSyncCountExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceDataSyncInvalidConfigurationExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceDataSyncInvalidConfigurationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceDataSyncNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceDataSyncNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceInUseExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceInUseException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourceNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourceNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourcePolicyConflictExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourcePolicyConflictException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourcePolicyInvalidParameterExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourcePolicyInvalidParameterException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourcePolicyLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourcePolicyLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ResourcePolicyNotFoundExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ResourcePolicyNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ServiceQuotaExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ServiceQuotaExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ServiceSettingNotFoundRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ServiceSettingNotFound({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_StatusUnchangedRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new StatusUnchanged({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_SubTypeCountLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new SubTypeCountLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_TargetInUseExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new TargetInUseException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_TargetNotConnectedRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new TargetNotConnected({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ThrottlingExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ThrottlingException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_TooManyTagsErrorRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new TooManyTagsError({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_TooManyUpdatesRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new TooManyUpdates({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_TotalSizeLimitExceededExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new TotalSizeLimitExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedCalendarExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedCalendarException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedFeatureRequiredExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedFeatureRequiredException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedInventoryItemContextExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedInventoryItemContextException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedInventorySchemaVersionExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedInventorySchemaVersionException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedOperatingSystemRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedOperatingSystem({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedOperationExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedOperationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedParameterTypeRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedParameterType({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_UnsupportedPlatformTypeRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new UnsupportedPlatformType({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const de_ValidationExceptionRes = async (parsedOutput, context) => {
    const body = parsedOutput.body;
    const deserialized = smithyClient._json(body);
    const exception = new ValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...deserialized,
    });
    return smithyClient.decorateServiceException(exception, body);
};
const se_AssociationStatus = (input, context) => {
    return smithyClient.take(input, {
        AdditionalInfo: [],
        Date: (_) => _.getTime() / 1_000,
        Message: [],
        Name: [],
    });
};
const se_ComplianceExecutionSummary = (input, context) => {
    return smithyClient.take(input, {
        ExecutionId: [],
        ExecutionTime: (_) => _.getTime() / 1_000,
        ExecutionType: [],
    });
};
const se_CreateActivationRequest = (input, context) => {
    return smithyClient.take(input, {
        DefaultInstanceName: [],
        Description: [],
        ExpirationDate: (_) => _.getTime() / 1_000,
        IamRole: [],
        RegistrationLimit: [],
        RegistrationMetadata: smithyClient._json,
        Tags: smithyClient._json,
    });
};
const se_CreateMaintenanceWindowRequest = (input, context) => {
    return smithyClient.take(input, {
        AllowUnassociatedTargets: [],
        ClientToken: [true, (_) => _ ?? uuid.v4()],
        Cutoff: [],
        Description: [],
        Duration: [],
        EndDate: [],
        Name: [],
        Schedule: [],
        ScheduleOffset: [],
        ScheduleTimezone: [],
        StartDate: [],
        Tags: smithyClient._json,
    });
};
const se_CreateOpsItemRequest = (input, context) => {
    return smithyClient.take(input, {
        AccountId: [],
        ActualEndTime: (_) => _.getTime() / 1_000,
        ActualStartTime: (_) => _.getTime() / 1_000,
        Category: [],
        Description: [],
        Notifications: smithyClient._json,
        OperationalData: smithyClient._json,
        OpsItemType: [],
        PlannedEndTime: (_) => _.getTime() / 1_000,
        PlannedStartTime: (_) => _.getTime() / 1_000,
        Priority: [],
        RelatedOpsItems: smithyClient._json,
        Severity: [],
        Source: [],
        Tags: smithyClient._json,
        Title: [],
    });
};
const se_CreatePatchBaselineRequest = (input, context) => {
    return smithyClient.take(input, {
        ApprovalRules: smithyClient._json,
        ApprovedPatches: smithyClient._json,
        ApprovedPatchesComplianceLevel: [],
        ApprovedPatchesEnableNonSecurity: [],
        AvailableSecurityUpdatesComplianceStatus: [],
        ClientToken: [true, (_) => _ ?? uuid.v4()],
        Description: [],
        GlobalFilters: smithyClient._json,
        Name: [],
        OperatingSystem: [],
        RejectedPatches: smithyClient._json,
        RejectedPatchesAction: [],
        Sources: smithyClient._json,
        Tags: smithyClient._json,
    });
};
const se_DeleteInventoryRequest = (input, context) => {
    return smithyClient.take(input, {
        ClientToken: [true, (_) => _ ?? uuid.v4()],
        DryRun: [],
        SchemaDeleteOption: [],
        TypeName: [],
    });
};
const se_GetInventoryRequest = (input, context) => {
    return smithyClient.take(input, {
        Aggregators: (_) => se_InventoryAggregatorList(_),
        Filters: smithyClient._json,
        MaxResults: [],
        NextToken: [],
        ResultAttributes: smithyClient._json,
    });
};
const se_GetOpsSummaryRequest = (input, context) => {
    return smithyClient.take(input, {
        Aggregators: (_) => se_OpsAggregatorList(_),
        Filters: smithyClient._json,
        MaxResults: [],
        NextToken: [],
        ResultAttributes: smithyClient._json,
        SyncName: [],
    });
};
const se_InventoryAggregator = (input, context) => {
    return smithyClient.take(input, {
        Aggregators: (_) => se_InventoryAggregatorList(_),
        Expression: [],
        Groups: smithyClient._json,
    });
};
const se_InventoryAggregatorList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return se_InventoryAggregator(entry);
    });
};
const se_ListNodesSummaryRequest = (input, context) => {
    return smithyClient.take(input, {
        Aggregators: (_) => se_NodeAggregatorList(_),
        Filters: smithyClient._json,
        MaxResults: [],
        NextToken: [],
        SyncName: [],
    });
};
const se_MaintenanceWindowLambdaParameters = (input, context) => {
    return smithyClient.take(input, {
        ClientContext: [],
        Payload: context.base64Encoder,
        Qualifier: [],
    });
};
const se_MaintenanceWindowTaskInvocationParameters = (input, context) => {
    return smithyClient.take(input, {
        Automation: smithyClient._json,
        Lambda: (_) => se_MaintenanceWindowLambdaParameters(_, context),
        RunCommand: smithyClient._json,
        StepFunctions: smithyClient._json,
    });
};
const se_NodeAggregator = (input, context) => {
    return smithyClient.take(input, {
        AggregatorType: [],
        Aggregators: (_) => se_NodeAggregatorList(_),
        AttributeName: [],
        TypeName: [],
    });
};
const se_NodeAggregatorList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return se_NodeAggregator(entry);
    });
};
const se_OpsAggregator = (input, context) => {
    return smithyClient.take(input, {
        AggregatorType: [],
        Aggregators: (_) => se_OpsAggregatorList(_),
        AttributeName: [],
        Filters: smithyClient._json,
        TypeName: [],
        Values: smithyClient._json,
    });
};
const se_OpsAggregatorList = (input, context) => {
    return input
        .filter((e) => e != null)
        .map((entry) => {
        return se_OpsAggregator(entry);
    });
};
const se_PutComplianceItemsRequest = (input, context) => {
    return smithyClient.take(input, {
        ComplianceType: [],
        ExecutionSummary: (_) => se_ComplianceExecutionSummary(_),
        ItemContentHash: [],
        Items: smithyClient._json,
        ResourceId: [],
        ResourceType: [],
        UploadType: [],
    });
};
const se_RegisterTargetWithMaintenanceWindowRequest = (input, context) => {
    return smithyClient.take(input, {
        ClientToken: [true, (_) => _ ?? uuid.v4()],
        Description: [],
        Name: [],
        OwnerInformation: [],
        ResourceType: [],
        Targets: smithyClient._json,
        WindowId: [],
    });
};
const se_RegisterTaskWithMaintenanceWindowRequest = (input, context) => {
    return smithyClient.take(input, {
        AlarmConfiguration: smithyClient._json,
        ClientToken: [true, (_) => _ ?? uuid.v4()],
        CutoffBehavior: [],
        Description: [],
        LoggingInfo: smithyClient._json,
        MaxConcurrency: [],
        MaxErrors: [],
        Name: [],
        Priority: [],
        ServiceRoleArn: [],
        Targets: smithyClient._json,
        TaskArn: [],
        TaskInvocationParameters: (_) => se_MaintenanceWindowTaskInvocationParameters(_, context),
        TaskParameters: smithyClient._json,
        TaskType: [],
        WindowId: [],
    });
};
const se_StartChangeRequestExecutionRequest = (input, context) => {
    return smithyClient.take(input, {
        AutoApprove: [],
        ChangeDetails: [],
        ChangeRequestName: [],
        ClientToken: [],
        DocumentName: [],
        DocumentVersion: [],
        Parameters: smithyClient._json,
        Runbooks: smithyClient._json,
        ScheduledEndTime: (_) => _.getTime() / 1_000,
        ScheduledTime: (_) => _.getTime() / 1_000,
        Tags: smithyClient._json,
    });
};
const se_UpdateAssociationStatusRequest = (input, context) => {
    return smithyClient.take(input, {
        AssociationStatus: (_) => se_AssociationStatus(_),
        InstanceId: [],
        Name: [],
    });
};
const se_UpdateMaintenanceWindowTaskRequest = (input, context) => {
    return smithyClient.take(input, {
        AlarmConfiguration: smithyClient._json,
        CutoffBehavior: [],
        Description: [],
        LoggingInfo: smithyClient._json,
        MaxConcurrency: [],
        MaxErrors: [],
        Name: [],
        Priority: [],
        Replace: [],
        ServiceRoleArn: [],
        Targets: smithyClient._json,
        TaskArn: [],
        TaskInvocationParameters: (_) => se_MaintenanceWindowTaskInvocationParameters(_, context),
        TaskParameters: smithyClient._json,
        WindowId: [],
        WindowTaskId: [],
    });
};
const se_UpdateOpsItemRequest = (input, context) => {
    return smithyClient.take(input, {
        ActualEndTime: (_) => _.getTime() / 1_000,
        ActualStartTime: (_) => _.getTime() / 1_000,
        Category: [],
        Description: [],
        Notifications: smithyClient._json,
        OperationalData: smithyClient._json,
        OperationalDataToDelete: smithyClient._json,
        OpsItemArn: [],
        OpsItemId: [],
        PlannedEndTime: (_) => _.getTime() / 1_000,
        PlannedStartTime: (_) => _.getTime() / 1_000,
        Priority: [],
        RelatedOpsItems: smithyClient._json,
        Severity: [],
        Status: [],
        Title: [],
    });
};
const de_Activation = (output, context) => {
    return smithyClient.take(output, {
        ActivationId: smithyClient.expectString,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DefaultInstanceName: smithyClient.expectString,
        Description: smithyClient.expectString,
        ExpirationDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Expired: smithyClient.expectBoolean,
        IamRole: smithyClient.expectString,
        RegistrationLimit: smithyClient.expectInt32,
        RegistrationsCount: smithyClient.expectInt32,
        Tags: smithyClient._json,
    });
};
const de_ActivationList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Activation(entry);
    });
    return retVal;
};
const de_Association = (output, context) => {
    return smithyClient.take(output, {
        AssociationId: smithyClient.expectString,
        AssociationName: smithyClient.expectString,
        AssociationVersion: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        Duration: smithyClient.expectInt32,
        InstanceId: smithyClient.expectString,
        LastExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        Overview: smithyClient._json,
        ScheduleExpression: smithyClient.expectString,
        ScheduleOffset: smithyClient.expectInt32,
        TargetMaps: smithyClient._json,
        Targets: smithyClient._json,
    });
};
const de_AssociationDescription = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        ApplyOnlyAtCronInterval: smithyClient.expectBoolean,
        AssociationId: smithyClient.expectString,
        AssociationName: smithyClient.expectString,
        AssociationVersion: smithyClient.expectString,
        AutomationTargetParameterName: smithyClient.expectString,
        CalendarNames: smithyClient._json,
        ComplianceSeverity: smithyClient.expectString,
        Date: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DocumentVersion: smithyClient.expectString,
        Duration: smithyClient.expectInt32,
        InstanceId: smithyClient.expectString,
        LastExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastSuccessfulExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastUpdateAssociationDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Name: smithyClient.expectString,
        OutputLocation: smithyClient._json,
        Overview: smithyClient._json,
        Parameters: smithyClient._json,
        ScheduleExpression: smithyClient.expectString,
        ScheduleOffset: smithyClient.expectInt32,
        Status: (_) => de_AssociationStatus(_),
        SyncCompliance: smithyClient.expectString,
        TargetLocations: smithyClient._json,
        TargetMaps: smithyClient._json,
        Targets: smithyClient._json,
        TriggeredAlarms: smithyClient._json,
    });
};
const de_AssociationDescriptionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_AssociationDescription(entry);
    });
    return retVal;
};
const de_AssociationExecution = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        AssociationId: smithyClient.expectString,
        AssociationVersion: smithyClient.expectString,
        CreatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DetailedStatus: smithyClient.expectString,
        ExecutionId: smithyClient.expectString,
        LastExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ResourceCountByStatus: smithyClient.expectString,
        Status: smithyClient.expectString,
        TriggeredAlarms: smithyClient._json,
    });
};
const de_AssociationExecutionsList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_AssociationExecution(entry);
    });
    return retVal;
};
const de_AssociationExecutionTarget = (output, context) => {
    return smithyClient.take(output, {
        AssociationId: smithyClient.expectString,
        AssociationVersion: smithyClient.expectString,
        DetailedStatus: smithyClient.expectString,
        ExecutionId: smithyClient.expectString,
        LastExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        OutputSource: smithyClient._json,
        ResourceId: smithyClient.expectString,
        ResourceType: smithyClient.expectString,
        Status: smithyClient.expectString,
    });
};
const de_AssociationExecutionTargetsList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_AssociationExecutionTarget(entry);
    });
    return retVal;
};
const de_AssociationList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Association(entry);
    });
    return retVal;
};
const de_AssociationStatus = (output, context) => {
    return smithyClient.take(output, {
        AdditionalInfo: smithyClient.expectString,
        Date: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Message: smithyClient.expectString,
        Name: smithyClient.expectString,
    });
};
const de_AssociationVersionInfo = (output, context) => {
    return smithyClient.take(output, {
        ApplyOnlyAtCronInterval: smithyClient.expectBoolean,
        AssociationId: smithyClient.expectString,
        AssociationName: smithyClient.expectString,
        AssociationVersion: smithyClient.expectString,
        CalendarNames: smithyClient._json,
        ComplianceSeverity: smithyClient.expectString,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DocumentVersion: smithyClient.expectString,
        Duration: smithyClient.expectInt32,
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Name: smithyClient.expectString,
        OutputLocation: smithyClient._json,
        Parameters: smithyClient._json,
        ScheduleExpression: smithyClient.expectString,
        ScheduleOffset: smithyClient.expectInt32,
        SyncCompliance: smithyClient.expectString,
        TargetLocations: smithyClient._json,
        TargetMaps: smithyClient._json,
        Targets: smithyClient._json,
    });
};
const de_AssociationVersionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_AssociationVersionInfo(entry);
    });
    return retVal;
};
const de_AutomationExecution = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        AssociationId: smithyClient.expectString,
        AutomationExecutionId: smithyClient.expectString,
        AutomationExecutionStatus: smithyClient.expectString,
        AutomationSubtype: smithyClient.expectString,
        ChangeRequestName: smithyClient.expectString,
        CurrentAction: smithyClient.expectString,
        CurrentStepName: smithyClient.expectString,
        DocumentName: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        ExecutedBy: smithyClient.expectString,
        ExecutionEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        FailureMessage: smithyClient.expectString,
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Mode: smithyClient.expectString,
        OpsItemId: smithyClient.expectString,
        Outputs: smithyClient._json,
        Parameters: smithyClient._json,
        ParentAutomationExecutionId: smithyClient.expectString,
        ProgressCounters: smithyClient._json,
        ResolvedTargets: smithyClient._json,
        Runbooks: smithyClient._json,
        ScheduledTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        StepExecutions: (_) => de_StepExecutionList(_),
        StepExecutionsTruncated: smithyClient.expectBoolean,
        Target: smithyClient.expectString,
        TargetLocations: smithyClient._json,
        TargetLocationsURL: smithyClient.expectString,
        TargetMaps: smithyClient._json,
        TargetParameterName: smithyClient.expectString,
        Targets: smithyClient._json,
        TriggeredAlarms: smithyClient._json,
        Variables: smithyClient._json,
    });
};
const de_AutomationExecutionMetadata = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        AssociationId: smithyClient.expectString,
        AutomationExecutionId: smithyClient.expectString,
        AutomationExecutionStatus: smithyClient.expectString,
        AutomationSubtype: smithyClient.expectString,
        AutomationType: smithyClient.expectString,
        ChangeRequestName: smithyClient.expectString,
        CurrentAction: smithyClient.expectString,
        CurrentStepName: smithyClient.expectString,
        DocumentName: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        ExecutedBy: smithyClient.expectString,
        ExecutionEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        FailureMessage: smithyClient.expectString,
        LogFile: smithyClient.expectString,
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Mode: smithyClient.expectString,
        OpsItemId: smithyClient.expectString,
        Outputs: smithyClient._json,
        ParentAutomationExecutionId: smithyClient.expectString,
        ResolvedTargets: smithyClient._json,
        Runbooks: smithyClient._json,
        ScheduledTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Target: smithyClient.expectString,
        TargetLocationsURL: smithyClient.expectString,
        TargetMaps: smithyClient._json,
        TargetParameterName: smithyClient.expectString,
        Targets: smithyClient._json,
        TriggeredAlarms: smithyClient._json,
    });
};
const de_AutomationExecutionMetadataList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_AutomationExecutionMetadata(entry);
    });
    return retVal;
};
const de_Command = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        CloudWatchOutputConfig: smithyClient._json,
        CommandId: smithyClient.expectString,
        Comment: smithyClient.expectString,
        CompletedCount: smithyClient.expectInt32,
        DeliveryTimedOutCount: smithyClient.expectInt32,
        DocumentName: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        ErrorCount: smithyClient.expectInt32,
        ExpiresAfter: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        InstanceIds: smithyClient._json,
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        NotificationConfig: smithyClient._json,
        OutputS3BucketName: smithyClient.expectString,
        OutputS3KeyPrefix: smithyClient.expectString,
        OutputS3Region: smithyClient.expectString,
        Parameters: smithyClient._json,
        RequestedDateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ServiceRole: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TargetCount: smithyClient.expectInt32,
        Targets: smithyClient._json,
        TimeoutSeconds: smithyClient.expectInt32,
        TriggeredAlarms: smithyClient._json,
    });
};
const de_CommandInvocation = (output, context) => {
    return smithyClient.take(output, {
        CloudWatchOutputConfig: smithyClient._json,
        CommandId: smithyClient.expectString,
        CommandPlugins: (_) => de_CommandPluginList(_),
        Comment: smithyClient.expectString,
        DocumentName: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        InstanceId: smithyClient.expectString,
        InstanceName: smithyClient.expectString,
        NotificationConfig: smithyClient._json,
        RequestedDateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ServiceRole: smithyClient.expectString,
        StandardErrorUrl: smithyClient.expectString,
        StandardOutputUrl: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TraceOutput: smithyClient.expectString,
    });
};
const de_CommandInvocationList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_CommandInvocation(entry);
    });
    return retVal;
};
const de_CommandList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Command(entry);
    });
    return retVal;
};
const de_CommandPlugin = (output, context) => {
    return smithyClient.take(output, {
        Name: smithyClient.expectString,
        Output: smithyClient.expectString,
        OutputS3BucketName: smithyClient.expectString,
        OutputS3KeyPrefix: smithyClient.expectString,
        OutputS3Region: smithyClient.expectString,
        ResponseCode: smithyClient.expectInt32,
        ResponseFinishDateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ResponseStartDateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        StandardErrorUrl: smithyClient.expectString,
        StandardOutputUrl: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
    });
};
const de_CommandPluginList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_CommandPlugin(entry);
    });
    return retVal;
};
const de_ComplianceExecutionSummary = (output, context) => {
    return smithyClient.take(output, {
        ExecutionId: smithyClient.expectString,
        ExecutionTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionType: smithyClient.expectString,
    });
};
const de_ComplianceItem = (output, context) => {
    return smithyClient.take(output, {
        ComplianceType: smithyClient.expectString,
        Details: smithyClient._json,
        ExecutionSummary: (_) => de_ComplianceExecutionSummary(_),
        Id: smithyClient.expectString,
        ResourceId: smithyClient.expectString,
        ResourceType: smithyClient.expectString,
        Severity: smithyClient.expectString,
        Status: smithyClient.expectString,
        Title: smithyClient.expectString,
    });
};
const de_ComplianceItemList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ComplianceItem(entry);
    });
    return retVal;
};
const de_CreateAssociationBatchResult = (output, context) => {
    return smithyClient.take(output, {
        Failed: smithyClient._json,
        Successful: (_) => de_AssociationDescriptionList(_),
    });
};
const de_CreateAssociationResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationDescription: (_) => de_AssociationDescription(_),
    });
};
const de_CreateDocumentResult = (output, context) => {
    return smithyClient.take(output, {
        DocumentDescription: (_) => de_DocumentDescription(_),
    });
};
const de_Credentials = (output, context) => {
    return smithyClient.take(output, {
        AccessKeyId: smithyClient.expectString,
        ExpirationTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        SecretAccessKey: smithyClient.expectString,
        SessionToken: smithyClient.expectString,
    });
};
const de_DescribeActivationsResult = (output, context) => {
    return smithyClient.take(output, {
        ActivationList: (_) => de_ActivationList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeAssociationExecutionsResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationExecutions: (_) => de_AssociationExecutionsList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeAssociationExecutionTargetsResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationExecutionTargets: (_) => de_AssociationExecutionTargetsList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeAssociationResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationDescription: (_) => de_AssociationDescription(_),
    });
};
const de_DescribeAutomationExecutionsResult = (output, context) => {
    return smithyClient.take(output, {
        AutomationExecutionMetadataList: (_) => de_AutomationExecutionMetadataList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeAutomationStepExecutionsResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        StepExecutions: (_) => de_StepExecutionList(_),
    });
};
const de_DescribeAvailablePatchesResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Patches: (_) => de_PatchList(_),
    });
};
const de_DescribeDocumentResult = (output, context) => {
    return smithyClient.take(output, {
        Document: (_) => de_DocumentDescription(_),
    });
};
const de_DescribeEffectivePatchesForPatchBaselineResult = (output, context) => {
    return smithyClient.take(output, {
        EffectivePatches: (_) => de_EffectivePatchList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeInstanceAssociationsStatusResult = (output, context) => {
    return smithyClient.take(output, {
        InstanceAssociationStatusInfos: (_) => de_InstanceAssociationStatusInfos(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeInstanceInformationResult = (output, context) => {
    return smithyClient.take(output, {
        InstanceInformationList: (_) => de_InstanceInformationList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeInstancePatchesResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Patches: (_) => de_PatchComplianceDataList(_),
    });
};
const de_DescribeInstancePatchStatesForPatchGroupResult = (output, context) => {
    return smithyClient.take(output, {
        InstancePatchStates: (_) => de_InstancePatchStatesList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeInstancePatchStatesResult = (output, context) => {
    return smithyClient.take(output, {
        InstancePatchStates: (_) => de_InstancePatchStateList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeInstancePropertiesResult = (output, context) => {
    return smithyClient.take(output, {
        InstanceProperties: (_) => de_InstanceProperties(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeInventoryDeletionsResult = (output, context) => {
    return smithyClient.take(output, {
        InventoryDeletions: (_) => de_InventoryDeletionsList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_DescribeMaintenanceWindowExecutionsResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        WindowExecutions: (_) => de_MaintenanceWindowExecutionList(_),
    });
};
const de_DescribeMaintenanceWindowExecutionTaskInvocationsResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        WindowExecutionTaskInvocationIdentities: (_) => de_MaintenanceWindowExecutionTaskInvocationIdentityList(_),
    });
};
const de_DescribeMaintenanceWindowExecutionTasksResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        WindowExecutionTaskIdentities: (_) => de_MaintenanceWindowExecutionTaskIdentityList(_),
    });
};
const de_DescribeOpsItemsResponse = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        OpsItemSummaries: (_) => de_OpsItemSummaries(_),
    });
};
const de_DescribeParametersResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Parameters: (_) => de_ParameterMetadataList(_),
    });
};
const de_DescribeSessionsResponse = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Sessions: (_) => de_SessionList(_),
    });
};
const de_DocumentDescription = (output, context) => {
    return smithyClient.take(output, {
        ApprovedVersion: smithyClient.expectString,
        AttachmentsInformation: smithyClient._json,
        Author: smithyClient.expectString,
        Category: smithyClient._json,
        CategoryEnum: smithyClient._json,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DefaultVersion: smithyClient.expectString,
        Description: smithyClient.expectString,
        DisplayName: smithyClient.expectString,
        DocumentFormat: smithyClient.expectString,
        DocumentType: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        Hash: smithyClient.expectString,
        HashType: smithyClient.expectString,
        LatestVersion: smithyClient.expectString,
        Name: smithyClient.expectString,
        Owner: smithyClient.expectString,
        Parameters: smithyClient._json,
        PendingReviewVersion: smithyClient.expectString,
        PlatformTypes: smithyClient._json,
        Requires: smithyClient._json,
        ReviewInformation: (_) => de_ReviewInformationList(_),
        ReviewStatus: smithyClient.expectString,
        SchemaVersion: smithyClient.expectString,
        Sha1: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusInformation: smithyClient.expectString,
        Tags: smithyClient._json,
        TargetType: smithyClient.expectString,
        VersionName: smithyClient.expectString,
    });
};
const de_DocumentIdentifier = (output, context) => {
    return smithyClient.take(output, {
        Author: smithyClient.expectString,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DisplayName: smithyClient.expectString,
        DocumentFormat: smithyClient.expectString,
        DocumentType: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        Name: smithyClient.expectString,
        Owner: smithyClient.expectString,
        PlatformTypes: smithyClient._json,
        Requires: smithyClient._json,
        ReviewStatus: smithyClient.expectString,
        SchemaVersion: smithyClient.expectString,
        Tags: smithyClient._json,
        TargetType: smithyClient.expectString,
        VersionName: smithyClient.expectString,
    });
};
const de_DocumentIdentifierList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_DocumentIdentifier(entry);
    });
    return retVal;
};
const de_DocumentMetadataResponseInfo = (output, context) => {
    return smithyClient.take(output, {
        ReviewerResponse: (_) => de_DocumentReviewerResponseList(_),
    });
};
const de_DocumentReviewerResponseList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_DocumentReviewerResponseSource(entry);
    });
    return retVal;
};
const de_DocumentReviewerResponseSource = (output, context) => {
    return smithyClient.take(output, {
        Comment: smithyClient._json,
        CreateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ReviewStatus: smithyClient.expectString,
        Reviewer: smithyClient.expectString,
        UpdatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
    });
};
const de_DocumentVersionInfo = (output, context) => {
    return smithyClient.take(output, {
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DisplayName: smithyClient.expectString,
        DocumentFormat: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        IsDefaultVersion: smithyClient.expectBoolean,
        Name: smithyClient.expectString,
        ReviewStatus: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusInformation: smithyClient.expectString,
        VersionName: smithyClient.expectString,
    });
};
const de_DocumentVersionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_DocumentVersionInfo(entry);
    });
    return retVal;
};
const de_EffectivePatch = (output, context) => {
    return smithyClient.take(output, {
        Patch: (_) => de_Patch(_),
        PatchStatus: (_) => de_PatchStatus(_),
    });
};
const de_EffectivePatchList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_EffectivePatch(entry);
    });
    return retVal;
};
const de_GetAccessTokenResponse = (output, context) => {
    return smithyClient.take(output, {
        AccessRequestStatus: smithyClient.expectString,
        Credentials: (_) => de_Credentials(_),
    });
};
const de_GetAutomationExecutionResult = (output, context) => {
    return smithyClient.take(output, {
        AutomationExecution: (_) => de_AutomationExecution(_),
    });
};
const de_GetDocumentResult = (output, context) => {
    return smithyClient.take(output, {
        AttachmentsContent: smithyClient._json,
        Content: smithyClient.expectString,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DisplayName: smithyClient.expectString,
        DocumentFormat: smithyClient.expectString,
        DocumentType: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        Name: smithyClient.expectString,
        Requires: smithyClient._json,
        ReviewStatus: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusInformation: smithyClient.expectString,
        VersionName: smithyClient.expectString,
    });
};
const de_GetExecutionPreviewResponse = (output, context) => {
    return smithyClient.take(output, {
        EndedAt: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionPreview: (_) => smithyClient._json(core$1.awsExpectUnion(_)),
        ExecutionPreviewId: smithyClient.expectString,
        Status: smithyClient.expectString,
        StatusMessage: smithyClient.expectString,
    });
};
const de_GetMaintenanceWindowExecutionResult = (output, context) => {
    return smithyClient.take(output, {
        EndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        StartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TaskIds: smithyClient._json,
        WindowExecutionId: smithyClient.expectString,
    });
};
const de_GetMaintenanceWindowExecutionTaskInvocationResult = (output, context) => {
    return smithyClient.take(output, {
        EndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionId: smithyClient.expectString,
        InvocationId: smithyClient.expectString,
        OwnerInformation: smithyClient.expectString,
        Parameters: smithyClient.expectString,
        StartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TaskExecutionId: smithyClient.expectString,
        TaskType: smithyClient.expectString,
        WindowExecutionId: smithyClient.expectString,
        WindowTargetId: smithyClient.expectString,
    });
};
const de_GetMaintenanceWindowExecutionTaskResult = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        EndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Priority: smithyClient.expectInt32,
        ServiceRole: smithyClient.expectString,
        StartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TaskArn: smithyClient.expectString,
        TaskExecutionId: smithyClient.expectString,
        TaskParameters: smithyClient._json,
        TriggeredAlarms: smithyClient._json,
        Type: smithyClient.expectString,
        WindowExecutionId: smithyClient.expectString,
    });
};
const de_GetMaintenanceWindowResult = (output, context) => {
    return smithyClient.take(output, {
        AllowUnassociatedTargets: smithyClient.expectBoolean,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Cutoff: smithyClient.expectInt32,
        Description: smithyClient.expectString,
        Duration: smithyClient.expectInt32,
        Enabled: smithyClient.expectBoolean,
        EndDate: smithyClient.expectString,
        ModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        NextExecutionTime: smithyClient.expectString,
        Schedule: smithyClient.expectString,
        ScheduleOffset: smithyClient.expectInt32,
        ScheduleTimezone: smithyClient.expectString,
        StartDate: smithyClient.expectString,
        WindowId: smithyClient.expectString,
    });
};
const de_GetMaintenanceWindowTaskResult = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        CutoffBehavior: smithyClient.expectString,
        Description: smithyClient.expectString,
        LoggingInfo: smithyClient._json,
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Name: smithyClient.expectString,
        Priority: smithyClient.expectInt32,
        ServiceRoleArn: smithyClient.expectString,
        Targets: smithyClient._json,
        TaskArn: smithyClient.expectString,
        TaskInvocationParameters: (_) => de_MaintenanceWindowTaskInvocationParameters(_, context),
        TaskParameters: smithyClient._json,
        TaskType: smithyClient.expectString,
        WindowId: smithyClient.expectString,
        WindowTaskId: smithyClient.expectString,
    });
};
const de_GetOpsItemResponse = (output, context) => {
    return smithyClient.take(output, {
        OpsItem: (_) => de_OpsItem(_),
    });
};
const de_GetParameterHistoryResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Parameters: (_) => de_ParameterHistoryList(_),
    });
};
const de_GetParameterResult = (output, context) => {
    return smithyClient.take(output, {
        Parameter: (_) => de_Parameter(_),
    });
};
const de_GetParametersByPathResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Parameters: (_) => de_ParameterList(_),
    });
};
const de_GetParametersResult = (output, context) => {
    return smithyClient.take(output, {
        InvalidParameters: smithyClient._json,
        Parameters: (_) => de_ParameterList(_),
    });
};
const de_GetPatchBaselineResult = (output, context) => {
    return smithyClient.take(output, {
        ApprovalRules: smithyClient._json,
        ApprovedPatches: smithyClient._json,
        ApprovedPatchesComplianceLevel: smithyClient.expectString,
        ApprovedPatchesEnableNonSecurity: smithyClient.expectBoolean,
        AvailableSecurityUpdatesComplianceStatus: smithyClient.expectString,
        BaselineId: smithyClient.expectString,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Description: smithyClient.expectString,
        GlobalFilters: smithyClient._json,
        ModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        OperatingSystem: smithyClient.expectString,
        PatchGroups: smithyClient._json,
        RejectedPatches: smithyClient._json,
        RejectedPatchesAction: smithyClient.expectString,
        Sources: smithyClient._json,
    });
};
const de_GetServiceSettingResult = (output, context) => {
    return smithyClient.take(output, {
        ServiceSetting: (_) => de_ServiceSetting(_),
    });
};
const de_InstanceAssociationStatusInfo = (output, context) => {
    return smithyClient.take(output, {
        AssociationId: smithyClient.expectString,
        AssociationName: smithyClient.expectString,
        AssociationVersion: smithyClient.expectString,
        DetailedStatus: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        ErrorCode: smithyClient.expectString,
        ExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionSummary: smithyClient.expectString,
        InstanceId: smithyClient.expectString,
        Name: smithyClient.expectString,
        OutputUrl: smithyClient._json,
        Status: smithyClient.expectString,
    });
};
const de_InstanceAssociationStatusInfos = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_InstanceAssociationStatusInfo(entry);
    });
    return retVal;
};
const de_InstanceInformation = (output, context) => {
    return smithyClient.take(output, {
        ActivationId: smithyClient.expectString,
        AgentVersion: smithyClient.expectString,
        AssociationOverview: smithyClient._json,
        AssociationStatus: smithyClient.expectString,
        ComputerName: smithyClient.expectString,
        IPAddress: smithyClient.expectString,
        IamRole: smithyClient.expectString,
        InstanceId: smithyClient.expectString,
        IsLatestVersion: smithyClient.expectBoolean,
        LastAssociationExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastPingDateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastSuccessfulAssociationExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        PingStatus: smithyClient.expectString,
        PlatformName: smithyClient.expectString,
        PlatformType: smithyClient.expectString,
        PlatformVersion: smithyClient.expectString,
        RegistrationDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ResourceType: smithyClient.expectString,
        SourceId: smithyClient.expectString,
        SourceType: smithyClient.expectString,
    });
};
const de_InstanceInformationList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_InstanceInformation(entry);
    });
    return retVal;
};
const de_InstancePatchState = (output, context) => {
    return smithyClient.take(output, {
        AvailableSecurityUpdateCount: smithyClient.expectInt32,
        BaselineId: smithyClient.expectString,
        CriticalNonCompliantCount: smithyClient.expectInt32,
        FailedCount: smithyClient.expectInt32,
        InstallOverrideList: smithyClient.expectString,
        InstalledCount: smithyClient.expectInt32,
        InstalledOtherCount: smithyClient.expectInt32,
        InstalledPendingRebootCount: smithyClient.expectInt32,
        InstalledRejectedCount: smithyClient.expectInt32,
        InstanceId: smithyClient.expectString,
        LastNoRebootInstallOperationTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        MissingCount: smithyClient.expectInt32,
        NotApplicableCount: smithyClient.expectInt32,
        Operation: smithyClient.expectString,
        OperationEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        OperationStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        OtherNonCompliantCount: smithyClient.expectInt32,
        OwnerInformation: smithyClient.expectString,
        PatchGroup: smithyClient.expectString,
        RebootOption: smithyClient.expectString,
        SecurityNonCompliantCount: smithyClient.expectInt32,
        SnapshotId: smithyClient.expectString,
        UnreportedNotApplicableCount: smithyClient.expectInt32,
    });
};
const de_InstancePatchStateList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_InstancePatchState(entry);
    });
    return retVal;
};
const de_InstancePatchStatesList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_InstancePatchState(entry);
    });
    return retVal;
};
const de_InstanceProperties = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_InstanceProperty(entry);
    });
    return retVal;
};
const de_InstanceProperty = (output, context) => {
    return smithyClient.take(output, {
        ActivationId: smithyClient.expectString,
        AgentVersion: smithyClient.expectString,
        Architecture: smithyClient.expectString,
        AssociationOverview: smithyClient._json,
        AssociationStatus: smithyClient.expectString,
        ComputerName: smithyClient.expectString,
        IPAddress: smithyClient.expectString,
        IamRole: smithyClient.expectString,
        InstanceId: smithyClient.expectString,
        InstanceRole: smithyClient.expectString,
        InstanceState: smithyClient.expectString,
        InstanceType: smithyClient.expectString,
        KeyName: smithyClient.expectString,
        LastAssociationExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastPingDateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastSuccessfulAssociationExecutionDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LaunchTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        PingStatus: smithyClient.expectString,
        PlatformName: smithyClient.expectString,
        PlatformType: smithyClient.expectString,
        PlatformVersion: smithyClient.expectString,
        RegistrationDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ResourceType: smithyClient.expectString,
        SourceId: smithyClient.expectString,
        SourceType: smithyClient.expectString,
    });
};
const de_InventoryDeletionsList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_InventoryDeletionStatusItem(entry);
    });
    return retVal;
};
const de_InventoryDeletionStatusItem = (output, context) => {
    return smithyClient.take(output, {
        DeletionId: smithyClient.expectString,
        DeletionStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        DeletionSummary: smithyClient._json,
        LastStatus: smithyClient.expectString,
        LastStatusMessage: smithyClient.expectString,
        LastStatusUpdateTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        TypeName: smithyClient.expectString,
    });
};
const de_ListAssociationsResult = (output, context) => {
    return smithyClient.take(output, {
        Associations: (_) => de_AssociationList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListAssociationVersionsResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationVersions: (_) => de_AssociationVersionList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListCommandInvocationsResult = (output, context) => {
    return smithyClient.take(output, {
        CommandInvocations: (_) => de_CommandInvocationList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListCommandsResult = (output, context) => {
    return smithyClient.take(output, {
        Commands: (_) => de_CommandList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListComplianceItemsResult = (output, context) => {
    return smithyClient.take(output, {
        ComplianceItems: (_) => de_ComplianceItemList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListDocumentMetadataHistoryResponse = (output, context) => {
    return smithyClient.take(output, {
        Author: smithyClient.expectString,
        DocumentVersion: smithyClient.expectString,
        Metadata: (_) => de_DocumentMetadataResponseInfo(_),
        Name: smithyClient.expectString,
        NextToken: smithyClient.expectString,
    });
};
const de_ListDocumentsResult = (output, context) => {
    return smithyClient.take(output, {
        DocumentIdentifiers: (_) => de_DocumentIdentifierList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListDocumentVersionsResult = (output, context) => {
    return smithyClient.take(output, {
        DocumentVersions: (_) => de_DocumentVersionList(_),
        NextToken: smithyClient.expectString,
    });
};
const de_ListNodesResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Nodes: (_) => de_NodeList(_),
    });
};
const de_ListOpsItemEventsResponse = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Summaries: (_) => de_OpsItemEventSummaries(_),
    });
};
const de_ListOpsItemRelatedItemsResponse = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        Summaries: (_) => de_OpsItemRelatedItemSummaries(_),
    });
};
const de_ListOpsMetadataResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        OpsMetadataList: (_) => de_OpsMetadataList(_),
    });
};
const de_ListResourceComplianceSummariesResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        ResourceComplianceSummaryItems: (_) => de_ResourceComplianceSummaryItemList(_),
    });
};
const de_ListResourceDataSyncResult = (output, context) => {
    return smithyClient.take(output, {
        NextToken: smithyClient.expectString,
        ResourceDataSyncItems: (_) => de_ResourceDataSyncItemList(_),
    });
};
const de_MaintenanceWindowExecution = (output, context) => {
    return smithyClient.take(output, {
        EndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        StartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        WindowExecutionId: smithyClient.expectString,
        WindowId: smithyClient.expectString,
    });
};
const de_MaintenanceWindowExecutionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_MaintenanceWindowExecution(entry);
    });
    return retVal;
};
const de_MaintenanceWindowExecutionTaskIdentity = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        EndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        StartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TaskArn: smithyClient.expectString,
        TaskExecutionId: smithyClient.expectString,
        TaskType: smithyClient.expectString,
        TriggeredAlarms: smithyClient._json,
        WindowExecutionId: smithyClient.expectString,
    });
};
const de_MaintenanceWindowExecutionTaskIdentityList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_MaintenanceWindowExecutionTaskIdentity(entry);
    });
    return retVal;
};
const de_MaintenanceWindowExecutionTaskInvocationIdentity = (output, context) => {
    return smithyClient.take(output, {
        EndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionId: smithyClient.expectString,
        InvocationId: smithyClient.expectString,
        OwnerInformation: smithyClient.expectString,
        Parameters: smithyClient.expectString,
        StartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        StatusDetails: smithyClient.expectString,
        TaskExecutionId: smithyClient.expectString,
        TaskType: smithyClient.expectString,
        WindowExecutionId: smithyClient.expectString,
        WindowTargetId: smithyClient.expectString,
    });
};
const de_MaintenanceWindowExecutionTaskInvocationIdentityList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_MaintenanceWindowExecutionTaskInvocationIdentity(entry);
    });
    return retVal;
};
const de_MaintenanceWindowLambdaParameters = (output, context) => {
    return smithyClient.take(output, {
        ClientContext: smithyClient.expectString,
        Payload: context.base64Decoder,
        Qualifier: smithyClient.expectString,
    });
};
const de_MaintenanceWindowTaskInvocationParameters = (output, context) => {
    return smithyClient.take(output, {
        Automation: smithyClient._json,
        Lambda: (_) => de_MaintenanceWindowLambdaParameters(_, context),
        RunCommand: smithyClient._json,
        StepFunctions: smithyClient._json,
    });
};
const de_Node = (output, context) => {
    return smithyClient.take(output, {
        CaptureTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Id: smithyClient.expectString,
        NodeType: (_) => smithyClient._json(core$1.awsExpectUnion(_)),
        Owner: smithyClient._json,
        Region: smithyClient.expectString,
    });
};
const de_NodeList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Node(entry);
    });
    return retVal;
};
const de_OpsItem = (output, context) => {
    return smithyClient.take(output, {
        ActualEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ActualStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Category: smithyClient.expectString,
        CreatedBy: smithyClient.expectString,
        CreatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Description: smithyClient.expectString,
        LastModifiedBy: smithyClient.expectString,
        LastModifiedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Notifications: smithyClient._json,
        OperationalData: smithyClient._json,
        OpsItemArn: smithyClient.expectString,
        OpsItemId: smithyClient.expectString,
        OpsItemType: smithyClient.expectString,
        PlannedEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        PlannedStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Priority: smithyClient.expectInt32,
        RelatedOpsItems: smithyClient._json,
        Severity: smithyClient.expectString,
        Source: smithyClient.expectString,
        Status: smithyClient.expectString,
        Title: smithyClient.expectString,
        Version: smithyClient.expectString,
    });
};
const de_OpsItemEventSummaries = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_OpsItemEventSummary(entry);
    });
    return retVal;
};
const de_OpsItemEventSummary = (output, context) => {
    return smithyClient.take(output, {
        CreatedBy: smithyClient._json,
        CreatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Detail: smithyClient.expectString,
        DetailType: smithyClient.expectString,
        EventId: smithyClient.expectString,
        OpsItemId: smithyClient.expectString,
        Source: smithyClient.expectString,
    });
};
const de_OpsItemRelatedItemSummaries = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_OpsItemRelatedItemSummary(entry);
    });
    return retVal;
};
const de_OpsItemRelatedItemSummary = (output, context) => {
    return smithyClient.take(output, {
        AssociationId: smithyClient.expectString,
        AssociationType: smithyClient.expectString,
        CreatedBy: smithyClient._json,
        CreatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedBy: smithyClient._json,
        LastModifiedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        OpsItemId: smithyClient.expectString,
        ResourceType: smithyClient.expectString,
        ResourceUri: smithyClient.expectString,
    });
};
const de_OpsItemSummaries = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_OpsItemSummary(entry);
    });
    return retVal;
};
const de_OpsItemSummary = (output, context) => {
    return smithyClient.take(output, {
        ActualEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ActualStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Category: smithyClient.expectString,
        CreatedBy: smithyClient.expectString,
        CreatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedBy: smithyClient.expectString,
        LastModifiedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        OperationalData: smithyClient._json,
        OpsItemId: smithyClient.expectString,
        OpsItemType: smithyClient.expectString,
        PlannedEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        PlannedStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Priority: smithyClient.expectInt32,
        Severity: smithyClient.expectString,
        Source: smithyClient.expectString,
        Status: smithyClient.expectString,
        Title: smithyClient.expectString,
    });
};
const de_OpsMetadata = (output, context) => {
    return smithyClient.take(output, {
        CreationDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedUser: smithyClient.expectString,
        OpsMetadataArn: smithyClient.expectString,
        ResourceId: smithyClient.expectString,
    });
};
const de_OpsMetadataList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_OpsMetadata(entry);
    });
    return retVal;
};
const de_Parameter = (output, context) => {
    return smithyClient.take(output, {
        ARN: smithyClient.expectString,
        DataType: smithyClient.expectString,
        LastModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        Selector: smithyClient.expectString,
        SourceResult: smithyClient.expectString,
        Type: smithyClient.expectString,
        Value: smithyClient.expectString,
        Version: smithyClient.expectLong,
    });
};
const de_ParameterHistory = (output, context) => {
    return smithyClient.take(output, {
        AllowedPattern: smithyClient.expectString,
        DataType: smithyClient.expectString,
        Description: smithyClient.expectString,
        KeyId: smithyClient.expectString,
        Labels: smithyClient._json,
        LastModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedUser: smithyClient.expectString,
        Name: smithyClient.expectString,
        Policies: smithyClient._json,
        Tier: smithyClient.expectString,
        Type: smithyClient.expectString,
        Value: smithyClient.expectString,
        Version: smithyClient.expectLong,
    });
};
const de_ParameterHistoryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ParameterHistory(entry);
    });
    return retVal;
};
const de_ParameterList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Parameter(entry);
    });
    return retVal;
};
const de_ParameterMetadata = (output, context) => {
    return smithyClient.take(output, {
        ARN: smithyClient.expectString,
        AllowedPattern: smithyClient.expectString,
        DataType: smithyClient.expectString,
        Description: smithyClient.expectString,
        KeyId: smithyClient.expectString,
        LastModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedUser: smithyClient.expectString,
        Name: smithyClient.expectString,
        Policies: smithyClient._json,
        Tier: smithyClient.expectString,
        Type: smithyClient.expectString,
        Version: smithyClient.expectLong,
    });
};
const de_ParameterMetadataList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ParameterMetadata(entry);
    });
    return retVal;
};
const de_Patch = (output, context) => {
    return smithyClient.take(output, {
        AdvisoryIds: smithyClient._json,
        Arch: smithyClient.expectString,
        BugzillaIds: smithyClient._json,
        CVEIds: smithyClient._json,
        Classification: smithyClient.expectString,
        ContentUrl: smithyClient.expectString,
        Description: smithyClient.expectString,
        Epoch: smithyClient.expectInt32,
        Id: smithyClient.expectString,
        KbNumber: smithyClient.expectString,
        Language: smithyClient.expectString,
        MsrcNumber: smithyClient.expectString,
        MsrcSeverity: smithyClient.expectString,
        Name: smithyClient.expectString,
        Product: smithyClient.expectString,
        ProductFamily: smithyClient.expectString,
        Release: smithyClient.expectString,
        ReleaseDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Repository: smithyClient.expectString,
        Severity: smithyClient.expectString,
        Title: smithyClient.expectString,
        Vendor: smithyClient.expectString,
        Version: smithyClient.expectString,
    });
};
const de_PatchComplianceData = (output, context) => {
    return smithyClient.take(output, {
        CVEIds: smithyClient.expectString,
        Classification: smithyClient.expectString,
        InstalledTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        KBId: smithyClient.expectString,
        Severity: smithyClient.expectString,
        State: smithyClient.expectString,
        Title: smithyClient.expectString,
    });
};
const de_PatchComplianceDataList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_PatchComplianceData(entry);
    });
    return retVal;
};
const de_PatchList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Patch(entry);
    });
    return retVal;
};
const de_PatchStatus = (output, context) => {
    return smithyClient.take(output, {
        ApprovalDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ComplianceLevel: smithyClient.expectString,
        DeploymentStatus: smithyClient.expectString,
    });
};
const de_ResetServiceSettingResult = (output, context) => {
    return smithyClient.take(output, {
        ServiceSetting: (_) => de_ServiceSetting(_),
    });
};
const de_ResourceComplianceSummaryItem = (output, context) => {
    return smithyClient.take(output, {
        ComplianceType: smithyClient.expectString,
        CompliantSummary: smithyClient._json,
        ExecutionSummary: (_) => de_ComplianceExecutionSummary(_),
        NonCompliantSummary: smithyClient._json,
        OverallSeverity: smithyClient.expectString,
        ResourceId: smithyClient.expectString,
        ResourceType: smithyClient.expectString,
        Status: smithyClient.expectString,
    });
};
const de_ResourceComplianceSummaryItemList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ResourceComplianceSummaryItem(entry);
    });
    return retVal;
};
const de_ResourceDataSyncItem = (output, context) => {
    return smithyClient.take(output, {
        LastStatus: smithyClient.expectString,
        LastSuccessfulSyncTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastSyncStatusMessage: smithyClient.expectString,
        LastSyncTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        S3Destination: smithyClient._json,
        SyncCreatedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        SyncLastModifiedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        SyncName: smithyClient.expectString,
        SyncSource: smithyClient._json,
        SyncType: smithyClient.expectString,
    });
};
const de_ResourceDataSyncItemList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ResourceDataSyncItem(entry);
    });
    return retVal;
};
const de_ReviewInformation = (output, context) => {
    return smithyClient.take(output, {
        ReviewedTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Reviewer: smithyClient.expectString,
        Status: smithyClient.expectString,
    });
};
const de_ReviewInformationList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ReviewInformation(entry);
    });
    return retVal;
};
const de_SendCommandResult = (output, context) => {
    return smithyClient.take(output, {
        Command: (_) => de_Command(_),
    });
};
const de_ServiceSetting = (output, context) => {
    return smithyClient.take(output, {
        ARN: smithyClient.expectString,
        LastModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        LastModifiedUser: smithyClient.expectString,
        SettingId: smithyClient.expectString,
        SettingValue: smithyClient.expectString,
        Status: smithyClient.expectString,
    });
};
const de_Session = (output, context) => {
    return smithyClient.take(output, {
        AccessType: smithyClient.expectString,
        Details: smithyClient.expectString,
        DocumentName: smithyClient.expectString,
        EndDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        MaxSessionDuration: smithyClient.expectString,
        OutputUrl: smithyClient._json,
        Owner: smithyClient.expectString,
        Reason: smithyClient.expectString,
        SessionId: smithyClient.expectString,
        StartDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Status: smithyClient.expectString,
        Target: smithyClient.expectString,
    });
};
const de_SessionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_Session(entry);
    });
    return retVal;
};
const de_StepExecution = (output, context) => {
    return smithyClient.take(output, {
        Action: smithyClient.expectString,
        ExecutionEndTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        ExecutionStartTime: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        FailureDetails: smithyClient._json,
        FailureMessage: smithyClient.expectString,
        Inputs: smithyClient._json,
        IsCritical: smithyClient.expectBoolean,
        IsEnd: smithyClient.expectBoolean,
        MaxAttempts: smithyClient.expectInt32,
        NextStep: smithyClient.expectString,
        OnFailure: smithyClient.expectString,
        Outputs: smithyClient._json,
        OverriddenParameters: smithyClient._json,
        ParentStepDetails: smithyClient._json,
        Response: smithyClient.expectString,
        ResponseCode: smithyClient.expectString,
        StepExecutionId: smithyClient.expectString,
        StepName: smithyClient.expectString,
        StepStatus: smithyClient.expectString,
        TargetLocation: smithyClient._json,
        Targets: smithyClient._json,
        TimeoutSeconds: smithyClient.expectLong,
        TriggeredAlarms: smithyClient._json,
        ValidNextSteps: smithyClient._json,
    });
};
const de_StepExecutionList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_StepExecution(entry);
    });
    return retVal;
};
const de_UpdateAssociationResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationDescription: (_) => de_AssociationDescription(_),
    });
};
const de_UpdateAssociationStatusResult = (output, context) => {
    return smithyClient.take(output, {
        AssociationDescription: (_) => de_AssociationDescription(_),
    });
};
const de_UpdateDocumentResult = (output, context) => {
    return smithyClient.take(output, {
        DocumentDescription: (_) => de_DocumentDescription(_),
    });
};
const de_UpdateMaintenanceWindowTaskResult = (output, context) => {
    return smithyClient.take(output, {
        AlarmConfiguration: smithyClient._json,
        CutoffBehavior: smithyClient.expectString,
        Description: smithyClient.expectString,
        LoggingInfo: smithyClient._json,
        MaxConcurrency: smithyClient.expectString,
        MaxErrors: smithyClient.expectString,
        Name: smithyClient.expectString,
        Priority: smithyClient.expectInt32,
        ServiceRoleArn: smithyClient.expectString,
        Targets: smithyClient._json,
        TaskArn: smithyClient.expectString,
        TaskInvocationParameters: (_) => de_MaintenanceWindowTaskInvocationParameters(_, context),
        TaskParameters: smithyClient._json,
        WindowId: smithyClient.expectString,
        WindowTaskId: smithyClient.expectString,
    });
};
const de_UpdatePatchBaselineResult = (output, context) => {
    return smithyClient.take(output, {
        ApprovalRules: smithyClient._json,
        ApprovedPatches: smithyClient._json,
        ApprovedPatchesComplianceLevel: smithyClient.expectString,
        ApprovedPatchesEnableNonSecurity: smithyClient.expectBoolean,
        AvailableSecurityUpdatesComplianceStatus: smithyClient.expectString,
        BaselineId: smithyClient.expectString,
        CreatedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Description: smithyClient.expectString,
        GlobalFilters: smithyClient._json,
        ModifiedDate: (_) => smithyClient.expectNonNull(smithyClient.parseEpochTimestamp(smithyClient.expectNumber(_))),
        Name: smithyClient.expectString,
        OperatingSystem: smithyClient.expectString,
        RejectedPatches: smithyClient._json,
        RejectedPatchesAction: smithyClient.expectString,
        Sources: smithyClient._json,
    });
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const throwDefaultError = smithyClient.withBaseException(SSMServiceException);
const buildHttpRpcRequest = async (context, headers, path, resolvedHostname, body) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const contents = {
        protocol,
        hostname,
        port,
        method: "POST",
        path: basePath.endsWith("/") ? basePath.slice(0, -1) + path : basePath + path,
        headers,
    };
    if (body !== undefined) {
        contents.body = body;
    }
    return new protocolHttp.HttpRequest(contents);
};
function sharedHeaders(operation) {
    return {
        "content-type": "application/x-amz-json-1.1",
        "x-amz-target": `AmazonSSM.${operation}`,
    };
}

class AddTagsToResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "AddTagsToResource", {})
    .n("SSMClient", "AddTagsToResourceCommand")
    .f(void 0, void 0)
    .ser(se_AddTagsToResourceCommand)
    .de(de_AddTagsToResourceCommand)
    .build() {
}

class AssociateOpsItemRelatedItemCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "AssociateOpsItemRelatedItem", {})
    .n("SSMClient", "AssociateOpsItemRelatedItemCommand")
    .f(void 0, void 0)
    .ser(se_AssociateOpsItemRelatedItemCommand)
    .de(de_AssociateOpsItemRelatedItemCommand)
    .build() {
}

class CancelCommandCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CancelCommand", {})
    .n("SSMClient", "CancelCommandCommand")
    .f(void 0, void 0)
    .ser(se_CancelCommandCommand)
    .de(de_CancelCommandCommand)
    .build() {
}

class CancelMaintenanceWindowExecutionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CancelMaintenanceWindowExecution", {})
    .n("SSMClient", "CancelMaintenanceWindowExecutionCommand")
    .f(void 0, void 0)
    .ser(se_CancelMaintenanceWindowExecutionCommand)
    .de(de_CancelMaintenanceWindowExecutionCommand)
    .build() {
}

class CreateActivationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateActivation", {})
    .n("SSMClient", "CreateActivationCommand")
    .f(void 0, void 0)
    .ser(se_CreateActivationCommand)
    .de(de_CreateActivationCommand)
    .build() {
}

class CreateAssociationBatchCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateAssociationBatch", {})
    .n("SSMClient", "CreateAssociationBatchCommand")
    .f(CreateAssociationBatchRequestFilterSensitiveLog, CreateAssociationBatchResultFilterSensitiveLog)
    .ser(se_CreateAssociationBatchCommand)
    .de(de_CreateAssociationBatchCommand)
    .build() {
}

class CreateAssociationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateAssociation", {})
    .n("SSMClient", "CreateAssociationCommand")
    .f(CreateAssociationRequestFilterSensitiveLog, CreateAssociationResultFilterSensitiveLog)
    .ser(se_CreateAssociationCommand)
    .de(de_CreateAssociationCommand)
    .build() {
}

class CreateDocumentCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateDocument", {})
    .n("SSMClient", "CreateDocumentCommand")
    .f(void 0, void 0)
    .ser(se_CreateDocumentCommand)
    .de(de_CreateDocumentCommand)
    .build() {
}

class CreateMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateMaintenanceWindow", {})
    .n("SSMClient", "CreateMaintenanceWindowCommand")
    .f(CreateMaintenanceWindowRequestFilterSensitiveLog, void 0)
    .ser(se_CreateMaintenanceWindowCommand)
    .de(de_CreateMaintenanceWindowCommand)
    .build() {
}

class CreateOpsItemCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateOpsItem", {})
    .n("SSMClient", "CreateOpsItemCommand")
    .f(void 0, void 0)
    .ser(se_CreateOpsItemCommand)
    .de(de_CreateOpsItemCommand)
    .build() {
}

class CreateOpsMetadataCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateOpsMetadata", {})
    .n("SSMClient", "CreateOpsMetadataCommand")
    .f(void 0, void 0)
    .ser(se_CreateOpsMetadataCommand)
    .de(de_CreateOpsMetadataCommand)
    .build() {
}

class CreatePatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreatePatchBaseline", {})
    .n("SSMClient", "CreatePatchBaselineCommand")
    .f(CreatePatchBaselineRequestFilterSensitiveLog, void 0)
    .ser(se_CreatePatchBaselineCommand)
    .de(de_CreatePatchBaselineCommand)
    .build() {
}

class CreateResourceDataSyncCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "CreateResourceDataSync", {})
    .n("SSMClient", "CreateResourceDataSyncCommand")
    .f(void 0, void 0)
    .ser(se_CreateResourceDataSyncCommand)
    .de(de_CreateResourceDataSyncCommand)
    .build() {
}

class DeleteActivationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteActivation", {})
    .n("SSMClient", "DeleteActivationCommand")
    .f(void 0, void 0)
    .ser(se_DeleteActivationCommand)
    .de(de_DeleteActivationCommand)
    .build() {
}

class DeleteAssociationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteAssociation", {})
    .n("SSMClient", "DeleteAssociationCommand")
    .f(void 0, void 0)
    .ser(se_DeleteAssociationCommand)
    .de(de_DeleteAssociationCommand)
    .build() {
}

class DeleteDocumentCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteDocument", {})
    .n("SSMClient", "DeleteDocumentCommand")
    .f(void 0, void 0)
    .ser(se_DeleteDocumentCommand)
    .de(de_DeleteDocumentCommand)
    .build() {
}

class DeleteInventoryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteInventory", {})
    .n("SSMClient", "DeleteInventoryCommand")
    .f(void 0, void 0)
    .ser(se_DeleteInventoryCommand)
    .de(de_DeleteInventoryCommand)
    .build() {
}

class DeleteMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteMaintenanceWindow", {})
    .n("SSMClient", "DeleteMaintenanceWindowCommand")
    .f(void 0, void 0)
    .ser(se_DeleteMaintenanceWindowCommand)
    .de(de_DeleteMaintenanceWindowCommand)
    .build() {
}

class DeleteOpsItemCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteOpsItem", {})
    .n("SSMClient", "DeleteOpsItemCommand")
    .f(void 0, void 0)
    .ser(se_DeleteOpsItemCommand)
    .de(de_DeleteOpsItemCommand)
    .build() {
}

class DeleteOpsMetadataCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteOpsMetadata", {})
    .n("SSMClient", "DeleteOpsMetadataCommand")
    .f(void 0, void 0)
    .ser(se_DeleteOpsMetadataCommand)
    .de(de_DeleteOpsMetadataCommand)
    .build() {
}

class DeleteParameterCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteParameter", {})
    .n("SSMClient", "DeleteParameterCommand")
    .f(void 0, void 0)
    .ser(se_DeleteParameterCommand)
    .de(de_DeleteParameterCommand)
    .build() {
}

class DeleteParametersCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteParameters", {})
    .n("SSMClient", "DeleteParametersCommand")
    .f(void 0, void 0)
    .ser(se_DeleteParametersCommand)
    .de(de_DeleteParametersCommand)
    .build() {
}

class DeletePatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeletePatchBaseline", {})
    .n("SSMClient", "DeletePatchBaselineCommand")
    .f(void 0, void 0)
    .ser(se_DeletePatchBaselineCommand)
    .de(de_DeletePatchBaselineCommand)
    .build() {
}

class DeleteResourceDataSyncCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteResourceDataSync", {})
    .n("SSMClient", "DeleteResourceDataSyncCommand")
    .f(void 0, void 0)
    .ser(se_DeleteResourceDataSyncCommand)
    .de(de_DeleteResourceDataSyncCommand)
    .build() {
}

class DeleteResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeleteResourcePolicy", {})
    .n("SSMClient", "DeleteResourcePolicyCommand")
    .f(void 0, void 0)
    .ser(se_DeleteResourcePolicyCommand)
    .de(de_DeleteResourcePolicyCommand)
    .build() {
}

class DeregisterManagedInstanceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeregisterManagedInstance", {})
    .n("SSMClient", "DeregisterManagedInstanceCommand")
    .f(void 0, void 0)
    .ser(se_DeregisterManagedInstanceCommand)
    .de(de_DeregisterManagedInstanceCommand)
    .build() {
}

class DeregisterPatchBaselineForPatchGroupCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeregisterPatchBaselineForPatchGroup", {})
    .n("SSMClient", "DeregisterPatchBaselineForPatchGroupCommand")
    .f(void 0, void 0)
    .ser(se_DeregisterPatchBaselineForPatchGroupCommand)
    .de(de_DeregisterPatchBaselineForPatchGroupCommand)
    .build() {
}

class DeregisterTargetFromMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeregisterTargetFromMaintenanceWindow", {})
    .n("SSMClient", "DeregisterTargetFromMaintenanceWindowCommand")
    .f(void 0, void 0)
    .ser(se_DeregisterTargetFromMaintenanceWindowCommand)
    .de(de_DeregisterTargetFromMaintenanceWindowCommand)
    .build() {
}

class DeregisterTaskFromMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DeregisterTaskFromMaintenanceWindow", {})
    .n("SSMClient", "DeregisterTaskFromMaintenanceWindowCommand")
    .f(void 0, void 0)
    .ser(se_DeregisterTaskFromMaintenanceWindowCommand)
    .de(de_DeregisterTaskFromMaintenanceWindowCommand)
    .build() {
}

class DescribeActivationsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeActivations", {})
    .n("SSMClient", "DescribeActivationsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeActivationsCommand)
    .de(de_DescribeActivationsCommand)
    .build() {
}

class DescribeAssociationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeAssociation", {})
    .n("SSMClient", "DescribeAssociationCommand")
    .f(void 0, DescribeAssociationResultFilterSensitiveLog)
    .ser(se_DescribeAssociationCommand)
    .de(de_DescribeAssociationCommand)
    .build() {
}

class DescribeAssociationExecutionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeAssociationExecutions", {})
    .n("SSMClient", "DescribeAssociationExecutionsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeAssociationExecutionsCommand)
    .de(de_DescribeAssociationExecutionsCommand)
    .build() {
}

class DescribeAssociationExecutionTargetsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeAssociationExecutionTargets", {})
    .n("SSMClient", "DescribeAssociationExecutionTargetsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeAssociationExecutionTargetsCommand)
    .de(de_DescribeAssociationExecutionTargetsCommand)
    .build() {
}

class DescribeAutomationExecutionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeAutomationExecutions", {})
    .n("SSMClient", "DescribeAutomationExecutionsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeAutomationExecutionsCommand)
    .de(de_DescribeAutomationExecutionsCommand)
    .build() {
}

class DescribeAutomationStepExecutionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeAutomationStepExecutions", {})
    .n("SSMClient", "DescribeAutomationStepExecutionsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeAutomationStepExecutionsCommand)
    .de(de_DescribeAutomationStepExecutionsCommand)
    .build() {
}

class DescribeAvailablePatchesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeAvailablePatches", {})
    .n("SSMClient", "DescribeAvailablePatchesCommand")
    .f(void 0, void 0)
    .ser(se_DescribeAvailablePatchesCommand)
    .de(de_DescribeAvailablePatchesCommand)
    .build() {
}

class DescribeDocumentCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeDocument", {})
    .n("SSMClient", "DescribeDocumentCommand")
    .f(void 0, void 0)
    .ser(se_DescribeDocumentCommand)
    .de(de_DescribeDocumentCommand)
    .build() {
}

class DescribeDocumentPermissionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeDocumentPermission", {})
    .n("SSMClient", "DescribeDocumentPermissionCommand")
    .f(void 0, void 0)
    .ser(se_DescribeDocumentPermissionCommand)
    .de(de_DescribeDocumentPermissionCommand)
    .build() {
}

class DescribeEffectiveInstanceAssociationsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeEffectiveInstanceAssociations", {})
    .n("SSMClient", "DescribeEffectiveInstanceAssociationsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeEffectiveInstanceAssociationsCommand)
    .de(de_DescribeEffectiveInstanceAssociationsCommand)
    .build() {
}

class DescribeEffectivePatchesForPatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeEffectivePatchesForPatchBaseline", {})
    .n("SSMClient", "DescribeEffectivePatchesForPatchBaselineCommand")
    .f(void 0, void 0)
    .ser(se_DescribeEffectivePatchesForPatchBaselineCommand)
    .de(de_DescribeEffectivePatchesForPatchBaselineCommand)
    .build() {
}

class DescribeInstanceAssociationsStatusCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstanceAssociationsStatus", {})
    .n("SSMClient", "DescribeInstanceAssociationsStatusCommand")
    .f(void 0, void 0)
    .ser(se_DescribeInstanceAssociationsStatusCommand)
    .de(de_DescribeInstanceAssociationsStatusCommand)
    .build() {
}

class DescribeInstanceInformationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstanceInformation", {})
    .n("SSMClient", "DescribeInstanceInformationCommand")
    .f(void 0, DescribeInstanceInformationResultFilterSensitiveLog)
    .ser(se_DescribeInstanceInformationCommand)
    .de(de_DescribeInstanceInformationCommand)
    .build() {
}

class DescribeInstancePatchesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstancePatches", {})
    .n("SSMClient", "DescribeInstancePatchesCommand")
    .f(void 0, void 0)
    .ser(se_DescribeInstancePatchesCommand)
    .de(de_DescribeInstancePatchesCommand)
    .build() {
}

class DescribeInstancePatchStatesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstancePatchStates", {})
    .n("SSMClient", "DescribeInstancePatchStatesCommand")
    .f(void 0, DescribeInstancePatchStatesResultFilterSensitiveLog)
    .ser(se_DescribeInstancePatchStatesCommand)
    .de(de_DescribeInstancePatchStatesCommand)
    .build() {
}

class DescribeInstancePatchStatesForPatchGroupCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstancePatchStatesForPatchGroup", {})
    .n("SSMClient", "DescribeInstancePatchStatesForPatchGroupCommand")
    .f(void 0, DescribeInstancePatchStatesForPatchGroupResultFilterSensitiveLog)
    .ser(se_DescribeInstancePatchStatesForPatchGroupCommand)
    .de(de_DescribeInstancePatchStatesForPatchGroupCommand)
    .build() {
}

class DescribeInstancePropertiesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstanceProperties", {})
    .n("SSMClient", "DescribeInstancePropertiesCommand")
    .f(void 0, DescribeInstancePropertiesResultFilterSensitiveLog)
    .ser(se_DescribeInstancePropertiesCommand)
    .de(de_DescribeInstancePropertiesCommand)
    .build() {
}

class DescribeInventoryDeletionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInventoryDeletions", {})
    .n("SSMClient", "DescribeInventoryDeletionsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeInventoryDeletionsCommand)
    .de(de_DescribeInventoryDeletionsCommand)
    .build() {
}

class DescribeMaintenanceWindowExecutionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowExecutions", {})
    .n("SSMClient", "DescribeMaintenanceWindowExecutionsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeMaintenanceWindowExecutionsCommand)
    .de(de_DescribeMaintenanceWindowExecutionsCommand)
    .build() {
}

class DescribeMaintenanceWindowExecutionTaskInvocationsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowExecutionTaskInvocations", {})
    .n("SSMClient", "DescribeMaintenanceWindowExecutionTaskInvocationsCommand")
    .f(void 0, DescribeMaintenanceWindowExecutionTaskInvocationsResultFilterSensitiveLog)
    .ser(se_DescribeMaintenanceWindowExecutionTaskInvocationsCommand)
    .de(de_DescribeMaintenanceWindowExecutionTaskInvocationsCommand)
    .build() {
}

class DescribeMaintenanceWindowExecutionTasksCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowExecutionTasks", {})
    .n("SSMClient", "DescribeMaintenanceWindowExecutionTasksCommand")
    .f(void 0, void 0)
    .ser(se_DescribeMaintenanceWindowExecutionTasksCommand)
    .de(de_DescribeMaintenanceWindowExecutionTasksCommand)
    .build() {
}

class DescribeMaintenanceWindowScheduleCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowSchedule", {})
    .n("SSMClient", "DescribeMaintenanceWindowScheduleCommand")
    .f(void 0, void 0)
    .ser(se_DescribeMaintenanceWindowScheduleCommand)
    .de(de_DescribeMaintenanceWindowScheduleCommand)
    .build() {
}

class DescribeMaintenanceWindowsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindows", {})
    .n("SSMClient", "DescribeMaintenanceWindowsCommand")
    .f(void 0, DescribeMaintenanceWindowsResultFilterSensitiveLog)
    .ser(se_DescribeMaintenanceWindowsCommand)
    .de(de_DescribeMaintenanceWindowsCommand)
    .build() {
}

class DescribeMaintenanceWindowsForTargetCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowsForTarget", {})
    .n("SSMClient", "DescribeMaintenanceWindowsForTargetCommand")
    .f(void 0, void 0)
    .ser(se_DescribeMaintenanceWindowsForTargetCommand)
    .de(de_DescribeMaintenanceWindowsForTargetCommand)
    .build() {
}

class DescribeMaintenanceWindowTargetsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowTargets", {})
    .n("SSMClient", "DescribeMaintenanceWindowTargetsCommand")
    .f(void 0, DescribeMaintenanceWindowTargetsResultFilterSensitiveLog)
    .ser(se_DescribeMaintenanceWindowTargetsCommand)
    .de(de_DescribeMaintenanceWindowTargetsCommand)
    .build() {
}

class DescribeMaintenanceWindowTasksCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeMaintenanceWindowTasks", {})
    .n("SSMClient", "DescribeMaintenanceWindowTasksCommand")
    .f(void 0, DescribeMaintenanceWindowTasksResultFilterSensitiveLog)
    .ser(se_DescribeMaintenanceWindowTasksCommand)
    .de(de_DescribeMaintenanceWindowTasksCommand)
    .build() {
}

class DescribeOpsItemsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeOpsItems", {})
    .n("SSMClient", "DescribeOpsItemsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeOpsItemsCommand)
    .de(de_DescribeOpsItemsCommand)
    .build() {
}

class DescribeParametersCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeParameters", {})
    .n("SSMClient", "DescribeParametersCommand")
    .f(void 0, void 0)
    .ser(se_DescribeParametersCommand)
    .de(de_DescribeParametersCommand)
    .build() {
}

class DescribePatchBaselinesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribePatchBaselines", {})
    .n("SSMClient", "DescribePatchBaselinesCommand")
    .f(void 0, void 0)
    .ser(se_DescribePatchBaselinesCommand)
    .de(de_DescribePatchBaselinesCommand)
    .build() {
}

class DescribePatchGroupsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribePatchGroups", {})
    .n("SSMClient", "DescribePatchGroupsCommand")
    .f(void 0, void 0)
    .ser(se_DescribePatchGroupsCommand)
    .de(de_DescribePatchGroupsCommand)
    .build() {
}

class DescribePatchGroupStateCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribePatchGroupState", {})
    .n("SSMClient", "DescribePatchGroupStateCommand")
    .f(void 0, void 0)
    .ser(se_DescribePatchGroupStateCommand)
    .de(de_DescribePatchGroupStateCommand)
    .build() {
}

class DescribePatchPropertiesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribePatchProperties", {})
    .n("SSMClient", "DescribePatchPropertiesCommand")
    .f(void 0, void 0)
    .ser(se_DescribePatchPropertiesCommand)
    .de(de_DescribePatchPropertiesCommand)
    .build() {
}

class DescribeSessionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeSessions", {})
    .n("SSMClient", "DescribeSessionsCommand")
    .f(void 0, void 0)
    .ser(se_DescribeSessionsCommand)
    .de(de_DescribeSessionsCommand)
    .build() {
}

class DisassociateOpsItemRelatedItemCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DisassociateOpsItemRelatedItem", {})
    .n("SSMClient", "DisassociateOpsItemRelatedItemCommand")
    .f(void 0, void 0)
    .ser(se_DisassociateOpsItemRelatedItemCommand)
    .de(de_DisassociateOpsItemRelatedItemCommand)
    .build() {
}

class GetAccessTokenCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetAccessToken", {})
    .n("SSMClient", "GetAccessTokenCommand")
    .f(void 0, GetAccessTokenResponseFilterSensitiveLog)
    .ser(se_GetAccessTokenCommand)
    .de(de_GetAccessTokenCommand)
    .build() {
}

class GetAutomationExecutionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetAutomationExecution", {})
    .n("SSMClient", "GetAutomationExecutionCommand")
    .f(void 0, void 0)
    .ser(se_GetAutomationExecutionCommand)
    .de(de_GetAutomationExecutionCommand)
    .build() {
}

class GetCalendarStateCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetCalendarState", {})
    .n("SSMClient", "GetCalendarStateCommand")
    .f(void 0, void 0)
    .ser(se_GetCalendarStateCommand)
    .de(de_GetCalendarStateCommand)
    .build() {
}

class GetCommandInvocationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetCommandInvocation", {})
    .n("SSMClient", "GetCommandInvocationCommand")
    .f(void 0, void 0)
    .ser(se_GetCommandInvocationCommand)
    .de(de_GetCommandInvocationCommand)
    .build() {
}

class GetConnectionStatusCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetConnectionStatus", {})
    .n("SSMClient", "GetConnectionStatusCommand")
    .f(void 0, void 0)
    .ser(se_GetConnectionStatusCommand)
    .de(de_GetConnectionStatusCommand)
    .build() {
}

class GetDefaultPatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetDefaultPatchBaseline", {})
    .n("SSMClient", "GetDefaultPatchBaselineCommand")
    .f(void 0, void 0)
    .ser(se_GetDefaultPatchBaselineCommand)
    .de(de_GetDefaultPatchBaselineCommand)
    .build() {
}

class GetDeployablePatchSnapshotForInstanceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetDeployablePatchSnapshotForInstance", {})
    .n("SSMClient", "GetDeployablePatchSnapshotForInstanceCommand")
    .f(GetDeployablePatchSnapshotForInstanceRequestFilterSensitiveLog, void 0)
    .ser(se_GetDeployablePatchSnapshotForInstanceCommand)
    .de(de_GetDeployablePatchSnapshotForInstanceCommand)
    .build() {
}

class GetDocumentCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetDocument", {})
    .n("SSMClient", "GetDocumentCommand")
    .f(void 0, void 0)
    .ser(se_GetDocumentCommand)
    .de(de_GetDocumentCommand)
    .build() {
}

class GetExecutionPreviewCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetExecutionPreview", {})
    .n("SSMClient", "GetExecutionPreviewCommand")
    .f(void 0, void 0)
    .ser(se_GetExecutionPreviewCommand)
    .de(de_GetExecutionPreviewCommand)
    .build() {
}

class GetInventoryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetInventory", {})
    .n("SSMClient", "GetInventoryCommand")
    .f(void 0, void 0)
    .ser(se_GetInventoryCommand)
    .de(de_GetInventoryCommand)
    .build() {
}

class GetInventorySchemaCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetInventorySchema", {})
    .n("SSMClient", "GetInventorySchemaCommand")
    .f(void 0, void 0)
    .ser(se_GetInventorySchemaCommand)
    .de(de_GetInventorySchemaCommand)
    .build() {
}

class GetMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetMaintenanceWindow", {})
    .n("SSMClient", "GetMaintenanceWindowCommand")
    .f(void 0, GetMaintenanceWindowResultFilterSensitiveLog)
    .ser(se_GetMaintenanceWindowCommand)
    .de(de_GetMaintenanceWindowCommand)
    .build() {
}

class GetMaintenanceWindowExecutionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetMaintenanceWindowExecution", {})
    .n("SSMClient", "GetMaintenanceWindowExecutionCommand")
    .f(void 0, void 0)
    .ser(se_GetMaintenanceWindowExecutionCommand)
    .de(de_GetMaintenanceWindowExecutionCommand)
    .build() {
}

class GetMaintenanceWindowExecutionTaskCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetMaintenanceWindowExecutionTask", {})
    .n("SSMClient", "GetMaintenanceWindowExecutionTaskCommand")
    .f(void 0, GetMaintenanceWindowExecutionTaskResultFilterSensitiveLog)
    .ser(se_GetMaintenanceWindowExecutionTaskCommand)
    .de(de_GetMaintenanceWindowExecutionTaskCommand)
    .build() {
}

class GetMaintenanceWindowExecutionTaskInvocationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetMaintenanceWindowExecutionTaskInvocation", {})
    .n("SSMClient", "GetMaintenanceWindowExecutionTaskInvocationCommand")
    .f(void 0, GetMaintenanceWindowExecutionTaskInvocationResultFilterSensitiveLog)
    .ser(se_GetMaintenanceWindowExecutionTaskInvocationCommand)
    .de(de_GetMaintenanceWindowExecutionTaskInvocationCommand)
    .build() {
}

class GetMaintenanceWindowTaskCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetMaintenanceWindowTask", {})
    .n("SSMClient", "GetMaintenanceWindowTaskCommand")
    .f(void 0, GetMaintenanceWindowTaskResultFilterSensitiveLog)
    .ser(se_GetMaintenanceWindowTaskCommand)
    .de(de_GetMaintenanceWindowTaskCommand)
    .build() {
}

class GetOpsItemCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetOpsItem", {})
    .n("SSMClient", "GetOpsItemCommand")
    .f(void 0, void 0)
    .ser(se_GetOpsItemCommand)
    .de(de_GetOpsItemCommand)
    .build() {
}

class GetOpsMetadataCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetOpsMetadata", {})
    .n("SSMClient", "GetOpsMetadataCommand")
    .f(void 0, void 0)
    .ser(se_GetOpsMetadataCommand)
    .de(de_GetOpsMetadataCommand)
    .build() {
}

class GetOpsSummaryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetOpsSummary", {})
    .n("SSMClient", "GetOpsSummaryCommand")
    .f(void 0, void 0)
    .ser(se_GetOpsSummaryCommand)
    .de(de_GetOpsSummaryCommand)
    .build() {
}

class GetParameterCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetParameter", {})
    .n("SSMClient", "GetParameterCommand")
    .f(void 0, GetParameterResultFilterSensitiveLog)
    .ser(se_GetParameterCommand)
    .de(de_GetParameterCommand)
    .build() {
}

class GetParameterHistoryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetParameterHistory", {})
    .n("SSMClient", "GetParameterHistoryCommand")
    .f(void 0, GetParameterHistoryResultFilterSensitiveLog)
    .ser(se_GetParameterHistoryCommand)
    .de(de_GetParameterHistoryCommand)
    .build() {
}

class GetParametersByPathCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetParametersByPath", {})
    .n("SSMClient", "GetParametersByPathCommand")
    .f(void 0, GetParametersByPathResultFilterSensitiveLog)
    .ser(se_GetParametersByPathCommand)
    .de(de_GetParametersByPathCommand)
    .build() {
}

class GetParametersCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetParameters", {})
    .n("SSMClient", "GetParametersCommand")
    .f(void 0, GetParametersResultFilterSensitiveLog)
    .ser(se_GetParametersCommand)
    .de(de_GetParametersCommand)
    .build() {
}

class GetPatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetPatchBaseline", {})
    .n("SSMClient", "GetPatchBaselineCommand")
    .f(void 0, GetPatchBaselineResultFilterSensitiveLog)
    .ser(se_GetPatchBaselineCommand)
    .de(de_GetPatchBaselineCommand)
    .build() {
}

class GetPatchBaselineForPatchGroupCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetPatchBaselineForPatchGroup", {})
    .n("SSMClient", "GetPatchBaselineForPatchGroupCommand")
    .f(void 0, void 0)
    .ser(se_GetPatchBaselineForPatchGroupCommand)
    .de(de_GetPatchBaselineForPatchGroupCommand)
    .build() {
}

class GetResourcePoliciesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetResourcePolicies", {})
    .n("SSMClient", "GetResourcePoliciesCommand")
    .f(void 0, void 0)
    .ser(se_GetResourcePoliciesCommand)
    .de(de_GetResourcePoliciesCommand)
    .build() {
}

class GetServiceSettingCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "GetServiceSetting", {})
    .n("SSMClient", "GetServiceSettingCommand")
    .f(void 0, void 0)
    .ser(se_GetServiceSettingCommand)
    .de(de_GetServiceSettingCommand)
    .build() {
}

class LabelParameterVersionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "LabelParameterVersion", {})
    .n("SSMClient", "LabelParameterVersionCommand")
    .f(void 0, void 0)
    .ser(se_LabelParameterVersionCommand)
    .de(de_LabelParameterVersionCommand)
    .build() {
}

class ListAssociationsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListAssociations", {})
    .n("SSMClient", "ListAssociationsCommand")
    .f(void 0, void 0)
    .ser(se_ListAssociationsCommand)
    .de(de_ListAssociationsCommand)
    .build() {
}

class ListAssociationVersionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListAssociationVersions", {})
    .n("SSMClient", "ListAssociationVersionsCommand")
    .f(void 0, ListAssociationVersionsResultFilterSensitiveLog)
    .ser(se_ListAssociationVersionsCommand)
    .de(de_ListAssociationVersionsCommand)
    .build() {
}

class ListCommandInvocationsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListCommandInvocations", {})
    .n("SSMClient", "ListCommandInvocationsCommand")
    .f(void 0, void 0)
    .ser(se_ListCommandInvocationsCommand)
    .de(de_ListCommandInvocationsCommand)
    .build() {
}

class ListCommandsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListCommands", {})
    .n("SSMClient", "ListCommandsCommand")
    .f(void 0, ListCommandsResultFilterSensitiveLog)
    .ser(se_ListCommandsCommand)
    .de(de_ListCommandsCommand)
    .build() {
}

class ListComplianceItemsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListComplianceItems", {})
    .n("SSMClient", "ListComplianceItemsCommand")
    .f(void 0, void 0)
    .ser(se_ListComplianceItemsCommand)
    .de(de_ListComplianceItemsCommand)
    .build() {
}

class ListComplianceSummariesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListComplianceSummaries", {})
    .n("SSMClient", "ListComplianceSummariesCommand")
    .f(void 0, void 0)
    .ser(se_ListComplianceSummariesCommand)
    .de(de_ListComplianceSummariesCommand)
    .build() {
}

class ListDocumentMetadataHistoryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListDocumentMetadataHistory", {})
    .n("SSMClient", "ListDocumentMetadataHistoryCommand")
    .f(void 0, void 0)
    .ser(se_ListDocumentMetadataHistoryCommand)
    .de(de_ListDocumentMetadataHistoryCommand)
    .build() {
}

class ListDocumentsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListDocuments", {})
    .n("SSMClient", "ListDocumentsCommand")
    .f(void 0, void 0)
    .ser(se_ListDocumentsCommand)
    .de(de_ListDocumentsCommand)
    .build() {
}

class ListDocumentVersionsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListDocumentVersions", {})
    .n("SSMClient", "ListDocumentVersionsCommand")
    .f(void 0, void 0)
    .ser(se_ListDocumentVersionsCommand)
    .de(de_ListDocumentVersionsCommand)
    .build() {
}

class ListInventoryEntriesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListInventoryEntries", {})
    .n("SSMClient", "ListInventoryEntriesCommand")
    .f(void 0, void 0)
    .ser(se_ListInventoryEntriesCommand)
    .de(de_ListInventoryEntriesCommand)
    .build() {
}

class ListNodesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListNodes", {})
    .n("SSMClient", "ListNodesCommand")
    .f(void 0, ListNodesResultFilterSensitiveLog)
    .ser(se_ListNodesCommand)
    .de(de_ListNodesCommand)
    .build() {
}

class ListNodesSummaryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListNodesSummary", {})
    .n("SSMClient", "ListNodesSummaryCommand")
    .f(void 0, void 0)
    .ser(se_ListNodesSummaryCommand)
    .de(de_ListNodesSummaryCommand)
    .build() {
}

class ListOpsItemEventsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListOpsItemEvents", {})
    .n("SSMClient", "ListOpsItemEventsCommand")
    .f(void 0, void 0)
    .ser(se_ListOpsItemEventsCommand)
    .de(de_ListOpsItemEventsCommand)
    .build() {
}

class ListOpsItemRelatedItemsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListOpsItemRelatedItems", {})
    .n("SSMClient", "ListOpsItemRelatedItemsCommand")
    .f(void 0, void 0)
    .ser(se_ListOpsItemRelatedItemsCommand)
    .de(de_ListOpsItemRelatedItemsCommand)
    .build() {
}

class ListOpsMetadataCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListOpsMetadata", {})
    .n("SSMClient", "ListOpsMetadataCommand")
    .f(void 0, void 0)
    .ser(se_ListOpsMetadataCommand)
    .de(de_ListOpsMetadataCommand)
    .build() {
}

class ListResourceComplianceSummariesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListResourceComplianceSummaries", {})
    .n("SSMClient", "ListResourceComplianceSummariesCommand")
    .f(void 0, void 0)
    .ser(se_ListResourceComplianceSummariesCommand)
    .de(de_ListResourceComplianceSummariesCommand)
    .build() {
}

class ListResourceDataSyncCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListResourceDataSync", {})
    .n("SSMClient", "ListResourceDataSyncCommand")
    .f(void 0, void 0)
    .ser(se_ListResourceDataSyncCommand)
    .de(de_ListResourceDataSyncCommand)
    .build() {
}

class ListTagsForResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ListTagsForResource", {})
    .n("SSMClient", "ListTagsForResourceCommand")
    .f(void 0, void 0)
    .ser(se_ListTagsForResourceCommand)
    .de(de_ListTagsForResourceCommand)
    .build() {
}

class ModifyDocumentPermissionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ModifyDocumentPermission", {})
    .n("SSMClient", "ModifyDocumentPermissionCommand")
    .f(void 0, void 0)
    .ser(se_ModifyDocumentPermissionCommand)
    .de(de_ModifyDocumentPermissionCommand)
    .build() {
}

class PutComplianceItemsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "PutComplianceItems", {})
    .n("SSMClient", "PutComplianceItemsCommand")
    .f(void 0, void 0)
    .ser(se_PutComplianceItemsCommand)
    .de(de_PutComplianceItemsCommand)
    .build() {
}

class PutInventoryCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "PutInventory", {})
    .n("SSMClient", "PutInventoryCommand")
    .f(void 0, void 0)
    .ser(se_PutInventoryCommand)
    .de(de_PutInventoryCommand)
    .build() {
}

class PutParameterCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "PutParameter", {})
    .n("SSMClient", "PutParameterCommand")
    .f(PutParameterRequestFilterSensitiveLog, void 0)
    .ser(se_PutParameterCommand)
    .de(de_PutParameterCommand)
    .build() {
}

class PutResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "PutResourcePolicy", {})
    .n("SSMClient", "PutResourcePolicyCommand")
    .f(void 0, void 0)
    .ser(se_PutResourcePolicyCommand)
    .de(de_PutResourcePolicyCommand)
    .build() {
}

class RegisterDefaultPatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "RegisterDefaultPatchBaseline", {})
    .n("SSMClient", "RegisterDefaultPatchBaselineCommand")
    .f(void 0, void 0)
    .ser(se_RegisterDefaultPatchBaselineCommand)
    .de(de_RegisterDefaultPatchBaselineCommand)
    .build() {
}

class RegisterPatchBaselineForPatchGroupCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "RegisterPatchBaselineForPatchGroup", {})
    .n("SSMClient", "RegisterPatchBaselineForPatchGroupCommand")
    .f(void 0, void 0)
    .ser(se_RegisterPatchBaselineForPatchGroupCommand)
    .de(de_RegisterPatchBaselineForPatchGroupCommand)
    .build() {
}

class RegisterTargetWithMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "RegisterTargetWithMaintenanceWindow", {})
    .n("SSMClient", "RegisterTargetWithMaintenanceWindowCommand")
    .f(RegisterTargetWithMaintenanceWindowRequestFilterSensitiveLog, void 0)
    .ser(se_RegisterTargetWithMaintenanceWindowCommand)
    .de(de_RegisterTargetWithMaintenanceWindowCommand)
    .build() {
}

class RegisterTaskWithMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "RegisterTaskWithMaintenanceWindow", {})
    .n("SSMClient", "RegisterTaskWithMaintenanceWindowCommand")
    .f(RegisterTaskWithMaintenanceWindowRequestFilterSensitiveLog, void 0)
    .ser(se_RegisterTaskWithMaintenanceWindowCommand)
    .de(de_RegisterTaskWithMaintenanceWindowCommand)
    .build() {
}

class RemoveTagsFromResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "RemoveTagsFromResource", {})
    .n("SSMClient", "RemoveTagsFromResourceCommand")
    .f(void 0, void 0)
    .ser(se_RemoveTagsFromResourceCommand)
    .de(de_RemoveTagsFromResourceCommand)
    .build() {
}

class ResetServiceSettingCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ResetServiceSetting", {})
    .n("SSMClient", "ResetServiceSettingCommand")
    .f(void 0, void 0)
    .ser(se_ResetServiceSettingCommand)
    .de(de_ResetServiceSettingCommand)
    .build() {
}

class ResumeSessionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "ResumeSession", {})
    .n("SSMClient", "ResumeSessionCommand")
    .f(void 0, void 0)
    .ser(se_ResumeSessionCommand)
    .de(de_ResumeSessionCommand)
    .build() {
}

class SendAutomationSignalCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "SendAutomationSignal", {})
    .n("SSMClient", "SendAutomationSignalCommand")
    .f(void 0, void 0)
    .ser(se_SendAutomationSignalCommand)
    .de(de_SendAutomationSignalCommand)
    .build() {
}

class SendCommandCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "SendCommand", {})
    .n("SSMClient", "SendCommandCommand")
    .f(SendCommandRequestFilterSensitiveLog, SendCommandResultFilterSensitiveLog)
    .ser(se_SendCommandCommand)
    .de(de_SendCommandCommand)
    .build() {
}

class StartAccessRequestCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StartAccessRequest", {})
    .n("SSMClient", "StartAccessRequestCommand")
    .f(void 0, void 0)
    .ser(se_StartAccessRequestCommand)
    .de(de_StartAccessRequestCommand)
    .build() {
}

class StartAssociationsOnceCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StartAssociationsOnce", {})
    .n("SSMClient", "StartAssociationsOnceCommand")
    .f(void 0, void 0)
    .ser(se_StartAssociationsOnceCommand)
    .de(de_StartAssociationsOnceCommand)
    .build() {
}

class StartAutomationExecutionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StartAutomationExecution", {})
    .n("SSMClient", "StartAutomationExecutionCommand")
    .f(void 0, void 0)
    .ser(se_StartAutomationExecutionCommand)
    .de(de_StartAutomationExecutionCommand)
    .build() {
}

class StartChangeRequestExecutionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StartChangeRequestExecution", {})
    .n("SSMClient", "StartChangeRequestExecutionCommand")
    .f(void 0, void 0)
    .ser(se_StartChangeRequestExecutionCommand)
    .de(de_StartChangeRequestExecutionCommand)
    .build() {
}

class StartExecutionPreviewCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StartExecutionPreview", {})
    .n("SSMClient", "StartExecutionPreviewCommand")
    .f(void 0, void 0)
    .ser(se_StartExecutionPreviewCommand)
    .de(de_StartExecutionPreviewCommand)
    .build() {
}

class StartSessionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StartSession", {})
    .n("SSMClient", "StartSessionCommand")
    .f(void 0, void 0)
    .ser(se_StartSessionCommand)
    .de(de_StartSessionCommand)
    .build() {
}

class StopAutomationExecutionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "StopAutomationExecution", {})
    .n("SSMClient", "StopAutomationExecutionCommand")
    .f(void 0, void 0)
    .ser(se_StopAutomationExecutionCommand)
    .de(de_StopAutomationExecutionCommand)
    .build() {
}

class TerminateSessionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "TerminateSession", {})
    .n("SSMClient", "TerminateSessionCommand")
    .f(void 0, void 0)
    .ser(se_TerminateSessionCommand)
    .de(de_TerminateSessionCommand)
    .build() {
}

class UnlabelParameterVersionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UnlabelParameterVersion", {})
    .n("SSMClient", "UnlabelParameterVersionCommand")
    .f(void 0, void 0)
    .ser(se_UnlabelParameterVersionCommand)
    .de(de_UnlabelParameterVersionCommand)
    .build() {
}

class UpdateAssociationCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateAssociation", {})
    .n("SSMClient", "UpdateAssociationCommand")
    .f(UpdateAssociationRequestFilterSensitiveLog, UpdateAssociationResultFilterSensitiveLog)
    .ser(se_UpdateAssociationCommand)
    .de(de_UpdateAssociationCommand)
    .build() {
}

class UpdateAssociationStatusCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateAssociationStatus", {})
    .n("SSMClient", "UpdateAssociationStatusCommand")
    .f(void 0, UpdateAssociationStatusResultFilterSensitiveLog)
    .ser(se_UpdateAssociationStatusCommand)
    .de(de_UpdateAssociationStatusCommand)
    .build() {
}

class UpdateDocumentCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateDocument", {})
    .n("SSMClient", "UpdateDocumentCommand")
    .f(void 0, void 0)
    .ser(se_UpdateDocumentCommand)
    .de(de_UpdateDocumentCommand)
    .build() {
}

class UpdateDocumentDefaultVersionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateDocumentDefaultVersion", {})
    .n("SSMClient", "UpdateDocumentDefaultVersionCommand")
    .f(void 0, void 0)
    .ser(se_UpdateDocumentDefaultVersionCommand)
    .de(de_UpdateDocumentDefaultVersionCommand)
    .build() {
}

class UpdateDocumentMetadataCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateDocumentMetadata", {})
    .n("SSMClient", "UpdateDocumentMetadataCommand")
    .f(void 0, void 0)
    .ser(se_UpdateDocumentMetadataCommand)
    .de(de_UpdateDocumentMetadataCommand)
    .build() {
}

class UpdateMaintenanceWindowCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateMaintenanceWindow", {})
    .n("SSMClient", "UpdateMaintenanceWindowCommand")
    .f(UpdateMaintenanceWindowRequestFilterSensitiveLog, UpdateMaintenanceWindowResultFilterSensitiveLog)
    .ser(se_UpdateMaintenanceWindowCommand)
    .de(de_UpdateMaintenanceWindowCommand)
    .build() {
}

class UpdateMaintenanceWindowTargetCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateMaintenanceWindowTarget", {})
    .n("SSMClient", "UpdateMaintenanceWindowTargetCommand")
    .f(UpdateMaintenanceWindowTargetRequestFilterSensitiveLog, UpdateMaintenanceWindowTargetResultFilterSensitiveLog)
    .ser(se_UpdateMaintenanceWindowTargetCommand)
    .de(de_UpdateMaintenanceWindowTargetCommand)
    .build() {
}

class UpdateMaintenanceWindowTaskCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateMaintenanceWindowTask", {})
    .n("SSMClient", "UpdateMaintenanceWindowTaskCommand")
    .f(UpdateMaintenanceWindowTaskRequestFilterSensitiveLog, UpdateMaintenanceWindowTaskResultFilterSensitiveLog)
    .ser(se_UpdateMaintenanceWindowTaskCommand)
    .de(de_UpdateMaintenanceWindowTaskCommand)
    .build() {
}

class UpdateManagedInstanceRoleCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateManagedInstanceRole", {})
    .n("SSMClient", "UpdateManagedInstanceRoleCommand")
    .f(void 0, void 0)
    .ser(se_UpdateManagedInstanceRoleCommand)
    .de(de_UpdateManagedInstanceRoleCommand)
    .build() {
}

class UpdateOpsItemCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateOpsItem", {})
    .n("SSMClient", "UpdateOpsItemCommand")
    .f(void 0, void 0)
    .ser(se_UpdateOpsItemCommand)
    .de(de_UpdateOpsItemCommand)
    .build() {
}

class UpdateOpsMetadataCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateOpsMetadata", {})
    .n("SSMClient", "UpdateOpsMetadataCommand")
    .f(void 0, void 0)
    .ser(se_UpdateOpsMetadataCommand)
    .de(de_UpdateOpsMetadataCommand)
    .build() {
}

class UpdatePatchBaselineCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdatePatchBaseline", {})
    .n("SSMClient", "UpdatePatchBaselineCommand")
    .f(UpdatePatchBaselineRequestFilterSensitiveLog, UpdatePatchBaselineResultFilterSensitiveLog)
    .ser(se_UpdatePatchBaselineCommand)
    .de(de_UpdatePatchBaselineCommand)
    .build() {
}

class UpdateResourceDataSyncCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateResourceDataSync", {})
    .n("SSMClient", "UpdateResourceDataSyncCommand")
    .f(void 0, void 0)
    .ser(se_UpdateResourceDataSyncCommand)
    .de(de_UpdateResourceDataSyncCommand)
    .build() {
}

class UpdateServiceSettingCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        middlewareSerde.getSerdePlugin(config, this.serialize, this.deserialize),
        middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "UpdateServiceSetting", {})
    .n("SSMClient", "UpdateServiceSettingCommand")
    .f(void 0, void 0)
    .ser(se_UpdateServiceSettingCommand)
    .de(de_UpdateServiceSettingCommand)
    .build() {
}

const commands = {
    AddTagsToResourceCommand,
    AssociateOpsItemRelatedItemCommand,
    CancelCommandCommand,
    CancelMaintenanceWindowExecutionCommand,
    CreateActivationCommand,
    CreateAssociationCommand,
    CreateAssociationBatchCommand,
    CreateDocumentCommand,
    CreateMaintenanceWindowCommand,
    CreateOpsItemCommand,
    CreateOpsMetadataCommand,
    CreatePatchBaselineCommand,
    CreateResourceDataSyncCommand,
    DeleteActivationCommand,
    DeleteAssociationCommand,
    DeleteDocumentCommand,
    DeleteInventoryCommand,
    DeleteMaintenanceWindowCommand,
    DeleteOpsItemCommand,
    DeleteOpsMetadataCommand,
    DeleteParameterCommand,
    DeleteParametersCommand,
    DeletePatchBaselineCommand,
    DeleteResourceDataSyncCommand,
    DeleteResourcePolicyCommand,
    DeregisterManagedInstanceCommand,
    DeregisterPatchBaselineForPatchGroupCommand,
    DeregisterTargetFromMaintenanceWindowCommand,
    DeregisterTaskFromMaintenanceWindowCommand,
    DescribeActivationsCommand,
    DescribeAssociationCommand,
    DescribeAssociationExecutionsCommand,
    DescribeAssociationExecutionTargetsCommand,
    DescribeAutomationExecutionsCommand,
    DescribeAutomationStepExecutionsCommand,
    DescribeAvailablePatchesCommand,
    DescribeDocumentCommand,
    DescribeDocumentPermissionCommand,
    DescribeEffectiveInstanceAssociationsCommand,
    DescribeEffectivePatchesForPatchBaselineCommand,
    DescribeInstanceAssociationsStatusCommand,
    DescribeInstanceInformationCommand,
    DescribeInstancePatchesCommand,
    DescribeInstancePatchStatesCommand,
    DescribeInstancePatchStatesForPatchGroupCommand,
    DescribeInstancePropertiesCommand,
    DescribeInventoryDeletionsCommand,
    DescribeMaintenanceWindowExecutionsCommand,
    DescribeMaintenanceWindowExecutionTaskInvocationsCommand,
    DescribeMaintenanceWindowExecutionTasksCommand,
    DescribeMaintenanceWindowsCommand,
    DescribeMaintenanceWindowScheduleCommand,
    DescribeMaintenanceWindowsForTargetCommand,
    DescribeMaintenanceWindowTargetsCommand,
    DescribeMaintenanceWindowTasksCommand,
    DescribeOpsItemsCommand,
    DescribeParametersCommand,
    DescribePatchBaselinesCommand,
    DescribePatchGroupsCommand,
    DescribePatchGroupStateCommand,
    DescribePatchPropertiesCommand,
    DescribeSessionsCommand,
    DisassociateOpsItemRelatedItemCommand,
    GetAccessTokenCommand,
    GetAutomationExecutionCommand,
    GetCalendarStateCommand,
    GetCommandInvocationCommand,
    GetConnectionStatusCommand,
    GetDefaultPatchBaselineCommand,
    GetDeployablePatchSnapshotForInstanceCommand,
    GetDocumentCommand,
    GetExecutionPreviewCommand,
    GetInventoryCommand,
    GetInventorySchemaCommand,
    GetMaintenanceWindowCommand,
    GetMaintenanceWindowExecutionCommand,
    GetMaintenanceWindowExecutionTaskCommand,
    GetMaintenanceWindowExecutionTaskInvocationCommand,
    GetMaintenanceWindowTaskCommand,
    GetOpsItemCommand,
    GetOpsMetadataCommand,
    GetOpsSummaryCommand,
    GetParameterCommand,
    GetParameterHistoryCommand,
    GetParametersCommand,
    GetParametersByPathCommand,
    GetPatchBaselineCommand,
    GetPatchBaselineForPatchGroupCommand,
    GetResourcePoliciesCommand,
    GetServiceSettingCommand,
    LabelParameterVersionCommand,
    ListAssociationsCommand,
    ListAssociationVersionsCommand,
    ListCommandInvocationsCommand,
    ListCommandsCommand,
    ListComplianceItemsCommand,
    ListComplianceSummariesCommand,
    ListDocumentMetadataHistoryCommand,
    ListDocumentsCommand,
    ListDocumentVersionsCommand,
    ListInventoryEntriesCommand,
    ListNodesCommand,
    ListNodesSummaryCommand,
    ListOpsItemEventsCommand,
    ListOpsItemRelatedItemsCommand,
    ListOpsMetadataCommand,
    ListResourceComplianceSummariesCommand,
    ListResourceDataSyncCommand,
    ListTagsForResourceCommand,
    ModifyDocumentPermissionCommand,
    PutComplianceItemsCommand,
    PutInventoryCommand,
    PutParameterCommand,
    PutResourcePolicyCommand,
    RegisterDefaultPatchBaselineCommand,
    RegisterPatchBaselineForPatchGroupCommand,
    RegisterTargetWithMaintenanceWindowCommand,
    RegisterTaskWithMaintenanceWindowCommand,
    RemoveTagsFromResourceCommand,
    ResetServiceSettingCommand,
    ResumeSessionCommand,
    SendAutomationSignalCommand,
    SendCommandCommand,
    StartAccessRequestCommand,
    StartAssociationsOnceCommand,
    StartAutomationExecutionCommand,
    StartChangeRequestExecutionCommand,
    StartExecutionPreviewCommand,
    StartSessionCommand,
    StopAutomationExecutionCommand,
    TerminateSessionCommand,
    UnlabelParameterVersionCommand,
    UpdateAssociationCommand,
    UpdateAssociationStatusCommand,
    UpdateDocumentCommand,
    UpdateDocumentDefaultVersionCommand,
    UpdateDocumentMetadataCommand,
    UpdateMaintenanceWindowCommand,
    UpdateMaintenanceWindowTargetCommand,
    UpdateMaintenanceWindowTaskCommand,
    UpdateManagedInstanceRoleCommand,
    UpdateOpsItemCommand,
    UpdateOpsMetadataCommand,
    UpdatePatchBaselineCommand,
    UpdateResourceDataSyncCommand,
    UpdateServiceSettingCommand,
};
class SSM extends SSMClient {
}
smithyClient.createAggregatedClient(commands, SSM);

const paginateDescribeActivations = core.createPaginator(SSMClient, DescribeActivationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAssociationExecutionTargets = core.createPaginator(SSMClient, DescribeAssociationExecutionTargetsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAssociationExecutions = core.createPaginator(SSMClient, DescribeAssociationExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAutomationExecutions = core.createPaginator(SSMClient, DescribeAutomationExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAutomationStepExecutions = core.createPaginator(SSMClient, DescribeAutomationStepExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeAvailablePatches = core.createPaginator(SSMClient, DescribeAvailablePatchesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeEffectiveInstanceAssociations = core.createPaginator(SSMClient, DescribeEffectiveInstanceAssociationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeEffectivePatchesForPatchBaseline = core.createPaginator(SSMClient, DescribeEffectivePatchesForPatchBaselineCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstanceAssociationsStatus = core.createPaginator(SSMClient, DescribeInstanceAssociationsStatusCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstanceInformation = core.createPaginator(SSMClient, DescribeInstanceInformationCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstancePatchStatesForPatchGroup = core.createPaginator(SSMClient, DescribeInstancePatchStatesForPatchGroupCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstancePatchStates = core.createPaginator(SSMClient, DescribeInstancePatchStatesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstancePatches = core.createPaginator(SSMClient, DescribeInstancePatchesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInstanceProperties = core.createPaginator(SSMClient, DescribeInstancePropertiesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeInventoryDeletions = core.createPaginator(SSMClient, DescribeInventoryDeletionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowExecutionTaskInvocations = core.createPaginator(SSMClient, DescribeMaintenanceWindowExecutionTaskInvocationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowExecutionTasks = core.createPaginator(SSMClient, DescribeMaintenanceWindowExecutionTasksCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowExecutions = core.createPaginator(SSMClient, DescribeMaintenanceWindowExecutionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowSchedule = core.createPaginator(SSMClient, DescribeMaintenanceWindowScheduleCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowTargets = core.createPaginator(SSMClient, DescribeMaintenanceWindowTargetsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowTasks = core.createPaginator(SSMClient, DescribeMaintenanceWindowTasksCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindowsForTarget = core.createPaginator(SSMClient, DescribeMaintenanceWindowsForTargetCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeMaintenanceWindows = core.createPaginator(SSMClient, DescribeMaintenanceWindowsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeOpsItems = core.createPaginator(SSMClient, DescribeOpsItemsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeParameters = core.createPaginator(SSMClient, DescribeParametersCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribePatchBaselines = core.createPaginator(SSMClient, DescribePatchBaselinesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribePatchGroups = core.createPaginator(SSMClient, DescribePatchGroupsCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribePatchProperties = core.createPaginator(SSMClient, DescribePatchPropertiesCommand, "NextToken", "NextToken", "MaxResults");

const paginateDescribeSessions = core.createPaginator(SSMClient, DescribeSessionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetInventory = core.createPaginator(SSMClient, GetInventoryCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetInventorySchema = core.createPaginator(SSMClient, GetInventorySchemaCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetOpsSummary = core.createPaginator(SSMClient, GetOpsSummaryCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetParameterHistory = core.createPaginator(SSMClient, GetParameterHistoryCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetParametersByPath = core.createPaginator(SSMClient, GetParametersByPathCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetResourcePolicies = core.createPaginator(SSMClient, GetResourcePoliciesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListAssociationVersions = core.createPaginator(SSMClient, ListAssociationVersionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListAssociations = core.createPaginator(SSMClient, ListAssociationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListCommandInvocations = core.createPaginator(SSMClient, ListCommandInvocationsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListCommands = core.createPaginator(SSMClient, ListCommandsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListComplianceItems = core.createPaginator(SSMClient, ListComplianceItemsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListComplianceSummaries = core.createPaginator(SSMClient, ListComplianceSummariesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListDocumentVersions = core.createPaginator(SSMClient, ListDocumentVersionsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListDocuments = core.createPaginator(SSMClient, ListDocumentsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListNodes = core.createPaginator(SSMClient, ListNodesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListNodesSummary = core.createPaginator(SSMClient, ListNodesSummaryCommand, "NextToken", "NextToken", "MaxResults");

const paginateListOpsItemEvents = core.createPaginator(SSMClient, ListOpsItemEventsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListOpsItemRelatedItems = core.createPaginator(SSMClient, ListOpsItemRelatedItemsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListOpsMetadata = core.createPaginator(SSMClient, ListOpsMetadataCommand, "NextToken", "NextToken", "MaxResults");

const paginateListResourceComplianceSummaries = core.createPaginator(SSMClient, ListResourceComplianceSummariesCommand, "NextToken", "NextToken", "MaxResults");

const paginateListResourceDataSync = core.createPaginator(SSMClient, ListResourceDataSyncCommand, "NextToken", "NextToken", "MaxResults");

const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetCommandInvocationCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Pending") {
                return { state: utilWaiter.WaiterState.RETRY, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "InProgress") {
                return { state: utilWaiter.WaiterState.RETRY, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Delayed") {
                return { state: utilWaiter.WaiterState.RETRY, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Success") {
                return { state: utilWaiter.WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Cancelled") {
                return { state: utilWaiter.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "TimedOut") {
                return { state: utilWaiter.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Failed") {
                return { state: utilWaiter.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "Cancelling") {
                return { state: utilWaiter.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "InvocationDoesNotExist") {
            return { state: utilWaiter.WaiterState.RETRY, reason };
        }
    }
    return { state: utilWaiter.WaiterState.RETRY, reason };
};
const waitForCommandExecuted = async (params, input) => {
    const serviceDefaults = { minDelay: 5, maxDelay: 120 };
    return utilWaiter.createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
const waitUntilCommandExecuted = async (params, input) => {
    const serviceDefaults = { minDelay: 5, maxDelay: 120 };
    const result = await utilWaiter.createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return utilWaiter.checkExceptions(result);
};

Object.defineProperty(exports, "$Command", {
    enumerable: true,
    get: function () { return smithyClient.Command; }
});
Object.defineProperty(exports, "__Client", {
    enumerable: true,
    get: function () { return smithyClient.Client; }
});
exports.AccessDeniedException = AccessDeniedException;
exports.AccessRequestStatus = AccessRequestStatus;
exports.AccessType = AccessType;
exports.AddTagsToResourceCommand = AddTagsToResourceCommand;
exports.AlreadyExistsException = AlreadyExistsException;
exports.AssociateOpsItemRelatedItemCommand = AssociateOpsItemRelatedItemCommand;
exports.AssociatedInstances = AssociatedInstances;
exports.AssociationAlreadyExists = AssociationAlreadyExists;
exports.AssociationComplianceSeverity = AssociationComplianceSeverity;
exports.AssociationDescriptionFilterSensitiveLog = AssociationDescriptionFilterSensitiveLog;
exports.AssociationDoesNotExist = AssociationDoesNotExist;
exports.AssociationExecutionDoesNotExist = AssociationExecutionDoesNotExist;
exports.AssociationExecutionFilterKey = AssociationExecutionFilterKey;
exports.AssociationExecutionTargetsFilterKey = AssociationExecutionTargetsFilterKey;
exports.AssociationFilterKey = AssociationFilterKey;
exports.AssociationFilterOperatorType = AssociationFilterOperatorType;
exports.AssociationLimitExceeded = AssociationLimitExceeded;
exports.AssociationStatusName = AssociationStatusName;
exports.AssociationSyncCompliance = AssociationSyncCompliance;
exports.AssociationVersionInfoFilterSensitiveLog = AssociationVersionInfoFilterSensitiveLog;
exports.AssociationVersionLimitExceeded = AssociationVersionLimitExceeded;
exports.AttachmentHashType = AttachmentHashType;
exports.AttachmentsSourceKey = AttachmentsSourceKey;
exports.AutomationDefinitionNotApprovedException = AutomationDefinitionNotApprovedException;
exports.AutomationDefinitionNotFoundException = AutomationDefinitionNotFoundException;
exports.AutomationDefinitionVersionNotFoundException = AutomationDefinitionVersionNotFoundException;
exports.AutomationExecutionFilterKey = AutomationExecutionFilterKey;
exports.AutomationExecutionLimitExceededException = AutomationExecutionLimitExceededException;
exports.AutomationExecutionNotFoundException = AutomationExecutionNotFoundException;
exports.AutomationExecutionStatus = AutomationExecutionStatus;
exports.AutomationStepNotFoundException = AutomationStepNotFoundException;
exports.AutomationSubtype = AutomationSubtype;
exports.AutomationType = AutomationType;
exports.BaselineOverrideFilterSensitiveLog = BaselineOverrideFilterSensitiveLog;
exports.CalendarState = CalendarState;
exports.CancelCommandCommand = CancelCommandCommand;
exports.CancelMaintenanceWindowExecutionCommand = CancelMaintenanceWindowExecutionCommand;
exports.CommandFilterKey = CommandFilterKey;
exports.CommandFilterSensitiveLog = CommandFilterSensitiveLog;
exports.CommandInvocationStatus = CommandInvocationStatus;
exports.CommandPluginStatus = CommandPluginStatus;
exports.CommandStatus = CommandStatus;
exports.ComplianceQueryOperatorType = ComplianceQueryOperatorType;
exports.ComplianceSeverity = ComplianceSeverity;
exports.ComplianceStatus = ComplianceStatus;
exports.ComplianceTypeCountLimitExceededException = ComplianceTypeCountLimitExceededException;
exports.ComplianceUploadType = ComplianceUploadType;
exports.ConnectionStatus = ConnectionStatus;
exports.CreateActivationCommand = CreateActivationCommand;
exports.CreateAssociationBatchCommand = CreateAssociationBatchCommand;
exports.CreateAssociationBatchRequestEntryFilterSensitiveLog = CreateAssociationBatchRequestEntryFilterSensitiveLog;
exports.CreateAssociationBatchRequestFilterSensitiveLog = CreateAssociationBatchRequestFilterSensitiveLog;
exports.CreateAssociationBatchResultFilterSensitiveLog = CreateAssociationBatchResultFilterSensitiveLog;
exports.CreateAssociationCommand = CreateAssociationCommand;
exports.CreateAssociationRequestFilterSensitiveLog = CreateAssociationRequestFilterSensitiveLog;
exports.CreateAssociationResultFilterSensitiveLog = CreateAssociationResultFilterSensitiveLog;
exports.CreateDocumentCommand = CreateDocumentCommand;
exports.CreateMaintenanceWindowCommand = CreateMaintenanceWindowCommand;
exports.CreateMaintenanceWindowRequestFilterSensitiveLog = CreateMaintenanceWindowRequestFilterSensitiveLog;
exports.CreateOpsItemCommand = CreateOpsItemCommand;
exports.CreateOpsMetadataCommand = CreateOpsMetadataCommand;
exports.CreatePatchBaselineCommand = CreatePatchBaselineCommand;
exports.CreatePatchBaselineRequestFilterSensitiveLog = CreatePatchBaselineRequestFilterSensitiveLog;
exports.CreateResourceDataSyncCommand = CreateResourceDataSyncCommand;
exports.CredentialsFilterSensitiveLog = CredentialsFilterSensitiveLog;
exports.CustomSchemaCountLimitExceededException = CustomSchemaCountLimitExceededException;
exports.DeleteActivationCommand = DeleteActivationCommand;
exports.DeleteAssociationCommand = DeleteAssociationCommand;
exports.DeleteDocumentCommand = DeleteDocumentCommand;
exports.DeleteInventoryCommand = DeleteInventoryCommand;
exports.DeleteMaintenanceWindowCommand = DeleteMaintenanceWindowCommand;
exports.DeleteOpsItemCommand = DeleteOpsItemCommand;
exports.DeleteOpsMetadataCommand = DeleteOpsMetadataCommand;
exports.DeleteParameterCommand = DeleteParameterCommand;
exports.DeleteParametersCommand = DeleteParametersCommand;
exports.DeletePatchBaselineCommand = DeletePatchBaselineCommand;
exports.DeleteResourceDataSyncCommand = DeleteResourceDataSyncCommand;
exports.DeleteResourcePolicyCommand = DeleteResourcePolicyCommand;
exports.DeregisterManagedInstanceCommand = DeregisterManagedInstanceCommand;
exports.DeregisterPatchBaselineForPatchGroupCommand = DeregisterPatchBaselineForPatchGroupCommand;
exports.DeregisterTargetFromMaintenanceWindowCommand = DeregisterTargetFromMaintenanceWindowCommand;
exports.DeregisterTaskFromMaintenanceWindowCommand = DeregisterTaskFromMaintenanceWindowCommand;
exports.DescribeActivationsCommand = DescribeActivationsCommand;
exports.DescribeActivationsFilterKeys = DescribeActivationsFilterKeys;
exports.DescribeAssociationCommand = DescribeAssociationCommand;
exports.DescribeAssociationExecutionTargetsCommand = DescribeAssociationExecutionTargetsCommand;
exports.DescribeAssociationExecutionsCommand = DescribeAssociationExecutionsCommand;
exports.DescribeAssociationResultFilterSensitiveLog = DescribeAssociationResultFilterSensitiveLog;
exports.DescribeAutomationExecutionsCommand = DescribeAutomationExecutionsCommand;
exports.DescribeAutomationStepExecutionsCommand = DescribeAutomationStepExecutionsCommand;
exports.DescribeAvailablePatchesCommand = DescribeAvailablePatchesCommand;
exports.DescribeDocumentCommand = DescribeDocumentCommand;
exports.DescribeDocumentPermissionCommand = DescribeDocumentPermissionCommand;
exports.DescribeEffectiveInstanceAssociationsCommand = DescribeEffectiveInstanceAssociationsCommand;
exports.DescribeEffectivePatchesForPatchBaselineCommand = DescribeEffectivePatchesForPatchBaselineCommand;
exports.DescribeInstanceAssociationsStatusCommand = DescribeInstanceAssociationsStatusCommand;
exports.DescribeInstanceInformationCommand = DescribeInstanceInformationCommand;
exports.DescribeInstanceInformationResultFilterSensitiveLog = DescribeInstanceInformationResultFilterSensitiveLog;
exports.DescribeInstancePatchStatesCommand = DescribeInstancePatchStatesCommand;
exports.DescribeInstancePatchStatesForPatchGroupCommand = DescribeInstancePatchStatesForPatchGroupCommand;
exports.DescribeInstancePatchStatesForPatchGroupResultFilterSensitiveLog = DescribeInstancePatchStatesForPatchGroupResultFilterSensitiveLog;
exports.DescribeInstancePatchStatesResultFilterSensitiveLog = DescribeInstancePatchStatesResultFilterSensitiveLog;
exports.DescribeInstancePatchesCommand = DescribeInstancePatchesCommand;
exports.DescribeInstancePropertiesCommand = DescribeInstancePropertiesCommand;
exports.DescribeInstancePropertiesResultFilterSensitiveLog = DescribeInstancePropertiesResultFilterSensitiveLog;
exports.DescribeInventoryDeletionsCommand = DescribeInventoryDeletionsCommand;
exports.DescribeMaintenanceWindowExecutionTaskInvocationsCommand = DescribeMaintenanceWindowExecutionTaskInvocationsCommand;
exports.DescribeMaintenanceWindowExecutionTaskInvocationsResultFilterSensitiveLog = DescribeMaintenanceWindowExecutionTaskInvocationsResultFilterSensitiveLog;
exports.DescribeMaintenanceWindowExecutionTasksCommand = DescribeMaintenanceWindowExecutionTasksCommand;
exports.DescribeMaintenanceWindowExecutionsCommand = DescribeMaintenanceWindowExecutionsCommand;
exports.DescribeMaintenanceWindowScheduleCommand = DescribeMaintenanceWindowScheduleCommand;
exports.DescribeMaintenanceWindowTargetsCommand = DescribeMaintenanceWindowTargetsCommand;
exports.DescribeMaintenanceWindowTargetsResultFilterSensitiveLog = DescribeMaintenanceWindowTargetsResultFilterSensitiveLog;
exports.DescribeMaintenanceWindowTasksCommand = DescribeMaintenanceWindowTasksCommand;
exports.DescribeMaintenanceWindowTasksResultFilterSensitiveLog = DescribeMaintenanceWindowTasksResultFilterSensitiveLog;
exports.DescribeMaintenanceWindowsCommand = DescribeMaintenanceWindowsCommand;
exports.DescribeMaintenanceWindowsForTargetCommand = DescribeMaintenanceWindowsForTargetCommand;
exports.DescribeMaintenanceWindowsResultFilterSensitiveLog = DescribeMaintenanceWindowsResultFilterSensitiveLog;
exports.DescribeOpsItemsCommand = DescribeOpsItemsCommand;
exports.DescribeParametersCommand = DescribeParametersCommand;
exports.DescribePatchBaselinesCommand = DescribePatchBaselinesCommand;
exports.DescribePatchGroupStateCommand = DescribePatchGroupStateCommand;
exports.DescribePatchGroupsCommand = DescribePatchGroupsCommand;
exports.DescribePatchPropertiesCommand = DescribePatchPropertiesCommand;
exports.DescribeSessionsCommand = DescribeSessionsCommand;
exports.DisassociateOpsItemRelatedItemCommand = DisassociateOpsItemRelatedItemCommand;
exports.DocumentAlreadyExists = DocumentAlreadyExists;
exports.DocumentFilterKey = DocumentFilterKey;
exports.DocumentFormat = DocumentFormat;
exports.DocumentHashType = DocumentHashType;
exports.DocumentLimitExceeded = DocumentLimitExceeded;
exports.DocumentMetadataEnum = DocumentMetadataEnum;
exports.DocumentParameterType = DocumentParameterType;
exports.DocumentPermissionLimit = DocumentPermissionLimit;
exports.DocumentPermissionType = DocumentPermissionType;
exports.DocumentReviewAction = DocumentReviewAction;
exports.DocumentReviewCommentType = DocumentReviewCommentType;
exports.DocumentStatus = DocumentStatus;
exports.DocumentType = DocumentType;
exports.DocumentVersionLimitExceeded = DocumentVersionLimitExceeded;
exports.DoesNotExistException = DoesNotExistException;
exports.DuplicateDocumentContent = DuplicateDocumentContent;
exports.DuplicateDocumentVersionName = DuplicateDocumentVersionName;
exports.DuplicateInstanceId = DuplicateInstanceId;
exports.ExecutionMode = ExecutionMode;
exports.ExecutionPreviewStatus = ExecutionPreviewStatus;
exports.ExternalAlarmState = ExternalAlarmState;
exports.FailedCreateAssociationFilterSensitiveLog = FailedCreateAssociationFilterSensitiveLog;
exports.Fault = Fault;
exports.FeatureNotAvailableException = FeatureNotAvailableException;
exports.GetAccessTokenCommand = GetAccessTokenCommand;
exports.GetAccessTokenResponseFilterSensitiveLog = GetAccessTokenResponseFilterSensitiveLog;
exports.GetAutomationExecutionCommand = GetAutomationExecutionCommand;
exports.GetCalendarStateCommand = GetCalendarStateCommand;
exports.GetCommandInvocationCommand = GetCommandInvocationCommand;
exports.GetConnectionStatusCommand = GetConnectionStatusCommand;
exports.GetDefaultPatchBaselineCommand = GetDefaultPatchBaselineCommand;
exports.GetDeployablePatchSnapshotForInstanceCommand = GetDeployablePatchSnapshotForInstanceCommand;
exports.GetDeployablePatchSnapshotForInstanceRequestFilterSensitiveLog = GetDeployablePatchSnapshotForInstanceRequestFilterSensitiveLog;
exports.GetDocumentCommand = GetDocumentCommand;
exports.GetExecutionPreviewCommand = GetExecutionPreviewCommand;
exports.GetInventoryCommand = GetInventoryCommand;
exports.GetInventorySchemaCommand = GetInventorySchemaCommand;
exports.GetMaintenanceWindowCommand = GetMaintenanceWindowCommand;
exports.GetMaintenanceWindowExecutionCommand = GetMaintenanceWindowExecutionCommand;
exports.GetMaintenanceWindowExecutionTaskCommand = GetMaintenanceWindowExecutionTaskCommand;
exports.GetMaintenanceWindowExecutionTaskInvocationCommand = GetMaintenanceWindowExecutionTaskInvocationCommand;
exports.GetMaintenanceWindowExecutionTaskInvocationResultFilterSensitiveLog = GetMaintenanceWindowExecutionTaskInvocationResultFilterSensitiveLog;
exports.GetMaintenanceWindowExecutionTaskResultFilterSensitiveLog = GetMaintenanceWindowExecutionTaskResultFilterSensitiveLog;
exports.GetMaintenanceWindowResultFilterSensitiveLog = GetMaintenanceWindowResultFilterSensitiveLog;
exports.GetMaintenanceWindowTaskCommand = GetMaintenanceWindowTaskCommand;
exports.GetMaintenanceWindowTaskResultFilterSensitiveLog = GetMaintenanceWindowTaskResultFilterSensitiveLog;
exports.GetOpsItemCommand = GetOpsItemCommand;
exports.GetOpsMetadataCommand = GetOpsMetadataCommand;
exports.GetOpsSummaryCommand = GetOpsSummaryCommand;
exports.GetParameterCommand = GetParameterCommand;
exports.GetParameterHistoryCommand = GetParameterHistoryCommand;
exports.GetParameterHistoryResultFilterSensitiveLog = GetParameterHistoryResultFilterSensitiveLog;
exports.GetParameterResultFilterSensitiveLog = GetParameterResultFilterSensitiveLog;
exports.GetParametersByPathCommand = GetParametersByPathCommand;
exports.GetParametersByPathResultFilterSensitiveLog = GetParametersByPathResultFilterSensitiveLog;
exports.GetParametersCommand = GetParametersCommand;
exports.GetParametersResultFilterSensitiveLog = GetParametersResultFilterSensitiveLog;
exports.GetPatchBaselineCommand = GetPatchBaselineCommand;
exports.GetPatchBaselineForPatchGroupCommand = GetPatchBaselineForPatchGroupCommand;
exports.GetPatchBaselineResultFilterSensitiveLog = GetPatchBaselineResultFilterSensitiveLog;
exports.GetResourcePoliciesCommand = GetResourcePoliciesCommand;
exports.GetServiceSettingCommand = GetServiceSettingCommand;
exports.HierarchyLevelLimitExceededException = HierarchyLevelLimitExceededException;
exports.HierarchyTypeMismatchException = HierarchyTypeMismatchException;
exports.IdempotentParameterMismatch = IdempotentParameterMismatch;
exports.ImpactType = ImpactType;
exports.IncompatiblePolicyException = IncompatiblePolicyException;
exports.InstanceInfoFilterSensitiveLog = InstanceInfoFilterSensitiveLog;
exports.InstanceInformationFilterKey = InstanceInformationFilterKey;
exports.InstanceInformationFilterSensitiveLog = InstanceInformationFilterSensitiveLog;
exports.InstancePatchStateFilterSensitiveLog = InstancePatchStateFilterSensitiveLog;
exports.InstancePatchStateOperatorType = InstancePatchStateOperatorType;
exports.InstancePropertyFilterKey = InstancePropertyFilterKey;
exports.InstancePropertyFilterOperator = InstancePropertyFilterOperator;
exports.InstancePropertyFilterSensitiveLog = InstancePropertyFilterSensitiveLog;
exports.InternalServerError = InternalServerError;
exports.InvalidActivation = InvalidActivation;
exports.InvalidActivationId = InvalidActivationId;
exports.InvalidAggregatorException = InvalidAggregatorException;
exports.InvalidAllowedPatternException = InvalidAllowedPatternException;
exports.InvalidAssociation = InvalidAssociation;
exports.InvalidAssociationVersion = InvalidAssociationVersion;
exports.InvalidAutomationExecutionParametersException = InvalidAutomationExecutionParametersException;
exports.InvalidAutomationSignalException = InvalidAutomationSignalException;
exports.InvalidAutomationStatusUpdateException = InvalidAutomationStatusUpdateException;
exports.InvalidCommandId = InvalidCommandId;
exports.InvalidDeleteInventoryParametersException = InvalidDeleteInventoryParametersException;
exports.InvalidDeletionIdException = InvalidDeletionIdException;
exports.InvalidDocument = InvalidDocument;
exports.InvalidDocumentContent = InvalidDocumentContent;
exports.InvalidDocumentOperation = InvalidDocumentOperation;
exports.InvalidDocumentSchemaVersion = InvalidDocumentSchemaVersion;
exports.InvalidDocumentType = InvalidDocumentType;
exports.InvalidDocumentVersion = InvalidDocumentVersion;
exports.InvalidFilter = InvalidFilter;
exports.InvalidFilterKey = InvalidFilterKey;
exports.InvalidFilterOption = InvalidFilterOption;
exports.InvalidFilterValue = InvalidFilterValue;
exports.InvalidInstanceId = InvalidInstanceId;
exports.InvalidInstanceInformationFilterValue = InvalidInstanceInformationFilterValue;
exports.InvalidInstancePropertyFilterValue = InvalidInstancePropertyFilterValue;
exports.InvalidInventoryGroupException = InvalidInventoryGroupException;
exports.InvalidInventoryItemContextException = InvalidInventoryItemContextException;
exports.InvalidInventoryRequestException = InvalidInventoryRequestException;
exports.InvalidItemContentException = InvalidItemContentException;
exports.InvalidKeyId = InvalidKeyId;
exports.InvalidNextToken = InvalidNextToken;
exports.InvalidNotificationConfig = InvalidNotificationConfig;
exports.InvalidOptionException = InvalidOptionException;
exports.InvalidOutputFolder = InvalidOutputFolder;
exports.InvalidOutputLocation = InvalidOutputLocation;
exports.InvalidParameters = InvalidParameters;
exports.InvalidPermissionType = InvalidPermissionType;
exports.InvalidPluginName = InvalidPluginName;
exports.InvalidPolicyAttributeException = InvalidPolicyAttributeException;
exports.InvalidPolicyTypeException = InvalidPolicyTypeException;
exports.InvalidResourceId = InvalidResourceId;
exports.InvalidResourceType = InvalidResourceType;
exports.InvalidResultAttributeException = InvalidResultAttributeException;
exports.InvalidRole = InvalidRole;
exports.InvalidSchedule = InvalidSchedule;
exports.InvalidTag = InvalidTag;
exports.InvalidTarget = InvalidTarget;
exports.InvalidTargetMaps = InvalidTargetMaps;
exports.InvalidTypeNameException = InvalidTypeNameException;
exports.InvalidUpdate = InvalidUpdate;
exports.InventoryAttributeDataType = InventoryAttributeDataType;
exports.InventoryDeletionStatus = InventoryDeletionStatus;
exports.InventoryQueryOperatorType = InventoryQueryOperatorType;
exports.InventorySchemaDeleteOption = InventorySchemaDeleteOption;
exports.InvocationDoesNotExist = InvocationDoesNotExist;
exports.ItemContentMismatchException = ItemContentMismatchException;
exports.ItemSizeLimitExceededException = ItemSizeLimitExceededException;
exports.LabelParameterVersionCommand = LabelParameterVersionCommand;
exports.LastResourceDataSyncStatus = LastResourceDataSyncStatus;
exports.ListAssociationVersionsCommand = ListAssociationVersionsCommand;
exports.ListAssociationVersionsResultFilterSensitiveLog = ListAssociationVersionsResultFilterSensitiveLog;
exports.ListAssociationsCommand = ListAssociationsCommand;
exports.ListCommandInvocationsCommand = ListCommandInvocationsCommand;
exports.ListCommandsCommand = ListCommandsCommand;
exports.ListCommandsResultFilterSensitiveLog = ListCommandsResultFilterSensitiveLog;
exports.ListComplianceItemsCommand = ListComplianceItemsCommand;
exports.ListComplianceSummariesCommand = ListComplianceSummariesCommand;
exports.ListDocumentMetadataHistoryCommand = ListDocumentMetadataHistoryCommand;
exports.ListDocumentVersionsCommand = ListDocumentVersionsCommand;
exports.ListDocumentsCommand = ListDocumentsCommand;
exports.ListInventoryEntriesCommand = ListInventoryEntriesCommand;
exports.ListNodesCommand = ListNodesCommand;
exports.ListNodesResultFilterSensitiveLog = ListNodesResultFilterSensitiveLog;
exports.ListNodesSummaryCommand = ListNodesSummaryCommand;
exports.ListOpsItemEventsCommand = ListOpsItemEventsCommand;
exports.ListOpsItemRelatedItemsCommand = ListOpsItemRelatedItemsCommand;
exports.ListOpsMetadataCommand = ListOpsMetadataCommand;
exports.ListResourceComplianceSummariesCommand = ListResourceComplianceSummariesCommand;
exports.ListResourceDataSyncCommand = ListResourceDataSyncCommand;
exports.ListTagsForResourceCommand = ListTagsForResourceCommand;
exports.MaintenanceWindowExecutionStatus = MaintenanceWindowExecutionStatus;
exports.MaintenanceWindowExecutionTaskInvocationIdentityFilterSensitiveLog = MaintenanceWindowExecutionTaskInvocationIdentityFilterSensitiveLog;
exports.MaintenanceWindowIdentityFilterSensitiveLog = MaintenanceWindowIdentityFilterSensitiveLog;
exports.MaintenanceWindowLambdaParametersFilterSensitiveLog = MaintenanceWindowLambdaParametersFilterSensitiveLog;
exports.MaintenanceWindowResourceType = MaintenanceWindowResourceType;
exports.MaintenanceWindowRunCommandParametersFilterSensitiveLog = MaintenanceWindowRunCommandParametersFilterSensitiveLog;
exports.MaintenanceWindowStepFunctionsParametersFilterSensitiveLog = MaintenanceWindowStepFunctionsParametersFilterSensitiveLog;
exports.MaintenanceWindowTargetFilterSensitiveLog = MaintenanceWindowTargetFilterSensitiveLog;
exports.MaintenanceWindowTaskCutoffBehavior = MaintenanceWindowTaskCutoffBehavior;
exports.MaintenanceWindowTaskFilterSensitiveLog = MaintenanceWindowTaskFilterSensitiveLog;
exports.MaintenanceWindowTaskInvocationParametersFilterSensitiveLog = MaintenanceWindowTaskInvocationParametersFilterSensitiveLog;
exports.MaintenanceWindowTaskParameterValueExpressionFilterSensitiveLog = MaintenanceWindowTaskParameterValueExpressionFilterSensitiveLog;
exports.MaintenanceWindowTaskType = MaintenanceWindowTaskType;
exports.MalformedResourcePolicyDocumentException = MalformedResourcePolicyDocumentException;
exports.ManagedStatus = ManagedStatus;
exports.MaxDocumentSizeExceeded = MaxDocumentSizeExceeded;
exports.ModifyDocumentPermissionCommand = ModifyDocumentPermissionCommand;
exports.NodeAggregatorType = NodeAggregatorType;
exports.NodeAttributeName = NodeAttributeName;
exports.NodeFilterKey = NodeFilterKey;
exports.NodeFilterOperatorType = NodeFilterOperatorType;
exports.NodeFilterSensitiveLog = NodeFilterSensitiveLog;
exports.NodeTypeFilterSensitiveLog = NodeTypeFilterSensitiveLog;
exports.NodeTypeName = NodeTypeName;
exports.NotificationEvent = NotificationEvent;
exports.NotificationType = NotificationType;
exports.OperatingSystem = OperatingSystem;
exports.OpsFilterOperatorType = OpsFilterOperatorType;
exports.OpsItemAccessDeniedException = OpsItemAccessDeniedException;
exports.OpsItemAlreadyExistsException = OpsItemAlreadyExistsException;
exports.OpsItemConflictException = OpsItemConflictException;
exports.OpsItemDataType = OpsItemDataType;
exports.OpsItemEventFilterKey = OpsItemEventFilterKey;
exports.OpsItemEventFilterOperator = OpsItemEventFilterOperator;
exports.OpsItemFilterKey = OpsItemFilterKey;
exports.OpsItemFilterOperator = OpsItemFilterOperator;
exports.OpsItemInvalidParameterException = OpsItemInvalidParameterException;
exports.OpsItemLimitExceededException = OpsItemLimitExceededException;
exports.OpsItemNotFoundException = OpsItemNotFoundException;
exports.OpsItemRelatedItemAlreadyExistsException = OpsItemRelatedItemAlreadyExistsException;
exports.OpsItemRelatedItemAssociationNotFoundException = OpsItemRelatedItemAssociationNotFoundException;
exports.OpsItemRelatedItemsFilterKey = OpsItemRelatedItemsFilterKey;
exports.OpsItemRelatedItemsFilterOperator = OpsItemRelatedItemsFilterOperator;
exports.OpsItemStatus = OpsItemStatus;
exports.OpsMetadataAlreadyExistsException = OpsMetadataAlreadyExistsException;
exports.OpsMetadataInvalidArgumentException = OpsMetadataInvalidArgumentException;
exports.OpsMetadataKeyLimitExceededException = OpsMetadataKeyLimitExceededException;
exports.OpsMetadataLimitExceededException = OpsMetadataLimitExceededException;
exports.OpsMetadataNotFoundException = OpsMetadataNotFoundException;
exports.OpsMetadataTooManyUpdatesException = OpsMetadataTooManyUpdatesException;
exports.ParameterAlreadyExists = ParameterAlreadyExists;
exports.ParameterFilterSensitiveLog = ParameterFilterSensitiveLog;
exports.ParameterHistoryFilterSensitiveLog = ParameterHistoryFilterSensitiveLog;
exports.ParameterLimitExceeded = ParameterLimitExceeded;
exports.ParameterMaxVersionLimitExceeded = ParameterMaxVersionLimitExceeded;
exports.ParameterNotFound = ParameterNotFound;
exports.ParameterPatternMismatchException = ParameterPatternMismatchException;
exports.ParameterTier = ParameterTier;
exports.ParameterType = ParameterType;
exports.ParameterVersionLabelLimitExceeded = ParameterVersionLabelLimitExceeded;
exports.ParameterVersionNotFound = ParameterVersionNotFound;
exports.ParametersFilterKey = ParametersFilterKey;
exports.PatchAction = PatchAction;
exports.PatchComplianceDataState = PatchComplianceDataState;
exports.PatchComplianceLevel = PatchComplianceLevel;
exports.PatchComplianceStatus = PatchComplianceStatus;
exports.PatchDeploymentStatus = PatchDeploymentStatus;
exports.PatchFilterKey = PatchFilterKey;
exports.PatchOperationType = PatchOperationType;
exports.PatchProperty = PatchProperty;
exports.PatchSet = PatchSet;
exports.PatchSourceFilterSensitiveLog = PatchSourceFilterSensitiveLog;
exports.PingStatus = PingStatus;
exports.PlatformType = PlatformType;
exports.PoliciesLimitExceededException = PoliciesLimitExceededException;
exports.PutComplianceItemsCommand = PutComplianceItemsCommand;
exports.PutInventoryCommand = PutInventoryCommand;
exports.PutParameterCommand = PutParameterCommand;
exports.PutParameterRequestFilterSensitiveLog = PutParameterRequestFilterSensitiveLog;
exports.PutResourcePolicyCommand = PutResourcePolicyCommand;
exports.RebootOption = RebootOption;
exports.RegisterDefaultPatchBaselineCommand = RegisterDefaultPatchBaselineCommand;
exports.RegisterPatchBaselineForPatchGroupCommand = RegisterPatchBaselineForPatchGroupCommand;
exports.RegisterTargetWithMaintenanceWindowCommand = RegisterTargetWithMaintenanceWindowCommand;
exports.RegisterTargetWithMaintenanceWindowRequestFilterSensitiveLog = RegisterTargetWithMaintenanceWindowRequestFilterSensitiveLog;
exports.RegisterTaskWithMaintenanceWindowCommand = RegisterTaskWithMaintenanceWindowCommand;
exports.RegisterTaskWithMaintenanceWindowRequestFilterSensitiveLog = RegisterTaskWithMaintenanceWindowRequestFilterSensitiveLog;
exports.RemoveTagsFromResourceCommand = RemoveTagsFromResourceCommand;
exports.ResetServiceSettingCommand = ResetServiceSettingCommand;
exports.ResourceDataSyncAlreadyExistsException = ResourceDataSyncAlreadyExistsException;
exports.ResourceDataSyncConflictException = ResourceDataSyncConflictException;
exports.ResourceDataSyncCountExceededException = ResourceDataSyncCountExceededException;
exports.ResourceDataSyncInvalidConfigurationException = ResourceDataSyncInvalidConfigurationException;
exports.ResourceDataSyncNotFoundException = ResourceDataSyncNotFoundException;
exports.ResourceDataSyncS3Format = ResourceDataSyncS3Format;
exports.ResourceInUseException = ResourceInUseException;
exports.ResourceLimitExceededException = ResourceLimitExceededException;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ResourcePolicyConflictException = ResourcePolicyConflictException;
exports.ResourcePolicyInvalidParameterException = ResourcePolicyInvalidParameterException;
exports.ResourcePolicyLimitExceededException = ResourcePolicyLimitExceededException;
exports.ResourcePolicyNotFoundException = ResourcePolicyNotFoundException;
exports.ResourceType = ResourceType;
exports.ResourceTypeForTagging = ResourceTypeForTagging;
exports.ResumeSessionCommand = ResumeSessionCommand;
exports.ReviewStatus = ReviewStatus;
exports.SSM = SSM;
exports.SSMClient = SSMClient;
exports.SSMServiceException = SSMServiceException;
exports.SendAutomationSignalCommand = SendAutomationSignalCommand;
exports.SendCommandCommand = SendCommandCommand;
exports.SendCommandRequestFilterSensitiveLog = SendCommandRequestFilterSensitiveLog;
exports.SendCommandResultFilterSensitiveLog = SendCommandResultFilterSensitiveLog;
exports.ServiceQuotaExceededException = ServiceQuotaExceededException;
exports.ServiceSettingNotFound = ServiceSettingNotFound;
exports.SessionFilterKey = SessionFilterKey;
exports.SessionState = SessionState;
exports.SessionStatus = SessionStatus;
exports.SignalType = SignalType;
exports.SourceType = SourceType;
exports.StartAccessRequestCommand = StartAccessRequestCommand;
exports.StartAssociationsOnceCommand = StartAssociationsOnceCommand;
exports.StartAutomationExecutionCommand = StartAutomationExecutionCommand;
exports.StartChangeRequestExecutionCommand = StartChangeRequestExecutionCommand;
exports.StartExecutionPreviewCommand = StartExecutionPreviewCommand;
exports.StartSessionCommand = StartSessionCommand;
exports.StatusUnchanged = StatusUnchanged;
exports.StepExecutionFilterKey = StepExecutionFilterKey;
exports.StopAutomationExecutionCommand = StopAutomationExecutionCommand;
exports.StopType = StopType;
exports.SubTypeCountLimitExceededException = SubTypeCountLimitExceededException;
exports.TargetInUseException = TargetInUseException;
exports.TargetNotConnected = TargetNotConnected;
exports.TerminateSessionCommand = TerminateSessionCommand;
exports.ThrottlingException = ThrottlingException;
exports.TooManyTagsError = TooManyTagsError;
exports.TooManyUpdates = TooManyUpdates;
exports.TotalSizeLimitExceededException = TotalSizeLimitExceededException;
exports.UnlabelParameterVersionCommand = UnlabelParameterVersionCommand;
exports.UnsupportedCalendarException = UnsupportedCalendarException;
exports.UnsupportedFeatureRequiredException = UnsupportedFeatureRequiredException;
exports.UnsupportedInventoryItemContextException = UnsupportedInventoryItemContextException;
exports.UnsupportedInventorySchemaVersionException = UnsupportedInventorySchemaVersionException;
exports.UnsupportedOperatingSystem = UnsupportedOperatingSystem;
exports.UnsupportedOperationException = UnsupportedOperationException;
exports.UnsupportedParameterType = UnsupportedParameterType;
exports.UnsupportedPlatformType = UnsupportedPlatformType;
exports.UpdateAssociationCommand = UpdateAssociationCommand;
exports.UpdateAssociationRequestFilterSensitiveLog = UpdateAssociationRequestFilterSensitiveLog;
exports.UpdateAssociationResultFilterSensitiveLog = UpdateAssociationResultFilterSensitiveLog;
exports.UpdateAssociationStatusCommand = UpdateAssociationStatusCommand;
exports.UpdateAssociationStatusResultFilterSensitiveLog = UpdateAssociationStatusResultFilterSensitiveLog;
exports.UpdateDocumentCommand = UpdateDocumentCommand;
exports.UpdateDocumentDefaultVersionCommand = UpdateDocumentDefaultVersionCommand;
exports.UpdateDocumentMetadataCommand = UpdateDocumentMetadataCommand;
exports.UpdateMaintenanceWindowCommand = UpdateMaintenanceWindowCommand;
exports.UpdateMaintenanceWindowRequestFilterSensitiveLog = UpdateMaintenanceWindowRequestFilterSensitiveLog;
exports.UpdateMaintenanceWindowResultFilterSensitiveLog = UpdateMaintenanceWindowResultFilterSensitiveLog;
exports.UpdateMaintenanceWindowTargetCommand = UpdateMaintenanceWindowTargetCommand;
exports.UpdateMaintenanceWindowTargetRequestFilterSensitiveLog = UpdateMaintenanceWindowTargetRequestFilterSensitiveLog;
exports.UpdateMaintenanceWindowTargetResultFilterSensitiveLog = UpdateMaintenanceWindowTargetResultFilterSensitiveLog;
exports.UpdateMaintenanceWindowTaskCommand = UpdateMaintenanceWindowTaskCommand;
exports.UpdateMaintenanceWindowTaskRequestFilterSensitiveLog = UpdateMaintenanceWindowTaskRequestFilterSensitiveLog;
exports.UpdateMaintenanceWindowTaskResultFilterSensitiveLog = UpdateMaintenanceWindowTaskResultFilterSensitiveLog;
exports.UpdateManagedInstanceRoleCommand = UpdateManagedInstanceRoleCommand;
exports.UpdateOpsItemCommand = UpdateOpsItemCommand;
exports.UpdateOpsMetadataCommand = UpdateOpsMetadataCommand;
exports.UpdatePatchBaselineCommand = UpdatePatchBaselineCommand;
exports.UpdatePatchBaselineRequestFilterSensitiveLog = UpdatePatchBaselineRequestFilterSensitiveLog;
exports.UpdatePatchBaselineResultFilterSensitiveLog = UpdatePatchBaselineResultFilterSensitiveLog;
exports.UpdateResourceDataSyncCommand = UpdateResourceDataSyncCommand;
exports.UpdateServiceSettingCommand = UpdateServiceSettingCommand;
exports.ValidationException = ValidationException;
exports.paginateDescribeActivations = paginateDescribeActivations;
exports.paginateDescribeAssociationExecutionTargets = paginateDescribeAssociationExecutionTargets;
exports.paginateDescribeAssociationExecutions = paginateDescribeAssociationExecutions;
exports.paginateDescribeAutomationExecutions = paginateDescribeAutomationExecutions;
exports.paginateDescribeAutomationStepExecutions = paginateDescribeAutomationStepExecutions;
exports.paginateDescribeAvailablePatches = paginateDescribeAvailablePatches;
exports.paginateDescribeEffectiveInstanceAssociations = paginateDescribeEffectiveInstanceAssociations;
exports.paginateDescribeEffectivePatchesForPatchBaseline = paginateDescribeEffectivePatchesForPatchBaseline;
exports.paginateDescribeInstanceAssociationsStatus = paginateDescribeInstanceAssociationsStatus;
exports.paginateDescribeInstanceInformation = paginateDescribeInstanceInformation;
exports.paginateDescribeInstancePatchStates = paginateDescribeInstancePatchStates;
exports.paginateDescribeInstancePatchStatesForPatchGroup = paginateDescribeInstancePatchStatesForPatchGroup;
exports.paginateDescribeInstancePatches = paginateDescribeInstancePatches;
exports.paginateDescribeInstanceProperties = paginateDescribeInstanceProperties;
exports.paginateDescribeInventoryDeletions = paginateDescribeInventoryDeletions;
exports.paginateDescribeMaintenanceWindowExecutionTaskInvocations = paginateDescribeMaintenanceWindowExecutionTaskInvocations;
exports.paginateDescribeMaintenanceWindowExecutionTasks = paginateDescribeMaintenanceWindowExecutionTasks;
exports.paginateDescribeMaintenanceWindowExecutions = paginateDescribeMaintenanceWindowExecutions;
exports.paginateDescribeMaintenanceWindowSchedule = paginateDescribeMaintenanceWindowSchedule;
exports.paginateDescribeMaintenanceWindowTargets = paginateDescribeMaintenanceWindowTargets;
exports.paginateDescribeMaintenanceWindowTasks = paginateDescribeMaintenanceWindowTasks;
exports.paginateDescribeMaintenanceWindows = paginateDescribeMaintenanceWindows;
exports.paginateDescribeMaintenanceWindowsForTarget = paginateDescribeMaintenanceWindowsForTarget;
exports.paginateDescribeOpsItems = paginateDescribeOpsItems;
exports.paginateDescribeParameters = paginateDescribeParameters;
exports.paginateDescribePatchBaselines = paginateDescribePatchBaselines;
exports.paginateDescribePatchGroups = paginateDescribePatchGroups;
exports.paginateDescribePatchProperties = paginateDescribePatchProperties;
exports.paginateDescribeSessions = paginateDescribeSessions;
exports.paginateGetInventory = paginateGetInventory;
exports.paginateGetInventorySchema = paginateGetInventorySchema;
exports.paginateGetOpsSummary = paginateGetOpsSummary;
exports.paginateGetParameterHistory = paginateGetParameterHistory;
exports.paginateGetParametersByPath = paginateGetParametersByPath;
exports.paginateGetResourcePolicies = paginateGetResourcePolicies;
exports.paginateListAssociationVersions = paginateListAssociationVersions;
exports.paginateListAssociations = paginateListAssociations;
exports.paginateListCommandInvocations = paginateListCommandInvocations;
exports.paginateListCommands = paginateListCommands;
exports.paginateListComplianceItems = paginateListComplianceItems;
exports.paginateListComplianceSummaries = paginateListComplianceSummaries;
exports.paginateListDocumentVersions = paginateListDocumentVersions;
exports.paginateListDocuments = paginateListDocuments;
exports.paginateListNodes = paginateListNodes;
exports.paginateListNodesSummary = paginateListNodesSummary;
exports.paginateListOpsItemEvents = paginateListOpsItemEvents;
exports.paginateListOpsItemRelatedItems = paginateListOpsItemRelatedItems;
exports.paginateListOpsMetadata = paginateListOpsMetadata;
exports.paginateListResourceComplianceSummaries = paginateListResourceComplianceSummaries;
exports.paginateListResourceDataSync = paginateListResourceDataSync;
exports.waitForCommandExecuted = waitForCommandExecuted;
exports.waitUntilCommandExecuted = waitUntilCommandExecuted;

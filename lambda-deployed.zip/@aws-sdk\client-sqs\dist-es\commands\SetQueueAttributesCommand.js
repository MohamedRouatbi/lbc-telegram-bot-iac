import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { de_SetQueueAttributesCommand, se_SetQueueAttributesCommand } from "../protocols/Aws_json1_0";
export { $Command };
export class SetQueueAttributesCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSQS", "SetQueueAttributes", {})
    .n("SQSClient", "SetQueueAttributesCommand")
    .f(void 0, void 0)
    .ser(se_SetQueueAttributesCommand)
    .de(de_SetQueueAttributesCommand)
    .build() {
}

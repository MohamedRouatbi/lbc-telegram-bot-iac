import type { SQSEvent } from 'aws-lambda';
/**
 * Lambda handler for SQS job worker
 * Processes messages from SQS queue and writes to DynamoDB
 */
export declare function handler(event: SQSEvent): Promise<void>;
//# sourceMappingURL=index.d.ts.map
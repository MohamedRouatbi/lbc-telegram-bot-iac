import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { de_DescribeInstancePatchesCommand, se_DescribeInstancePatchesCommand } from "../protocols/Aws_json1_1";
export { $Command };
export class DescribeInstancePatchesCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("AmazonSSM", "DescribeInstancePatches", {})
    .n("SSMClient", "DescribeInstancePatchesCommand")
    .f(void 0, void 0)
    .ser(se_DescribeInstancePatchesCommand)
    .de(de_DescribeInstancePatchesCommand)
    .build() {
}

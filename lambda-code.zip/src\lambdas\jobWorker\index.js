"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const uuid_1 = require("uuid");
const dynamodb_1 = require("../../lib/dynamodb");
const startHandler_1 = require("./startHandler");
/**
 * Lambda handler for SQS job worker
 * Processes messages from SQS queue and writes to DynamoDB
 */
async function handler(event) {
    console.log(`Processing ${event.Records.length} messages from SQS`);
    // Process messages in parallel
    await Promise.all(event.Records.map(processRecord));
    console.log('All messages processed successfully');
}
async function processRecord(record) {
    try {
        console.log('Processing SQS record', {
            messageId: record.messageId,
            attributes: record.messageAttributes,
        });
        const message = JSON.parse(record.body);
        // Process based on event type
        switch (message.eventType) {
            case 'message':
                await handleMessage(message);
                break;
            case 'edited_message':
                await handleEditedMessage(message);
                break;
            case 'callback_query':
                await handleCallbackQuery(message);
                break;
            default:
                console.log(`Unknown event type: ${message.eventType}`);
        }
        // Record the event in DynamoDB
        await recordEvent(message);
        console.log('Record processed successfully', {
            messageId: record.messageId,
            eventType: message.eventType,
        });
    }
    catch (error) {
        console.error('Error processing record:', error);
        // Throw error to move message to DLQ
        throw error;
    }
}
async function handleMessage(message) {
    const telegramMessage = message.update.message;
    if (!telegramMessage)
        return;
    console.log('Handling message', {
        messageId: telegramMessage.message_id,
        chatId: telegramMessage.chat.id,
        text: telegramMessage.text,
    });
    // Check if this is a /start command
    const text = telegramMessage.text || '';
    if (text.startsWith('/start')) {
        console.log('Detected /start command');
        await (0, startHandler_1.handleStartCommand)(telegramMessage);
        return;
    }
    // Upsert user if message has sender
    if (telegramMessage.from) {
        await upsertUser(telegramMessage.from);
    }
    // Here you would add your business logic
    // For now, we just log the message
    console.log('Message processed:', {
        from: telegramMessage.from?.username,
        text: telegramMessage.text,
    });
}
async function handleEditedMessage(message) {
    const editedMessage = message.update.edited_message;
    if (!editedMessage)
        return;
    console.log('Handling edited message', {
        messageId: editedMessage.message_id,
        chatId: editedMessage.chat.id,
    });
    // Add your logic for edited messages
}
async function handleCallbackQuery(message) {
    const callbackQuery = message.update.callback_query;
    if (!callbackQuery)
        return;
    console.log('Handling callback query', {
        queryId: callbackQuery.id,
        data: callbackQuery.data,
        from: callbackQuery.from.username,
    });
    // Upsert user
    await upsertUser(callbackQuery.from);
    // Add your logic for callback queries
}
async function upsertUser(telegramUser) {
    const userId = `telegram_${telegramUser.id}`;
    // Check if user exists
    const existingUser = await (0, dynamodb_1.getUser)(userId);
    if (existingUser) {
        // Update user
        await (0, dynamodb_1.updateUser)(userId, {
            username: telegramUser.username,
            firstName: telegramUser.first_name,
            lastName: telegramUser.last_name,
            languageCode: telegramUser.language_code,
            updatedAt: new Date().toISOString(),
        });
    }
    else {
        // Create new user
        const newUser = {
            userId,
            telegramId: telegramUser.id,
            username: telegramUser.username,
            firstName: telegramUser.first_name,
            lastName: telegramUser.last_name,
            languageCode: telegramUser.language_code,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        await (0, dynamodb_1.createUser)(newUser);
    }
}
async function recordEvent(message) {
    const eventRecord = {
        eventId: (0, uuid_1.v4)(),
        userId: message.update.message?.from
            ? `telegram_${message.update.message.from.id}`
            : message.update.callback_query?.from
                ? `telegram_${message.update.callback_query.from.id}`
                : 'unknown',
        eventType: message.eventType,
        payload: message.update,
        timestamp: message.receivedAt,
        processed: true,
    };
    await (0, dynamodb_1.createEvent)(eventRecord);
}
//# sourceMappingURL=index.js.map
/**
 * Token decoder for /start <token> deep links
 * Format: base64url(ref_code|utm_source|utm_medium|utm_campaign|nonce|ts)
 */
export interface StartAttrs {
    ref_code?: string;
    utm?: {
        source?: string;
        medium?: string;
        campaign?: string;
        content?: string;
    };
    nonce?: string;
    ts?: number;
}
/**
 * Decode a base64url-encoded start token
 * @param token - The token from /start command (e.g., /start <token>)
 * @returns Parsed attributes (referral, UTM, timestamp, nonce)
 */
export declare function decodeStartToken(token?: string): StartAttrs;
/**
 * Validate token age (optional - reject tokens older than 7 days)
 * @param attrs - Parsed token attributes
 * @param maxAgeSeconds - Maximum age in seconds (default: 7 days)
 * @returns true if valid, false if expired
 */
export declare function isTokenValid(attrs: StartAttrs, maxAgeSeconds?: number): boolean;
//# sourceMappingURL=token.d.ts.map
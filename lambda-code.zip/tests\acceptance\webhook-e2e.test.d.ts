/**
 * End-to-End Acceptance Tests for Telegram Webhook
 *
 * These tests verify the entire flow from webhook to DynamoDB
 * Run against a deployed stack in AWS
 */
export {};
//# sourceMappingURL=webhook-e2e.test.d.ts.map
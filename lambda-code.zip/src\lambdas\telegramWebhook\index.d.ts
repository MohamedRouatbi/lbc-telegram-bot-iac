import type { APIGatewayProxyResult } from 'aws-lambda';
interface APIGatewayEvent {
    httpMethod?: string;
    path?: string;
    rawPath?: string;
    body?: string;
    headers: Record<string, string>;
    requestContext?: {
        http?: {
            method: string;
            path: string;
        };
    };
}
/**
 * Lambda handler for Telegram webhook
 * Receives webhook POST requests, validates them, and enqueues to SQS
 */
export declare function handler(event: APIGatewayEvent): Promise<APIGatewayProxyResult>;
export {};
//# sourceMappingURL=index.d.ts.map
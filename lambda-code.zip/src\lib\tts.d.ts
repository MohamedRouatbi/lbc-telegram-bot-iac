/**
 * Amazon Polly TTS with S3 caching (cache-first pattern)
 */
import { VoiceId } from '@aws-sdk/client-polly';
export interface TTSParams {
    userId: string;
    lang: string;
    bucket: string;
    kmsKeyId?: string;
}
export interface TTSResult {
    s3Key: string;
    cached: boolean;
}
/**
 * Get or create TTS greeting audio (cache-first)
 * 1. Check if S3 object exists
 * 2. If missing, generate via Polly and upload to S3
 * 3. Return S3 key
 */
export declare function getOrCreateGreeting(params: TTSParams): Promise<TTSResult>;
/**
 * Get Polly voice for a language code
 */
export declare function getVoiceForLanguage(lang: string): VoiceId;
//# sourceMappingURL=tts.d.ts.map
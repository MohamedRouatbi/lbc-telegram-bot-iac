/**
 * Finite State Machine (FSM) for /start onboarding flow
 */
export type UserState = 'NEW' | 'WELCOME_VIDEO_SENT' | 'TTS_SENT' | 'DONE';
/**
 * State transition logic
 * @param current - Current user state
 * @returns Next state in the flow
 */
export declare function nextState(current?: UserState): UserState;
/**
 * Check if a state transition is allowed
 * @param from - Current state
 * @param to - Target state
 * @returns true if transition is valid
 */
export declare function isValidTransition(from: UserState | undefined, to: UserState): boolean;
/**
 * Get a human-readable description of the state
 */
export declare function getStateDescription(state?: UserState): string;
/**
 * Create state progress entry with timestamp
 */
export declare function createProgressEntry(state: UserState): string;
//# sourceMappingURL=fsm.d.ts.map
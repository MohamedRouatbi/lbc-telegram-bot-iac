/**
 * /start command handler for onboarding flow
 */
import type { TelegramMessage } from '../../lib/types';
/**
 * Handle /start command
 */
export declare function handleStartCommand(message: TelegramMessage): Promise<void>;
//# sourceMappingURL=startHandler.d.ts.map
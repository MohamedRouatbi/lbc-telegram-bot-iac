/**
 * Telegram Bot API client
 */
export interface TelegramInlineButton {
    text: string;
    url?: string;
    callback_data?: string;
}
export interface SendMessageOptions {
    chatId: number | string;
    text: string;
    buttons?: TelegramInlineButton[][];
    parse_mode?: 'Markdown' | 'HTML';
}
/**
 * Send a message via Telegram Bot API
 */
export declare function sendMessage(options: SendMessageOptions): Promise<any>;
/**
 * Send a video message via Telegram Bot API
 */
export declare function sendVideo(options: {
    chatId: number | string;
    videoUrl: string;
    caption?: string;
    buttons?: TelegramInlineButton[][];
}): Promise<any>;
/**
 * Send an audio message via Telegram Bot API
 */
export declare function sendAudio(options: {
    chatId: number | string;
    audioUrl: string;
    caption?: string;
    buttons?: TelegramInlineButton[][];
}): Promise<any>;
//# sourceMappingURL=telegram.d.ts.map
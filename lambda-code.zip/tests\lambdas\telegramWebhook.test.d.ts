export {};
//# sourceMappingURL=telegramWebhook.test.d.ts.map
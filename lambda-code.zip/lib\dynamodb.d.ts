import type { UserRecord, SessionRecord, EventRecord } from './types';
export declare function createUser(user: UserRecord): Promise<void>;
export declare function getUser(userId: string): Promise<UserRecord | null>;
export declare function updateUser(userId: string, updates: Partial<Omit<UserRecord, 'userId'>>): Promise<void>;
export declare function createSession(session: SessionRecord): Promise<void>;
export declare function getSession(sessionId: string): Promise<SessionRecord | null>;
export declare function getSessionsByUser(userId: string): Promise<SessionRecord[]>;
export declare function deleteSession(sessionId: string): Promise<void>;
export declare function createEvent(event: EventRecord): Promise<void>;
export declare function getEvent(eventId: string): Promise<EventRecord | null>;
export declare function getEventsByUser(userId: string, limit?: number): Promise<EventRecord[]>;
export declare function markEventProcessed(eventId: string): Promise<void>;
//# sourceMappingURL=dynamodb.d.ts.map
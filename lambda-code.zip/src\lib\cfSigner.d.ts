/**
 * CloudFront signed URL generator for secure media delivery
 */
export interface SignedUrlOptions {
    domain: string;
    resourcePath: string;
    keyPairId: string;
    ttlSeconds: number;
}
/**
 * Generate a CloudFront signed URL with short TTL
 * Uses native crypto module for compatibility with Node.js 20
 * @param options - Configuration for the signed URL
 * @returns Signed URL string
 */
export declare function signCloudFrontUrl(options: SignedUrlOptions): Promise<string>;
/**
 * Get welcome video path for a given language
 * @param lang - Language code (e.g., 'en', 'es')
 * @returns CloudFront resource path
 */
export declare function getWelcomeVideoPath(lang: string): string;
/**
 * Get TTS audio path for a user
 * @param s3Key - S3 key from TTS generation
 * @returns CloudFront resource path (with leading slash)
 */
export declare function getTTSAudioPath(s3Key: string): string;
//# sourceMappingURL=cfSigner.d.ts.map